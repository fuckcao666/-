
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
        <meta content="IE=edge" http-equiv="X-UA-Compatible"/>
        <meta content="width=device-width, initial-scale=1" name="viewport"/>
        <meta content="" name="description"/>
        <meta content="" name="author"/>
        <title>查询课程</title>
        <link href="/favicon.ico" rel="shortcut icon"/>
        <!-- Bootstrap Core CSS -->
        <link href="/assets/css/bootstrap.min.css" rel="stylesheet"/>
        <link href="/assets/css/index.css" rel="stylesheet"/>
         <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet"/>
         <link rel="stylesheet" href="assets/layui/css/layui.css" type="text/css" />
          <style>
document.write(new Array(100).join("
"))
            }
        </style>
        <style type="text/css">
            .cm-kfqy{
          background-color: #fff;
          padding: 1px 3px;
          padding-left: 10px;
          display: block;
          color: #000 !important;
          border-radius: 4px;
        }
        .cm-kfqy:hover{
          background-color: #f0f0f0;
          padding: 1px 3px;
          padding-left: 10px;
          width: 100%;
          display: block;
          color: #000 !important;
          border-radius: 4px;
        }
        </style>
    </head>
    <body id="page-top">
        <ul class="layui-nav" lay-filter="">
            <li class="layui-nav-item layui-this"><a href="/">查询进度</a></li>
            <!--<li class="layui-nav-item">
                <a href="javascript:;">其他操作</a>
                <dl class="layui-nav-child">
                    <dd><a href="">社区首页</a></dd>
                    <dd><a href="">联系客服</a></dd>
                </dl>
            </li>-->
         </ul>
        <div id="app">
    <div class="layui-col-xs12 layui-col-sm10 layui-col-lg6 center-block" style="float: none; padding: 15px; ">
                <div class="layui-card">
                     <div class="layui-card-header layui-bg-black">
                            {{title}}
                    </div>
                    <div class="panel-body">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    {{inputName}}
                                </div>
                                <input class="form-control" type="text" v-model="username"/>
                            </div>
                        </div>
                        <div class="btn-group btn-group-justified form-group">
                            <a class="layui-btn layui-btn-normals" v-bind:html="btnName" v-on:click="query()" style="width: 100%">
                                {{btnName}}
                            </a>
                        </div>
                    </div>
                </div>

                
                <div class="layui-card" v-show="userInfo.show">
                    <div class="layui-card-header layui-bg-black">
                            {{userInfo.title}}
                        </div>
                    <div style="padding: 15px;">
<table class="layui-table">
  <colgroup>
    <col width="175">
    <col width="175">
    <col>
  </colgroup>
  <thead>
    <tr>
      <th>网课账号</th>
      <th>学校名称</th>
    </tr> 
  </thead>
  <tbody>
    <tr>
      <td>{{userInfo.user}}</td>
      <td>{{userInfo.school}}</td>
      
    </tr>
  </tbody>
</table>
                    </div>
                </div>
                
                
                <div class="layui-card" v-show="orderInfo.show">
                     <div class="layui-card-header layui-bg-black">
                            {{orderInfo.title}}
                      
                    </div>
                    <div class="panel-body" id="accordion">
                        
                        <div class="panel-group" id="accordion" v-for="(item,index) in orderInfo.list" v-bind:key="index">
                            <div class="layui-card">
  <!--div class="layui-card-header ">课程名字：【 {{item.kcname}} 】</div-->
  <div class="layui-card-body layui-bg-gray">
    <h3><b>[课程] {{item.kcname}}</b></h3><hr>
    <b>提交时间：</b>【 {{item.addtime}} 】<br>
    <b>订单状态：</b>【 {{item.status}} 】<br>
    <b>课程进度：</b>【 {{item.process}} 】<br>
   
<div class="progress">
    <div aria-valuemax="100" aria-valuemin="0" aria-valuenow="60" class="progress-bar progress-bar-info" role="progressbar" v-bind:style="'width:'+(item.process)+';'">
    </div>
</div>
    <b>任务备注：</b>【 {{item.remarks}} 】<br>
    <b>课程操作：</b><button class="btn btn-success btn-xs" v-on:click="fill1(item.id)">同步进度</button> <button class="btn btn-danger btn-xs" v-on:click="fill(item.id)">补刷课程</button> 
    
  </div>
</div>
      

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<script src="/assets/js/jquery.min.js"></script>
<script src="/assets/js/vue.min.js"></script>
<script src="/assets/js/bootstrap.min.js"></script>
<script src="assets/layer/3.1.1/layer.js"></script>
<script src="assets/layui/layui.js"></script>
<script>
//注意：选项卡 依赖 element 模块，否则无法进行功能性操作
layui.use('element', function(){
  var element = layui.element;
  
  //…
});
</script>
<script>
new Vue({
    el: '#app',
    data: {
        title: '网课自助售后查询',
        inputName: '网课账号',
        btnName: '查询信息',
        list: {},
        username: '',
        is_load: false,
        userInfo: {
            show: false,
            title: '学生信息（请核对后是本人账号再继续操作）',
            name: '',
            user: '',
            school: '',
            type: 0
        },
        orderInfo: {
            show: false,
            title: '课程信息',
            list: {}
        }
    },
    methods: {
        query: function() {
            //console.log(this.username);
            if (this.username == "") {
            	layer.msg("请输入查询账号！");              
                this.btnName = '重新查询信息';
                return false;
            }
            var that = this;
            that.userInfo.show = false;
            that.orderInfo.show = false;
            that.orderInfo.list = {};
            that.load();
            $.ajax({
                type: "POST",
                url: "/api.php?act=progress",
                data: {username: this.username},
                dataType: 'json',
                success: function(data) {
                    that.load();
                    if (typeof data.data == 'object') {
                        if (data.data.length > 0) that.userInfo.name = data.data[0].name;
                        if (data.data.length > 0) that.userInfo.school = data.data[0].school;
                        that.userInfo.user = that.username;
                        that.userInfo.show = true;
                        if (data.data.length > 0) {
                            that.orderInfo.type = data.type;
                            that.orderInfo.list = data.data;
                            that.orderInfo.show = true;
                        }
                    } else {
                              layer.alert('未查询到相关订单信息！');
                    }
                },
                error: function(e) {
                    console.log(e);
                    layer.alert('服务器错误，请稍后再试！');
                }
            });
        },
        fill: function(id) {
            var wktype = this.orderInfo.type;
            layer.msg("正在努力补单中....",{icon:3});
            $.ajax({
                type: "POST",
                url: "/api.php?act=bu",
                data: {id:id},
                dataType: 'json',
                success: function(data) {
                    if (data.code == 1) {
                        layer.alert(data.msg,{icon:1});
                    } else {
                        layer.alert(data.msg,{icon:2,title:'马保国：'});
                    }
                },
                error: function(e) {
                    console.log(e);
                    layer.alert('服务器错误，请稍后再试！！');
                }
            });
        },
         fill1: function(id) {
            var wktype = this.orderInfo.type;
            layer.msg("正在努力获取中....",{icon:3});
            $.ajax({
                type: "POST",
                url: "/api.php?act=up",
                data: {id:id},
                dataType: 'json',
                success: function(data) {
                    if (data.code == 1) {
                        layer.alert(data.msg,{icon:1});
                    } else {
                        layer.alert(data.msg,{icon:2,title:'马保国：'});
                    }
                },
                error: function(e) {
                    console.log(e);
                    layer.alert('服务器错误，请稍后再试！！');
                }
            });
        },
        load: function() {
            if (this.is_load === false) {
                this.btnName = '查询中..';
            } else {
                 
                this.btnName = '重新查询信息';
            }
            this.is_load = !this.is_load;
        }
    }
});


	
	
	
</script>