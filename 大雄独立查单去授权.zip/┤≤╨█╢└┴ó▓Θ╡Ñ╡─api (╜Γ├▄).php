<?php
require_once 'config.php';
@header('Content-Type: application/json; charset=UTF-8');
$act=$_GET['act'];
if ($act=="getchake") {
        $platform=daddslashes($_POST['platform']);
	    $userinfo=daddslashes($_POST['userinfo']);
	    $kms = str_replace(array("\r\n", "\r", "\n"), "[br]", $userinfo);
		$info=explode("[br]",$kms);
		for($i=0;$i<count($info);$i++){
			 $str = merge_spaces(trim($info[$i]));
			 $userinfo2=explode(" ",$str);//分割
			 if(count($userinfo2)>2){
			 	$data = array("uid" => $uid, "key" => $key, "platform" => $platform, "school" => $userinfo2[0], "user" => $userinfo2[1], "pass" => $userinfo2[2]);
			 }else{
			 	$data = array("uid" => $uid, "key" => $key, "platform" => $platform, "school" => "自动识别", "user" => $userinfo2[0], "pass" => $userinfo2[1]);
			 }		
		 	$dx_url = "$dx_rl/api/index.php?act=chake";
		 	$result = get_url($dx_url, $data);
		 	$result = json_decode($result, true);				
		}         
	    exit(json_encode($result));      
}else if ($act=="syclass") {
    if ($switch=="no") {
        $data = array("uid" => $uid, "key" => $key);
        $dx_url = "$dx_rl/api/index.php?act=class";
        $result = get_url($dx_url, $data);
        $result = json_decode($result, true);
        exit(json_encode($result));
    }elseif ($switch=="off") {
        $data=array('code'=>1,'data'=>$json_data);
	    exit(json_encode($data));
    }else {
        $result=array("code"=>-2,"msg"=>"请打开课程列表开关");
        exit(json_encode($result));
    }
    
}else if ($act=="progress") {
    $username=$_POST['username'];
    $data = array("uid" => $uid, "key" => $key ,"username" => $username);
	$dx_url = "$dx_rl/api/index.php?act=cd";
	$result = get_url($dx_url, $data);
	$result = json_decode($result, true);
	exit(json_encode($result));
}else if ($act=="bu") {
    $id=$_POST['id'];
    $data = array("uid" => $uid, "key" => $key ,"id" => $id);
	$dx_url = "$dx_rl/api/index.php?act=bd";
	$result = get_url($dx_url, $data);
	$result = json_decode($result, true);
	exit(json_encode($result));
}else if ($act=="up") {
    $id=$_POST['id'];
    $data = array("uid" => $uid, "key" => $key ,"id" => $id);
	$dx_url = "$dx_rl/api/index.php?act=up";
	$result = get_url($dx_url, $data);
	$result = json_decode($result, true);
	exit(json_encode($result));
}
function get_url($url, $post = false, $cookie = false, $header = false)
{
	$ch = curl_init();
	if ($header) {
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
	} else {
		curl_setopt($ch, CURLOPT_HEADER, 0);
	}
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36");
	if ($post) {
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
	}
	if ($cookie) {
		curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	}
	$result = curl_exec($ch);
	curl_close($ch);
	return $result;
}
function daddslashes($string, $force = 0, $strip = FALSE)
{
	!defined("MAGIC_QUOTES_GPC") && define("MAGIC_QUOTES_GPC", get_magic_quotes_gpc());
	if (!MAGIC_QUOTES_GPC || $force) {
		if (is_array($string)) {
			foreach ($string as $key => $val) {
				$string[$key] = daddslashes($val, $force, $strip);
			}
		} else {
			$string = addslashes($strip ? stripslashes($string) : $string);
		}
	}
	return $string;
}
function merge_spaces($string)
{
	return preg_replace("/\\s+/", " ", $string);
}