<?php
//授权的学习平台
$dx_rl = "http://www.wklin.icu"; //填完整地址带http(s)://
$uid="1"; //填你的uid
$key=""; //填你得key

//是否使用对接平台的课程名字开关
//off关闭  no打开  默认no打开
$switch="no";

//如果关闭对接平台课程名字请在下方自定义配置想要显示的名字
//cid参数对应的是对接平台的课程id
//name参数为你要显示的课程名字
//content参数为对应课程的弹窗内容
//每添加一个课程复制下方示例修改即可
// $json_data[] = ['cid' => "对应的课程id",'name' => "显示的名字",'content' => "弹窗内容"];
$json_data[] = ['cid' => "平台课程id",'name' => "名字",'content' => "弹窗内容"];
$json_data[] = ['cid' => "id2",'name' => "名字2",'content' => "内容2"];
?>