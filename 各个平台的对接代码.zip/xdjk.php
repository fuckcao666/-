<?php

function wkname()
{
    $data = array(

        "27" => "27",
        "wuming" => "无名平台w",
        "paolu" => "paolu",
        "ameng" => "ameng",
        "xxtgf" => "学习通(官方查课)",
        "003" => "003",
        "buxi" => "buxi",
        "bb" => "白白",
        "bbpl" => "bbpl",
        "dlzj" => "代理之家",
        "oligei" => "2022",
        // 		"abab"=>"abab",
        "abzj" => "ab自己",
       
        "NB" => "NB",
      


        "kingxdd" => "kingxdd",
        // 		"ouba" => "欧巴仅下单",
        // 		"oubaks" => "欧巴仅考试",
        // 		"oubakj" => "欧巴仅课件",
        // // 		"wklmtoken" => "网课联盟token",
        // 		"wklmcookie" => "网课联盟cookie",
        // 		"wklmckbks" => "网课联盟ck不考试",
        // 		"00" => "00",
        // 		"jz" => "捐赠接口",
        // "laozhang" => "laozhang",
        // 		"zjygf" => "智慧职教职教云(官方查课)",
        // 		"moocgf" => "智慧职教MOOC(官方查课)",
        // 		"zykgf" => "智慧职教资源库(官方查课)",
        // 		"ayck" => "ay查课插件调用查课",
        // 		"dlam" => "哆啦a梦cookie",
        // 		"mogu" => "蘑菇",
        // 		"zs" => "止水",
        // 		"oo1" => "oo1",
        // 		"o1" => "o1",
        // 		"tf" => "tf",
        // 		"ts" => "ts",
        // 		"xiyouji" => "xiyouji",


    );
    return $data;
}
// 这里也要添加相应的接口数据  比如  "shenwei" => "神威",  后他设置里面才能看到

function addWk($oid)
{
    global $DB;
    global $wk;
    $d = $DB->get_row("select * from qingka_wangke_order where oid='{$oid}' ");
    $cid = $d["cid"];
    $school = $d["school"];
    $user = $d["user"];
    $pass = $d["pass"];
    $kcid = $d["kcid"];
    $kcname = $d["kcname"];
    $noun = $d["noun"];
    $miaoshua = $d["miaoshua"];
    $b = $DB->get_row("select * from qingka_wangke_class where cid='{$cid}' ");
    $hid = $b["docking"];
    $a = $DB->get_row("select * from qingka_wangke_huoyuan where hid='{$hid}' ");
    $type = $a["pt"];
    $cookie = $a["cookie"];
    $token = $a["token"];
    $ip = $a["ip"];

    //27下单接口
    if ($type == "27") {
        $data = array("uid" => $a["user"], "key" => $a["pass"], "platform" => $noun, "school" => $school, "user" => $user, "pass" => $pass, "kcname" => $kcname);
        $eq_rl = $a["url"];
        $eq_url = "$eq_rl/api.php?act=add";
        $result = get_url($eq_url, $data, $cookie);
        $result = json_decode($result, true);
        if ($result["code"] == "0") {
            $b = array("code" => 1, "msg" => "下单成功");
        } else {
            $b = array("code" => -1, "msg" => $result["msg"]);
        }
        return $b;
    }
   
    //牛逼下单接口
    elseif ($type == "NB") {
        $data = array("uid" => $a["user"], "key" => $a["pass"], "platform" => $noun, "school" => $school, "user" => $user, "pass" => $pass, "kcname" => $kcname, "kcid" => $kcid);
        $eq_rl = $a["url"];
        $eq_url = "$eq_rl/api.php?act=add";
        $result = get_url($eq_url, $data, $cookie);
        $result = json_decode($result, true);
        if ($result["code"] == "0") {
            $b = array("code" => 1, "msg" => "下单成功");
        } else {
            $b = array("code" => -1, "msg" => $result["msg"]);
        }
        return $b;
    } 
  
    //AB下单
    else if ($type == "abzj") {
        $preg = preg_split('/\|/', $kcid);
        $data = array("account" => $user, "password" => $pass, "appId" => $noun, "schoolId" => "", "school" => $school, "studyTasks" => array("0" => array("courseId" => $kcid, "courseName" => $kcname, "personID" => null, "type" => "")));
        $data = json_encode($data);
        $urls = $a['url'];
        $url = "https://$urls/api/addStudyOrder";
        $header = [
            "Content-Type: application/json;charset=UTF-8",
            "Authorization:$token",
            "apiVersion: 1.7",
            "Connection: keep-alive",
            "Origin: http://$urls",
            "Referer: http://$urls/"

        ];
        $result = post($url, $data, $header);
        $result = json_decode($result, true);
        if ($result["code"] == "1") {
            $b = array("code" => 1, "msg" => "下单成功");
        } else {
            $b = array("code" => -1, "msg" => $result["msg"]);
        }
        return $b;
    } else if ($type == "dlzj") {
        $preg = preg_split('/\|/', $kcid);
        $data = array("account" => $user, "password" => $pass, "platformId" => $noun, "taskType" => 0, "courseList" => array("0" => array("courseId" => $preg[0], "courseName" => $kcname, "classId" => $preg[1], "isChecked" => true)));
        $data = json_encode($data);
        $url = $a['url'];
        $url = "http://$url/api/course/add.php";
        $header = [
            "Content-Type: application/json;charset=UTF-8",
            "token:$token",
            "apiVersion: 1.8",
            "Connection: keep-alive",
            "Origin: http://dlgd.org",
            "Referer: http://dlgd.org/"

        ];
        $result = post($url, $data, $header);
        $result = json_decode($result, true);
        if ($result["code"] == "200") {
            $b = array("code" => 1, "msg" => "下单成功");
        } else {
            $b = array("code" => -1, "msg" => $result["msg"]);
        }
        return $b;
    } 
    
    
    //king下单
    else if ($type == "wang") {
        
        $kcnamelist = explode(",", $kcname);
        foreach ($kcnamelist as $key) {
            $list[] = $key;
        }
        $data = array(array("PlatformID" => $noun, "list" => $list, "password" => $pass, "school" => $school, "username" => $user, "miao" => "false", "isUnit" => "false"));
        // $token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiMTA0MSIsIm5iZiI6MTY2Mzg1MTA5MSwiZXhwIjoxNjc5NDg5NDkxLCJpYXQiOjE2NjM4NTEwOTF9.p-v39982BCzrak2SHW9Ngojc7DrLIUuNGsqsra9ULFU";
        $base_url=$a['url'];
        $url = "http://$base_url/api/Order/GiveClass";
        $data = json_encode($data);
        $header = array('Content-Type: application/json', "Cookie: $cookie", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36");
        
        $result = post($url, $data, $header);
        $result = json_decode($result, true);
        if ($result["code"] == 0) {
            $b = array("code" => 1, "msg" => "下单成功");
        } else {
            $b = array("code" => - 1, "msg" => $result['msg']);
        }
        return $b;
    }
  else if ($type == "oligei") {
  $data = array( "token" => $token,"ptid" => $noun, "school" => $school, "user" => $user, "pass" => $pass, "kcname" => $kcname, "kcid" => $kcid, "miaoshua" => $miaoshua, "shichang" => $shichang);
  $oligei_rl = $a["url"];
  $oligei_url = "$oligei_rl/api/add";
  $result = get_url($oligei_url, $data,$cookie);
  $result = json_decode($result, true);
  if ($result["code"] == "0") {
   $b = array("code" => 1, "msg" => "下单成功");
  } else {
   $b = array("code" => -1, "msg" => $result["msg"]);
  }
  return $b;}
    //king 下单
    else if ($type == 'kingxdd') {
        // $data=array("0"=>array("PlatformID"=>$noun,"school"=>$school,"password"=>$pass,"school"=>$school,"username"=>$user,"isUnit"=>false,"list"=>array($kcname)));
        $data = array("0" => array("PlatformID" => $noun, "school" => $school, "password" => $pass, "username" => $user, "isUnit" => false, "list" => array($kcname)));
        $url = $a["url"];
        $ameng_url = "http://$url/api/Order/GiveClass";
        $data = json_encode($data);
        $header = [
            "Accept: application/json, text/plain, */*",
            "Cookie: $cookie",
            "Accept-Language: zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
            "Content-Type: application/json",
            "Host: www.nice-nice.top",
            "Origin: http://www.nice-nice.top",
            "Proxy-Connection: keep-alive",
            "Referer: http://www.nice-nice.top/", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36 Edg/106.0.1370.34"
        ];
        $result = post($ameng_url, $data, $header);
        $result = json_decode($result, true);
        if ($result["code"] == "0") {
            $b = array("code" => 1, "msg" => "下单成功");
        } else {
            $b = array("code" => -1, "msg" => $result["msg"]);
        }
        return $b;
    } 
    //隐藏00下单接口
    //隐藏00下单接口
    else if ($type == "003") {
        $data = array(
            "accountmsg" => [["$school $user $pass", "$kcname"]],
            "token" => "$token",
            "value" => "$noun"
        );
        $data = json_encode($data, true);
        $header = array("Content-Type: application/json;charset=UTF-8", "cookie:$cookie", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.33");
        $url = $a["url"];
        $yc_url = "http://$url/order/submit/";
        $result = post($yc_url, $data, $header);
        $result = json_decode($result, true);

        if ($result["code"] == 0) {
            $b = array("code" => 1, "msg" => "添加成功");
        } else {
            $b = array("code" => -1, "msg" => $result["msg"]);
        }
        return $b;
    }


    //跑路下单接口
    else if ($type == "paolu") {
        $data = array("uid" => $a["user"], "key" => $a["pass"], "platform" => $noun, "school" => $school, "user" => $user, "pass" => $pass, "kcname" => $kcname, "kcid" => $kcid);
        $eq_rl = $a["url"];
        $eq_url = "$eq_rl/api.php?act=add";
        $result = get_url($eq_url, $data, $cookie);
        $result = json_decode($result, true);
        if ($result["code"] == "0") {
            $b = array("code" => 1, "msg" => "下单成功");
        } else {
            $b = array("code" => -1, "msg" => $result["msg"]);
        }
        return $b;
    }

    //无名学习平台下单接口
    else if ($type == "wuming") {
        $data = array("uid" => $a["user"], "key" => $a["pass"], "platform" => $noun, "school" => $school, "user" => $user, "pass" => $pass, "kcname" => $kcname, "kcid" => $kcid);
        $wm_rl = $a["url"];
        $wm_url = "$wm_rl/api.php?act=add";
        $result = get_url($wm_url, $data);
        $result = json_decode($result, true);
        if ($result["code"] == "0") {
            $b = array("code" => 1, "msg" => "下单成功");
        } else {
            $b = array("code" => -1, "msg" => $result["msg"]);
        }
        return $b;
    }
    //白白下单	
    else if ($type == "bb") {
        $data = array("school" => $school, "user" => $user, "pass" => $pass, "api_token" => $token, "cid" => $noun, "kcname" => $kcname, "uid" => 3401);
        $fk_sul = $a["url"];
        $fk_urll = "$fk_sul/api.php/lm/add";
        $result = get_url($fk_urll, $data);
        $result = json_decode($result, true);
        if ($result["code"] == 0) {
            $b = array("code" => 1, "msg" => $result["msg"], "yid" => $first);
        } else {
            $b = array("code" => -1, "msg" => $result["msg"]);
        }
        return $b;
    }
    //白白下单	
    else if ($type == "bbpl") {
        $data = array("school" => $school, "user" => $user, "pass" => $pass, "api_token" => $token, "cid" => $noun, "kcname" => $kcname, "uid" => 4074);
        $fk_sul = $a["url"];
        $fk_urll = "$fk_sul/api.php/lm/add";
        $result = get_url($fk_urll, $data);
        $result = json_decode($result, true);
        if ($result["code"] == 0) {
            $b = array("code" => 1, "msg" => $result["msg"], "yid" => $first);
        } else {
            $b = array("code" => -1, "msg" => $result["msg"]);
        }
        return $b;
    }


  



}
