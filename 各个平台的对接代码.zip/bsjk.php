<?php  
function budanWk($oid){
	global $DB;
	global $wk;
	$d = $DB->get_row("select * from qingka_wangke_order where oid='{$oid}' ");
	$b = $DB->get_row("select hid,yid,user from qingka_wangke_order where oid='{$oid}' ");
	$hid = $b["hid"];
	$yid = $b["yid"];
	$user = $b["user"];
	$a = $DB->get_row("select * from qingka_wangke_huoyuan where hid='{$hid}' ");
	$type = $a["pt"];
	$cookie = $a["cookie"];
	$token = $a["token"];
	$ip = $a["ip"];
	$cid = $d["cid"];
	$school = $d["school"];
	$user = $d["user"];
	$pass = $d["pass"];
	$kcid = $d["kcid"];
	$kcname = $d["kcname"];
	$noun = $d["noun"];
	$miaoshua = $d["miaoshua"];

	//27补刷javascript:;
	if ($type == "27") {
		$data = array("uid" => $a["user"], "key" => $a["pass"], "id" => $yid);
		$eq_rl = $a["url"];
		$eq_url = "$eq_rl/api.php?act=budan";
		$result = get_url($eq_url, $data);
		$result = json_decode($result, true);
		return $result;
	}
	//King补刷
    else if ($type == "wang") {
        $base_url=$a['url'];
        $header = array("Content-Type: application/json;charset=UTF-8", "Cookie:$cookie");
        $result = get_url("http://$base_url/api/Order/freshOrder?OID=$yid",false,false, $header);
        $result = json_decode($result, true);
        if($result['code']!=-1){
            $result['code']=1;
        }
        return $result;
    }
	 else if ($type == "oligei") {
  $data = array("token" => $token, "id" => $yid);
   $oligei_rl = $a["url"];
  $oligei_url = "$oligei_rl/api_koufei/reset";
  $result = get_url($oligei_url, $data,$cookie);
  $result = json_decode($result, true);
  if ($result["code"] == 1) {
     $b = array("code" => 1, "msg" => "操作成功");
    } else {
     $b = array("code" => -1, "msg" => "操作失败，请重试");
    }
   return $b;   
 }
		//xyj
	elseif ($type == "NB") {
		$data = array("uid" => $a["user"], "key" => $a["pass"], "id" => $yid);
		$eq_rl = $a["url"];
		$eq_url = "$eq_rl/api.php?act=budan";
		$result = get_url($eq_url, $data);
		$result = json_decode($result, true);
		return $result;
	} 
	//27补刷


	

	//King补刷
	elseif($type=="kingxdd"){
	    $url="http://$url/api/Order/freshOrderV2";
        $data=[$yid];
        $data=json_encode($data);
        $header=[
        "Accept: application/json, text/plain, */*",
        "Accept-Encoding: gzip, deflate",
        "Cookie: $cookie",
        "Accept-Language: zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
        "Content-Length: 8",
        "Content-Type: application/json",
        "Host: www.nice-nice.top",
        "Origin: http://www.nice-nice.top",
        "Proxy-Connection: keep-alive",
        "Referer: http://www.nice-nice.top/",
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36 Edg/106.0.1370.34"];
		$result=post($url,$data,$header);
		$result = json_decode($result, true);
        if ($result["msg"] == "批量重刷订单1条成功") {
            $b = array("code" => 1, "msg" => "补刷成功");
        } else {
            $b = array("code" => - 1, "msg" => $result["msg"]);
        }
        return $b;
	}
	//00 补刷接口
	else if($type == "003"){
	    $data = array("id"=>$yid,"token"=> $token);
	     $data=json_encode($data,true);
         $header=[
		    "cookie: cf_clearance=qRPzYgnuwCyTZ1pRWGt76lEuukGvev6OF4WOA8ETRbg-1665791721-0-250;$cookie",
		    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36 Edg/106.0.1370.42",
		    "Referer: http://$url/",
		    "Origin:http://$url",
		    "X-Token:$token",
		    "Accept: application/json, text/plain, */*",
		    "Content-Type: application/json;charset=UTF-8",
		    "Host: api.duangks.org",
		];
    	$yc_url = $a["url"];
    // 	$yc_url = "$url/order/reset/";
    	$result = post("http://$yc_url/order/reset/", $data,$header);
    	$result = json_decode($result, true);
    // 	return $result;
    	if ($result["code"] == 0) {
    		$b = array("code" => 1, "msg" => "补单成功，知到请确保无异地验证");
    	} else {
    		$b = array("code" => -1, "msg" => "补单失败，请重试");
    	}
	return $b;
	    
	}
	//ab补刷
	else if($type == "abab"){
        $url="https://abab.app/api/reTry?taskId=$yid";
    $header = ["authorization:$token","Content-Type:application/json;charset=UTF-8"];
 $result=get_url($url,false,false,$header);
var_dump($result);
 $result=json_decode($result,true);
   if ($result["code"] == 0) {
     $b = array("code" => 1, "msg" => $result["message"]);
    } else {
     $b = array("code" => -1, "msg" =>$result["data"]."".$result["message"]);
    }
   return $b;   
         
    }

//ab补刷
	else if($type == "abzj"){
        $url="https://abab.app/api/reTry?taskId=$yid";
    $header = ["authorization:$token","Content-Type:application/json;charset=UTF-8"];
 $result=get_url($url,false,false,$header);
// var_dump($result);
 $result=json_decode($result,true);
   if ($result["code"] == 1) {
     $b = array("code" => 1, "msg" => $result["message"]);
    } else {
     $b = array("code" => -1, "msg" =>$result["data"]."".$result["message"]);
    }
   return $b;   
         
    }

//     }
	//跑路补刷
	else if ($type == "paolu") {
		$data = array("uid" => $a["user"], "key" => $a["pass"], "id" => $yid);
		$eq_rl = $a["url"];
		$eq_url = "$eq_rl/api.php?act=budan";
		$result = get_url($eq_url, $data);
		$result = json_decode($result, true);
		return $result;
	} 

    //无名学习平台补刷
	else if ($type == "wuming") {
		$data = array("uid" => $a["user"], "key" => $a["pass"], "id" => $yid);
		$wm_rl = $a["url"];
		$wm_url = "$wm_rl/api.php?act=budan";
        $result = get_curl($wm_url, $data);
        $result = json_decode($result, true);
		if ($result["code"] == 1) {
			$b = array("code" => 1, "msg" => "补刷成功");
		} else {
			$b = array("code" => -1, "msg" => $result["msg"]);
		}
		return $b;
		    
	} 

	//白白补单

 //白白补单

 else if($type == "bb"){
     $data = array("user"=>$user,"uid"=>"3401","kcname"=>$kcname,"id"=>$yid,"cid" => $noun);
     $lm_ul = $a["url"];
     $lm_dingdan = "$lm_ul/api.php/lm/chongshua";
     $result = get_url($lm_dingdan, $data);
     $result = json_decode($result, true);
     if ($result["code"] == 0) {//buzzlighter
      $b = array("code" => 1, "msg" => "补单成功");
     } else {
      $b = array("code" => -1, "msg" => $result["msg"]);
     }
 return $b;}
        
    else if ($type=="dlzj"){
    $url=$a['url'];
    $url="http://$url/api/order/batchUpdateState.php";
    $data=array(
        "ids"=>$yid,
        "orderState"=>0,
        "type"=>"courseStatus",
        "Connection: keep-alive"
    );
    $header=["token:$token","apiVersion:1.8"];
    $result=post($url,$data,$header);
    $result = json_decode($result, true);
    if ($result["code"] == "200") {
        $b = array("code" => 1, "msg" => "补刷成功");
    } else {
        $b = array("code" => - 1, "msg" => $result["msg"]);
    }
    return $b;
}
        
    //白白补单

     else if($type == "bbpl"){
     $data = array("user"=>$user,"uid"=>"4074","kcname"=>$kcname,"id"=>$yid,"cid" => $noun);
     $lm_ul = $a["url"];
     $lm_dingdan = "$lm_ul/api.php/lm/chongshua";
     $result = get_url($lm_dingdan, $data);
     $result = json_decode($result, true);
     if ($result["code"] == 0) {//buzzlighter
      $b = array("code" => 1, "msg" => "补单成功");
     } else {
      $b = array("code" => -1, "msg" => $result["msg"]);
     }
     return $b;}
        
    else if ($type=="dlzj"){
    $url=$a['url'];
    $url="http://$url/api/order/batchUpdateState.php";
    $data=array(
        "ids"=>$yid,
        "orderState"=>0,
        "type"=>"courseStatus",
        "Connection: keep-alive"
    );
    $header=["token:$token","apiVersion:1.7"];
    $result=post($url,$data,$header);
    $result = json_decode($result, true);
    if ($result["code"] == "200") {
        $b = array("code" => 1, "msg" => "补刷成功");
    } else {
        $b = array("code" => - 1, "msg" => $result["msg"]);
    }
    return $b;
}    
        
        
        
        
        
        
        
        
        //以下接口已跑路//以下接口已跑路//以下接口已跑路//以下接口已跑路//以下接口已跑路//以下接口已跑路//以下接口已跑路
        
        
        
        
        
	//老张补刷
	else if ($type == "laozhang") {
		$lz_url = "https://api-new.2c3c.cn/api.php?act=budan&id={$yid}";
		$result = get_url($lz_url);
		$result = json_decode($result, true);
		if($result['code']=='0'){
        		$b=array("code"=>1,"msg"=>$result['msg']);	
    		}else{				
				$b=array("code"=>-1,"msg"=>$result['msg']);		
			}			
			return $b;      
	} 

	//欧巴虚假补刷	
	else if($type == "ouba") {
	    
	    $result["code"] = 0;
          if ($result["code"] == 0) {
					$b = array("code" => 1, "msg" => "操作成功,等待管理员后台处理");
				} else if($result["code"] == 1){
				    $b = array("code" => 1, "msg" => "订单完成无需操作，有问题联系管理");
				} else {
					$b = array("code" => -1, "msg" => "接口异常，请联系管理员");
				}
	  return $b;   
	    
	    
	}


	
	
	
	
	
	//001下单接口  
	else if ($type == "oo1") {
		$data = array(
			'token' => $token,
			'platform' => $noun,
			'school' => $school,
			'account' => $user,
			'password' => $pass,
			'coursename' => $kcname
		);
		$result = get_url("http://{$a['url']}/order", $data);
		$result = json_decode($result, true);
		if ($result['code'] == '0') {
			$b = array("code" => 1, "msg" => $result['msg']);
		} else {
			$b = array("code" => -1, "msg" => $result['msg']);
		}
		return $b;
	}
	//o1  大冰
	else if ($type == "o1") {
		$data = array(
			'token' => $token,
			'platform' => $noun,
			'school' => $school,
			'account' => $user,
			'password' => $pass,
			'coursename' => $kcname
		);
		$result = get_url("http://{$a['url']}/order", $data);
		$result = json_decode($result, true);
		if ($result['code'] == '0') {
			$b = array("code" => 1, "msg" => $result['msg']);
		} else {
			$b = array("code" => -1, "msg" => $result['msg']);
		}
		return $b;
	}



}
