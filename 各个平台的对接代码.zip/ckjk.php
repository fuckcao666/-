<?php
// 查课接口设置
function getWk($type, $noun, $school, $user, $pass, $name = false)
{
    global $DB;
    global $wk;
    $a = $DB->get_row("select * from qingka_wangke_huoyuan where hid='{$type}' ");
    $type = $a["pt"];
    $cookie = $a["cookie"];
    $token = $a["token"];
    //27查课接口
    if ($type == "27") {
        $data = array("uid" => $a["user"], "key" => $a["pass"], "school" => $school, "user" => $user, "pass" => $pass, "platform" => $noun, "kcid" => $kcid);
        $eq_rl = $a["url"];
        $er_url = "$eq_rl/api.php?act=get";
        $result = get_url($er_url, $data);
        $result = json_decode($result, true);
        return $result;
    }
    
    
    
    
    //kin查课
    else if ($type == "wang") {
        $data = array(array('PlatformID' => $noun, 'school' => $school, 'username' => $user, 'password' => $pass));
        
        
        $data=json_encode($data);
        $header = array('Content-Type: application/json', "Cookie: $cookie", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36");
        $base_url=$a['url'];
        $url = "http://$base_url/api/Order/GetClass";
        $back = post($url, $data, $header);
        
        $backjs = json_decode($back, true);
        if ($backjs['code'] != 0) {
            $b = ["code" => - 1, 'msg' => "信息错误或者重试"];
        } else {
            $req = $backjs['obj'][0]['data'];
            $courseList = [];
            foreach ($req as $k) {
                $courseList[] = ['id' => $k['id'], 'name' => $k['title'], 'planProgress' => $k['planProgress']];
            }
            $b = ['code' => 0, 'msg' => '查询成功', 'data' => $courseList];
        }
        return $b;
    
    } else if ($type == "NB") {
        $data = array("uid" => $a["user"], "key" => $a["pass"], "school" => $school, "user" => $user, "pass" => $pass, "platform" => $noun);
        $eq_rl = $a["url"];
        $er_url = "$eq_rl/api.php?act=get";
        $result = get_url($er_url, $data);
        $result = json_decode($result, true);
        return $result;
    }
    else if ($type == "oligei") {
   $data = array("token" => $token,"school" => $school, "user" => $user, "pass" => $pass, "ptid" => $noun);
  $oligei_rl = $a["url"];
  $oligei_url = "$oligei_rl/api_koufei/query";

  $result1 = get_url($oligei_url, $data);
  $result = json_decode($result1, true);
  if ($result["code"] == 1 ) {
      $courseList = $result["data"]; 
      foreach($courseList as $key => $value){
         $json_data[] = [
             'id' => $value['id'],
             'name' => $value['name'],
            ]; 
            }
                      $b = [
                        'code' => 0,
                        'msg' => '查询成功',
                        'data' => $json_data,
                    ]; 
  }elseif ($result["code"] == -1 ){
      $b = ["code" => -1, 'msg' => $result["msg"]];
        }else {
            // code...
            $b = ["code" => -1, 'msg' => '发送请求失败，请重试' ];
        }
 return $b;}

  else if ($type == "abab") {
        $data = array("account" => $user, "password" => $pass, "school" => "", "appId" => $noun);
        $data = json_encode($data);
        $header = array("Content-Type: application/json;charset=UTF-8", "Authorization: $token", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.42");
        $url = $a["url"];
        $ameng_url = "https://$url/api/searchCourse";
        $result = post($ameng_url, $data, $header);
        $result = json_decode($result, true);
        if ($result['code'] == 1) {
            $courseList = $result["courseList"];
            foreach ($courseList as $key => $value) {
                $json_data[] = [
                    'id' => $value['id'],
                    'name' => $value['name'],
                ];
            }
            $b  = [
                'code' => 0,
                'msg' => '查询成功',
                'data' => $json_data
            ];
        } else {
            $b = ["code" => -1, 'msg' => $data];
        }
        return $b;
    }
    //ab查课
    else if ($type == "abzj") {
        $data = array("account" => $user, "password" => $pass, "school" => "", "appId" => $noun, "schoolId" => "");
        $data = json_encode($data);
        $header = array("Content-Type: application/json;charset=UTF-8", "Authorization: $token", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.42");
        $url = $a["url"];
        $ameng_url = "https://$url/api/searchCourse";
        $result = post($ameng_url, $data, $header);
        $result = json_decode($result, true);
        if ($result['code'] == 1) {
            $courseList = $result["courseList"];
            foreach ($courseList as $key => $value) {
                $json_data[] = [
                    'id' => $value['id'],
                    'name' => $value['name'],
                ];
            }
            $b  = [
                'code' => 0,
                'msg' => '查询成功',
                'data' => $json_data
            ];
        } else {
            $b = ["code" => -1, 'msg' => "信息错误或者重试"];
        }
        return $b;
    } else if ($type == "nce") {
        //isUnit->是否秒刷
        $data = array("0" => array("PlatformID" => $noun, "isUnit" => false, "password" => $pass, "school" => 1, "username" => $user));
        $url = $a["url"];
        $ameng_url = "http://$url/api/Order/GetClass";
        $data = json_encode($data);
        $header = [
            "Accept: application/json, text/plain, */*",
            "Cookie: $cookie",
            "Accept-Language: zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
            "Content-Type: application/json",
            "Host: 3.nice-nice.top",
            "Origin: http://3.nice-nice.top",
            "Connection: keep-alive",
            "Referer: http://3.nice-nice.top/",
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36 Edg/106.0.1370.52"
        ];
        $result = post($ameng_url, $data, $header);
        $result = json_decode($result, true);
        if ($result['code'] == 0) {
            $courseList = $result['obj'][0]['data'];
            foreach ($courseList as $key => $value) {
                $json_data[] = [
                    'id' => $value['id'],
                    'name' => $value['title'],
                ];
            }
            $b  = [
                'code' => 0,
                'msg' => '查询成功',
                'data' => $json_data
            ];
        } else {

            $b = ["code" => -1, 'msg' => $data];
        }
        return $b;
    } 
    
    
  
    // 00查课接口  
    else if ($type == "003") {
        $data = array(
            "accountmsg" => ["$school $user $pass"],
            "token" => "$token",
            "value" => "$noun"
        );
        $data = json_encode($data, true);
        $header = array("Content-Type: application/json;charset=UTF-8", "cookie:$cookie", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.42");
        $url = $a["url"];
        $dandan_url = "http://$url/order/query/";
        $result = post($dandan_url, $data, $header);
        $result = json_decode($result, true);


        if ($result["code"] != 0) {
            $b = ["code" => -1, 'msg' => "信息错误或者重试"];
        } else {
            $courseList = $result["data"][0]["children"];

            foreach ($courseList as $key => $value) {

                $json_data[] = [
                    'id' => $value['value'],
                    'name' => $value['label'],
                ];
            }
            $b  = [
                'code' => 0,
                'msg' => '查询成功',
                'data' => $json_data
            ];
        }
        return $b;
    }





    //代理之家ck
    else if ($type == "dlzj") {
        $data = array("account" => $user, "password" => $pass, "platformId" => $noun);
        $url = $a['url'];
        $url = "http://$url/api/course/query.php";
        $header = ["token:$token", "apiVersion: 1.8", "Connection: keep-alive"];
        $result = get_url($url, $data, false, $header);
        $result = json_decode($result, true);
        if (!$result) jsonReturn(-1, "查课服务器出小差了，待会试试呗~");
        if ($result["code"] != 200) jsonReturn(-1, $result['msg']);
        $course = $result['data'];
        foreach ($course as $value) {
            if ($value['classId']) $id = $value['courseId'] . "|" . $value['classId'];
            else $id = $value['courseId'];
            $json[] = ['id' => $id, 'name' => $value['courseName']];
        }
        $b  = ['code' => 1, 'msg' => '查询成功', 'data' => $json];
        return $b;
    }


    //paolu查课接口
    else if ($type == "paolu") {
        $data = array("uid" => $a["user"], "key" => $a["pass"], "school" => $school, "user" => $user, "pass" => $pass, "platform" => $noun);
        $eq_rl = $a["url"];
        $er_url = "$eq_rl/api.php?act=get";
        $result = get_url($er_url, $data);
        $result = json_decode($result, true);
        return $result;
    }
    //无名学习平台查课接口
    //无名学习平台查课接口
    else if ($type == "wuming") {
        $data = array("uid" => $a["user"], "key" => $a["pass"], "platform" => $noun,  "user" => $user, "pass" => $pass, "school" => $school, "kcid" => $kcid);
        $wm_rl = $a["url"];
        $wm_url = "$wm_rl/api.php?act=get";
        $result = get_url($wm_url, $data);
        $result = json_decode($result, true);
        return $result;
    }
    //学习通官方查课接口
    else if ($type == "xxtgf") {
        $url = $_SERVER['HTTP_HOST'];
        $gf_url = "http://$url/Checkorder/xxtgf.php?school=$school&name=$user&pwd=$pass";
        $result = file_get_contents($gf_url);
        $result = json_decode($result, true);
        return $result;
    }
    //白白查课
    else if ($type == "bb") {
        $data = array("school" => $school, "user" => $user, "pass" => $pass, "cid" => $noun, "api_token" => $token);
        $fk_urla = $a["url"];
        $fk_url = "http://$fk_urla/api.php/lm/get";
        $result = get_url($fk_url, $data, $cookie);
        $result = json_decode($result, true);

        if ($result["code"] == 1) {
            $courseList = $result['data'];
            foreach ($courseList as $key => $value) {
                $json_data[] = [
                    'id' => "",
                    'name' => $value['name'],
                ];
            }
            $b  = [
                'code' => 1,
                'msg' => '查询成功',
                'data' => $json_data,

            ];
        } else {
            $b = array("code" => -1, "msg" => $result["msg"]);
        }
        return $b;
    }

    //跑路查课
    else if ($type == "bbpl") {
        $data = array("school" => $school, "user" => $user, "pass" => $pass, "cid" => $noun);
        $fk_urla = $a["url"];
        $fk_url = "http://$fk_urla/api.php/lm/get";
        $result = get_url($fk_url, $data, $cookie);
        $result = json_decode($result, true);

        if ($result["code"] == 1) {
            $courseList = $result['data'];
            foreach ($courseList as $key => $value) {
                $json_data[] = [
                    'id' => "",
                    'name' => $value['name'],
                ];
            }
            $b  = [
                'code' => 1,
                'msg' => '查询成功',
                'data' => $json_data,

            ];
        } else {
            $b = array("code" => -1, "msg" => $result["msg"]);
        }
        return $b;
    }








    
}
