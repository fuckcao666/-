<?php
function processCx($oid)
{
    global $DB;
    $d = $DB->get_row("select * from qingka_wangke_order where oid='{$oid}' ");
    $b = $DB->get_row("select hid,user,pass from qingka_wangke_order where oid='{$oid}' ");
    $a = $DB->get_row("select * from qingka_wangke_huoyuan where hid='{$b["hid"]}' ");
    $type = $a["pt"];
    $cookie = $a["cookie"];
    $token = $a["token"];
    $ip = $a["ip"];
    $user = $b["user"];
    $pass = $b["pass"];
    $kcname = $d["kcname"];
    $school = $d["school"];
    $pt = $d["noun"];
    $kcid = $d["kcid"];

    if ($type == "ameng") {
        if (!empty($yid))
            $data = array("token" => $token, "id" => $yid);
        else
            $data = array("token" => $token, "ptid" => $pt, "account" => $user, "password" => $pass, "kcname" => $kcname);
        $url = $a['url'];
        $ameng_url = "http://api.$url/api.php?act=query";
        $result = get_url($ameng_url, $data);
        $result = json_decode($result, true);
        if ($result["code"] == 1) {
            foreach ($result["data"] as $row) {
                $yid = $row['id'];
                $status = $row['status'];
                $progress = $row['progress'] . "%";
                $process = $row['process'];
                $kcjs = $row["courseEndTime"];
                $ksks = $row["examStartTime"];
                $ksjs = $row["examEndTime"];
            }
            if ($process == '') $process = "暂无详情";
            $b[] = array("code" => 1, "msg" => "查询成功", "yid" => $yid, "kcname" => $kcname, "user" => $user, "pass" => $pass, "ksks" => $ksks, "ksjs" => $ksjs, "status_text" => $status, "process" => $progress, "remarks" => $process);
        } else {
            $b[] = array("code" => -1, "msg" => "查询失败,请联系管理员");
        }
        return $b;
    }

    //00 虚假进度接口
    else if ($type == "abab") {
        $result["code"] == 0;
        if ($result["code"] == 0) {
            $b[] = array("code" => 1, "msg" => "查询成功", "yid" => 8888, "kcname" => $kcname, "user" => $user, "pass" => $pass, "school" => $school, "status_text" => "已完成", "status" => "已完成", "ksks" => $ksks, "ksjs" => $ksjs, "process" => "已经加入服务器", "remarks" => "正在努力完成中，有问题先看下单说明");
        } else {
            $b[] = array("code" => -1, "msg" => "查询失败,请联系管理员");
        }
        return $b;
    } elseif ($type == "NB") {
        $data = array("username" => $user);
        $eq_rl = $a["url"];
        $eq_url = "$eq_rl/api.php?act=chadan";
        $result = get_url($eq_url, $data);
        $result = json_decode($result, true);
        if ($result["code"] == "1") {
            foreach ($result["data"] as $res) {
                $yid = $res["id"];
                $kcname = $res["kcname"];
                $status = $res["status"];
                $statusjd = $res["status"];
                $process = $res["process"];
                $remarks = $res["remarks"];
                $kcks = $res["courseStartTime"];
                $kcjs = $res["courseEndTime"];
                $ksks = $res["examStartTime"];
                $ksjs = $res["examEndTime"];

                if (in_array($status, ["等待学习", "正在学习", "等待考试",])) $status = "进行中";
                if (in_array($status, ["完成学习"])) $status = "已完成";
                $b[] = array("code" => 1, "msg" => "查询成功", "yid" => $yid, "kcname" => $kcname, "user" => $user, "pass" => $pass, "ksks" => $ksks, "ksjs" => $ksjs, "status_text" => $status, "process" => "$statusjd $process", "remarks" => $remarks);
            }
        } else {
            $b[] = array("code" => -1, "msg" => "查询失败,请联系管理员");
        }
        return $b;
    }
    //ab进度
    else if ($type == "abzj") {

        $url = "https://abab.app/api/searchStudyOrder?pageNum=10&account=$user";
        $header = ["authorization:$token", "Content-Type:application/json;charset=UTF-8"];
        $result = get_url($url, false, false, $header);
        $result = json_decode($result, true);
        if ($result["code"] == 1) {
            foreach ($result["data"]["list"] as $res) {
                $yid = $res["orderId"];
                $url2 = "https://abab.app/api/getTask?orderId=$yid";
                $result2 = get_url($url2, false, false, $header);
                $result2 = json_decode($result2, true);
                foreach ($result2["data"] as $res2) {
                    $kcname = $res2["courseName"];
                    //   $process = $res2["percent"];
                    $process = $res2["progress"];
                    $status_text = $res2["status"];
                    $yid = $res2["taskId"];
                    $statusjd = "";



                    if (in_array($status_text, ["等待上号", "课程章节未开始，等待中", "排队中 (防止多门课同时刷)", "刷课中,请耐心等待.", "刷课中..",])) $statusjd = "进行中";
                    if (in_array($status_text, ["登录失败 用户名或密码错误", "课程带锁,等待适配"])) $statusjd = "异常中";
                    if (in_array($status_text, ["已完成刷课! (若有问题请联系客服)"])) $statusjd = "已完成";
                    if (in_array($status_text, ["无法匹配课程: $kcname ", "等待课程开课"])) $statusjd = "异常";

                    $b[] = array(
                        "code" => 0,
                        "msg" => "查询成功",
                        "yid" => $yid,
                        "kcname" => $kcname,
                        "studentname" => $studentname,
                        "user" => $user,
                        "pass" => $pass,
                        "ksks" => $ksks,
                        "ksjs" => $ksjs,
                        "status" => $status_text,
                        "status_text" => $statusjd,
                        "process" =>  $process,
                        //   "process" =>  "当前进度：$process%，当前分数：$examstatus分", 
                        "remarks" => "$status_text"
                    );
                }
            }
        } else {
            $b[] = array("code" => -1, "msg" => "查询失败,请联系管理员");
        }
        return $b;
    }

    //00进度
    else if ($type == "003") {
        usleep(500);
        $url = $a["url"];
        $url = "http://$url/order/list/?page=1&limit=10&token=$token&querytext=$user&querytype=%E8%B4%A6%E5%8F%B7";
        $header = [
            "cookie:$cookie",
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.71 Safari/537.36 Core/1.94.175.400 QQBrowser/11.1.5155.400",
            "Referer: http://$url/",
            "Origin:http://$url",
            "X-Token:$token",
        ];
        $result = get_url($url, false, false, $header);
        $result = json_decode($result, true);
        if ($result["code"] == "0") {
            foreach ($result["data"]["items"] as $res) {
                if ($kcname == $res['coursename']) {
                    $yid = $res["id"];
                    $kcname = $res["coursename"];
                    $status = $res["status"];
                    // $statusjd = $res["status"];
                    $process = $res["percent"] . "%";
                    // $remarks = $res["extra"];
                    $remarks = $res["statusdetail"];
                    $kcks = $res["courseStartTime"];
                    $kcjs = $res["endtime"];
                    $ksks = $res["examstarttime"];
                    $ksjs = $res["examendtime"];
                    $statusprocess = $res["status"];
                    $examstart = $res["examstart"];
                    if (in_array($status, ["待上号", "上号中", "1:1安排视频中", "平时分", "待考试",])) $status = "进行中";
                    if (in_array($status, ["密码错误", "单元格式错误", "未激活", "需验证码",])) $status = "异常";
                    $b[] = array("code" => 1, "msg" => "查询成功", "yid" => $yid, "kcname" => $kcname, "user" => $user, "pass" => $pass, "ksjs" => $ksjs, "status_text" => $status, "process" =>  "$process $statusprocess", "remarks" => $remarks);
                }
            }
        } else {
            $b[] = array("code" => -1, "msg" => "查询失败，请重试");
        }
        return $b;
    }
     //King进度
    else if ($type == "wang") {
        function https_get($ur1, $cookie) {
            $ch = curl_init($ur1);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array("Cookie:" . $cookie));
            $response = curl_exec($ch);
            curl_close($ch);
            return $response;
        }
        $base_url=$a["url"];
        $address = "http://$base_url/";
        $result = https_get($address . "api/Order/myOrderV2?username=$account&pageSize=20&pageIndex=1", $cookie);
        $result = json_decode($result, true);
        if ($result["code"] == 0) {
            foreach ($result["data"] as $res) {
                $yid = $res["id"];
                $name = $res["name"];
                $kcname = $res["className"];
                $status = $res["runstatus"];
                $processA='';
                if ($status == "0") {
                    $processA = '已提交';
                    $status = '进行中';
                }
                 elseif ($status == "1") {
                    $processA = '未提交';
                    $status = '已完成';
                }
                 elseif ($status == "2") {
                    $processA = '上号ing';
                    $status = '进行中';
                }
                elseif ($status == "5") {
                    $processA = '已登录';
                    $status = '进行中';
                }
                 elseif ($status == "7") {
                    $processA = '课程ing';
                    $status = '进行中';
                } elseif ($status == "8") {
                    $processA = '今日课件已完成';
                    $status = '进行中'; //已完成
                
                } elseif ($status == "9") {
                    $processA = '待考试';
                    $status = '进行中'; //已完成
                }
                elseif ($status == "12") {
                    $processA = '重刷ing';
                    $status = '补刷中';
                }
                elseif ($status == "16") {
                    $processA = '作业ing';
                    $status = '进行中';
                }
                elseif ($status == "20") {
                    $processA = '已完成';
                    $status = '已完成'; //已完成
                }
                // elseif ($status == 7) $status = "课程进行中";
                // elseif ($status == 8) $status = "今日课程已完成";
                // elseif ($status == 12) $status = "重刷";
                // elseif ($status == 16) $status = "作业中";
                // elseif ($status == 20) $status = "已全部完成";
                // else $status = "等待考试";
                $process = $res["job"]==null?100:$res["job"];
                $remarks = $res["statusdetail"];
                $kcjs = $res["endtime"];
                $ksks = $res["examstart"];
                $ksjs = $res["examend"];
                $examstatus = $res["examstatus"];
                $updatetime = $res["updateTime"];
                $b[] = array("code" => 1, "msg" => "查询成功", "yid" => $yid, "name" => $name, "kcname" => $kcname, "user" => $user, "pass" => $pass, "kcjs" => $kcjs, "ksks" => $ksks, "ksjs" => $ksjs, "status_text" => $status, "process" => "$processA $process", "remarks" => "$remarks  $examstatus 更新time：$updatetime");
            }
        } else {
            $b[] = array("code" => - 1, "msg" => "查询失败，请重试");
        }
        return $b;
    }
    // 	
     else if ($type == "kingxdd") {
        $url = $a["url"];
        $url = "http://$url/api/Order/myOrderV2?username=$user&pageSize=20&pageIndex=1";
        $header = [
            "Accept: application/json, text/plain, */*",
            "Cookie: $cookie",
            "Accept-Language: zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
            "Content-Type: application/json",
            "Host: www.nice-nice.top",
            "Origin: http://www.nice-nice.top",
            "Proxy-Connection: keep-alive",
            "Referer: http://www.nice-nice.top/", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36 Edg/106.0.1370.34"
        ];
        $result = get_url($url, false, false, $header);
        $result = json_decode($result, true);
        if ($result["code"] == "0") {
            foreach ($result["data"] as $res) {
                $uptime = $res['updateTime'];
                $status = $res['runstatus'];
                $remarks = '';
                $yid = $res['id'];

                if ($status == "0") {
                    $remarks = '订单提交';
                    $status = '进行中';
                } elseif ($status == "1") {
                    $remarks = '1';
                    $status = '已完成';
                } elseif ($status == "2") {
                    $remarks = '准备上号';
                    $status = '进行中';
                } elseif ($status == "3") {
                    $remarks = '登录失败';
                    $status = '异常中';
                } elseif ($status == "4") {
                    $remarks = '密码错误';
                    $status = '异常中';
                } elseif ($status == "5") {
                    $remarks = '已登陆';
                    $status = '进行中';
                } elseif ($status == "6") {
                    $remarks = '课程不存在';
                    $status = '异常中';
                } elseif ($status == "7") {
                    $remarks = '课程ing';
                    $status = '进行中';
                } elseif ($status == "8") {
                    $remarks = '课程finish,知到则习惯分ing';
                    $status = '已完成'; //已完成
                } elseif ($status == "9") {
                    $remarks = '待考试';
                    $status = '待考试';
                } elseif ($status == "10") {
                    $remarks = '考试中';
                    $status = '进行中';
                } elseif ($status == "11") {
                    $remarks = '';
                    $status = '已完成';
                } elseif ($status == "12") {
                    $remarks = '重刷中';
                    $status = '进行中';
                } elseif ($status == "13") {
                    $remarks = '13';
                    $status = '进行中';
                } elseif ($status == "14") {
                    $remarks = '含主观题';
                    $status = '异常中';
                } elseif ($status == "15") {
                    $remarks = '15';
                    $status = '已完成'; //已完成
                } elseif ($status == "16") {
                    $remarks = '作业中';
                    $status = '异常中';
                } elseif ($status == "18") {
                    $remarks = '18';
                    $status = '已完成'; //已完成
                } elseif ($status == "20") {
                    $remarks = '20';
                    $status = '已完成'; //已完成
                }


                $b[] = array("code" => 1, "msg" => "查询成功", "yid" => $yid, "kcname" => $kcname, "user" => $user, "pass" => $pass, "status_text" => $status, "process" => $remarks, "remarks" => '');
            }
        } else {
            $b[] = array("code" => -1, "msg" => "查询失败,请联系管理员");
        }
        return $b;
    }





    //27同步状态接口
    else if ($type == "27") {
        $data = array("username" => $user);
        $eq_rl = $a["url"];
        $eq_url = "$eq_rl/api.php?act=chadan";
        $result = get_url($eq_url, $data);
        $result = json_decode($result, true);
        if ($result["code"] == "1") {
            foreach ($result["data"] as $res) {
                $yid = $res["id"];
                $kcname = $res["kcname"];
                $status = $res["status"];
                $statusjd = $res["status"];

                $process = $res["process"];
                $remarks = $res["remarks"];
                $kcks = $res["courseStartTime"];
                $kcjs = $res["courseEndTime"];
                $ksks = $res["examStartTime"];
                $ksjs = $res["examEndTime"];

                if (in_array($status, ["待上号", "上号中", "1:1安排视频中", "平时分", "待考试",])) $status = "进行中";
                if (in_array($status, ["密码错误", "单元格式错误", "未激活", "需要验证", "需验证码"])) $status = "异常";


                $b[] = array("code" => 1, "msg" => "查询成功", "yid" => $yid, "kcname" => $kcname, "user" => $user, "pass" => $pass, "ksks" => $ksks, "ksjs" => $ksjs, "status_text" => $status, "process" => "$statusjd $process", "remarks" =>  $remarks);
            }
        } else {
            $b[] = array("code" => -1, "msg" => "查询失败,请联系管理员");
        }
        return $b;
    }
   

 
    //跑路同步状态接口
    else if ($type == "paolu") {
        $data = array("username" => $user);
        $eq_rl = $a["url"];
        $eq_url = "$eq_rl/api.php?act=chadan";
        $result = get_url($eq_url, $data);
        $result = json_decode($result, true);
        if ($result["code"] == "1") {
            foreach ($result["data"] as $res) {
                $yid = $res["id"];
                $kcname = $res["kcname"];
                $status = $res["status"];
                $process = $res["process"];
                $remarks = $res["remarks"];
                $kcks = $res["courseStartTime"];
                $kcjs = $res["courseEndTime"];
                $ksks = $res["examStartTime"];
                $ksjs = $res["examEndTime"];
                if (in_array($status, ["已提取"])) $status = "进行中";
                if (in_array($status, ["失败"])) $status = "异常中";
                if (in_array($status, ["失败"])) $process = "失败";



                $b[] = array("code" => 1, "msg" => "查询成功", "yid" => $yid, "kcname" => $kcname, "user" => $user, "pass" => $pass, "ksks" => $ksks, "ksjs" => $ksjs, "status_text" => $status, "process" => $process, "remarks" => $remarks);
            }
        } else {
            $b[] = array("code" => -1, "msg" => "查询失败,请联系管理员");
        }
        return $b;
    }
    //无名学习平台进度
    else if ($type == "wuming") {
        $data = array("user" => $user);
        $wm_rl = $a["url"];
        $wm_url = "$wm_rl/api.php?act=chadan";
        $result = get_url($wm_url, $data);
        $result = json_decode($result, true);
        if ($result["code"] == "1") {
            foreach ($result["data"] as $res) {
                $yid = $res["id"];
                $kcname = $res["kcname"];
                $status = $res["status"];
                $process = $res["process"];
                $remarks = $res["remarks"];
                $kcks = $res["courseStartTime"];
                $kcjs = $res["courseEndTime"];
                $ksks = $res["examStartTime"];
                $ksjs = $res["examEndTime"];
                $b[] = array("code" => 1, "msg" => "查询成功", "yid" => $yid, "kcname" => $kcname, "user" => $user, "pass" => $pass, "ksks" => $ksks, "ksjs" => $ksjs, "status_text" => $status, "process" => "$process", "remarks" => $remarks);
            }
        } else {
            $b[] = array("code" => -1, "msg" => "查询失败,请联系管理员");
        }
        return $b;
    }

    //白白进度
    else if ($type == "bb") {
        $data = array("uid" => "3401", "user" => $user, "kcname" => $kcname, "cid" => $pt, "pass" => $pass);
        $lm_ul = $a["url"];
        $lm_dingdan = "http://$lm_ul/api.php/lm/getcourse";
        $result = get_url($lm_dingdan, $data, $cookie);
        $result = json_decode($result, true);
        if ($result["code"] == 0) {
            $status = $result["data"]["status"];
            if ($status == 1) {
                $status = "已完成";
            } else {
                $status = "进行中";
            }
            $yid = $result["data"]["id"];
            $process = $result["data"]["process"];
            $b[] = array("code" => 1, "msg" => "查询成功", "yid" => $yid, "kcname" => $kcname, "user" => $user, "pass" => $pass, "ksks" => $ksks, "kcid" => 1, "ksjs" => $ksjs, "status_text" => "$status",  "updatetime" => $updatetime, "process" => "$process $remarks", "remarks" => '', "status" => "$status");
        } else {
            $b[] = array("code" => -1, "msg" => "查询失败,请重试");
        }
        return $b;
    }

    //白白进度
    else if ($type == "bbpl") {
        $data = array("uid" => "4074", "user" => $user, "kcname" => $kcname, "cid" => $pt, "pass" => $pass);
        $lm_ul = $a["url"];
        $lm_dingdan = "http://$lm_ul/api.php/lm/getcourse";
        $result = get_url($lm_dingdan, $data, $cookie);
        $result = json_decode($result, true);
        if ($result["code"] == 0) {
            $status = $result["data"]["status"];
            if ($status == 1) {
                $status = "已完成";
            } else {
                $status = "进行中";
            }
            $yid = $result["data"]["id"];
            $process = $result["data"]["process"];
            $b[] = array("code" => 1, "msg" => $result, "yid" => $yid, "kcname" => $kcname, "user" => $user, "pass" => $pass, "ksks" => $ksks, "kcid" => 1, "ksjs" => $ksjs, "status_text" => "$status",  "updatetime" => $updatetime, "process" => "$process $remarks", "remarks" => '', "status" => "$status");
        } else {
            $b[] = array("code" => -1, "msg" => "查询失败,请重试");
        }
        return $b;
    } 
    else if ($type == "oligei") {
  $data = array( "token" => $token,"user" => $user,"pass" => $pass,"kcname" => $kcname);
  $oligei_rl = $a["url"];
  $oligei_url = "$oligei_rl/api_koufei/order";
  $result = get_url($oligei_url, $data,$cookie);
  $result = json_decode($result, true);
  if ($result["code"] == "1") {
   foreach ($result["data"] as $res) {
    $yid = $res["id"];
    $kcname = $res["kcname"];
    $status = $res["status"];
    $process = $res["process"];
    $remarks = $res["remarks"];
    $kcks = $res["courseStartTime"];
    $kcjs = $res["courseEndTime"];
    $ksks = $res["examStartTime"];
    $ksjs = $res["examEndTime"];
    /*$process = "$process—$remarks";
    $remarks = '';*/
    if(strpos($status,"完成")){
        $status='已完成';
        }elseif(strpos($status,"安排")){
            $status='进行中';
        }elseif(strpos($status,"上号")){
            $status='进行中';
        }elseif(strpos($status,"重刷")){
            $status='进行中';}

    $b[] = array("code" => 1, "msg" => "查询成功", "yid" => $yid, "kcname" => $kcname, "user" => $user, "pass" => $pass, "kcks" => $kcks, "kcjs" => $kcjs, "ksks" => $ksks, "ksjs" => $ksjs, "status_text" => $status, "process" => $process, "remarks" => $remarks);
   }
  } else {
   $b[] = array("code" => -1, "msg" => "查询失败,请重试");
  }
  return $b;}
    elseif ($type == "dlzj") {
        $data = array("currentPage" => 1, "pageSize" => 10, "username" => $user, "password" => $pass, "courseName" => $kcname);
        $data = json_encode($data);
        $url = $a['url'];
        $url = "http://$url/api/order/list.php";
        $header = ["Content-Type: application/json;charset=UTF-8", "token:$token", "apiVersion:1.8", "Connection: keep-alive"];
        $result = post($url, $data, $header);
        $result = json_decode($result, true);
        if (!$result) jsonReturn(-1, "进度服务器出小差了，待会试试呗~");
        if ($result["code"] != 200) jsonReturn(-1, $result['msg']);
        foreach ($result['data']['records'] as $res) {
            $status_text = $res['courseStatus'];
            if ($status_text == 0) $status = "待处理";
            $progress = 0;
            if ($status_text == 1) $status = "进行中";
            $progress = 0;
            if ($status_text == 2) $status = "已完成";
            $progress = 100;
            if ($status_text == 3) $status = "异常中";
            $progress = 0;
            $process = $res['msg'];
            $yid = $res['id'];
        }
        $b[] = array("code" => 1, "msg" => "查询成功", "yid" => $yid, "kcname" => $kcname, "user" => $user, "pass" => $pass, "status_text" => $status, "process" => $progress, "remarks" => $process);
        return $b;
    }




}
