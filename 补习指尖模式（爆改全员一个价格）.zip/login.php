<script>
    window.location.href='/admin/login.php';
</script>