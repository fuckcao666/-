<?php
/**
 * 登录
**/

if($conf['cdnpublic']==1){
	$cdnpublic = '//lib.baomitu.com/';
}elseif($conf['cdnpublic']==2){
	$cdnpublic = '//cdn.bootcss.com/';
}elseif($conf['cdnpublic']==4){
	$cdnpublic = '//s1.pstatp.com/cdn/expire-1-M/';
}else{
	$cdnpublic = '//cdn.staticfile.org/';
}
if(!empty($conf['staticurl'])){
	$cdnserver = '//'.$conf['staticurl'].'/';
}else{
	$cdnserver = '../';
}
@header('Content-Type: text/html; charset=UTF-8');
$is_defend=true;
include("../includes/common.php");
if(isset($_GET['logout'])){
	if(!checkRefererHost())exit();
	setcookie("user_token", "", time() - 604800, '/');
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已成功注销本次登陆！');window.location.href='./login.php';</script>");
}elseif($islogin2==1){
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>");
}
?>
<!DOCTYPE html>
<html>

<head>
    <script>if (window !== top) top.location.replace(location.href);</script>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="./assets/images/favicon.ico" rel="icon">
    <title>用户登录</title>
     <link rel="stylesheet" href="/assets/layuiadmin/layui/css/layui.css" media="all">

</head>

<body>
 <style>
        body {
            background-image: url("https://api.btstu.cn/sjbz/api.php?lx=dongman&format=images");
            background-repeat: no-repeat;
            background-size: cover;
            min-height: 100vh;
        }

        body:before {
            content: "";
            background-color: rgba(0, 0, 0, .2);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
        }

        .login-wrapper {
            max-width: 420px;
            padding: 20px;
            margin: 0 auto;
            position: relative;
            box-sizing: border-box;
            z-index: 2;
        }

        .login-wrapper>.layui-form {
            padding: 25px 30px;
            background-color: #fff;
            box-shadow: 0 3px 6px -1px rgba(0, 0, 0, 0.19);
            box-sizing: border-box;
            border-radius: 4px;
        }

        .login-wrapper>.layui-form>h2 {
            color: #333;
            font-size: 18px;
            text-align: center;
            margin-bottom: 25px;
        }

        .login-wrapper>.layui-form>.layui-form-item {
            margin-bottom: 25px;
            position: relative;
        }

        .login-wrapper>.layui-form>.layui-form-item:last-child {
            margin-bottom: 0;
        }

        .login-wrapper>.layui-form>.layui-form-item>.layui-input {
            height: 46px;
            line-height: 46px;
            border-radius: 2px !important;
        }

        .login-wrapper .layui-input-icon-group>.layui-input {
            padding-left: 46px;
        }

        .login-wrapper .layui-input-icon-group>.layui-icon {
            width: 46px;
            height: 46px;
            line-height: 46px;
            font-size: 20px;
            color: #909399;
            position: absolute;
            left: 0;
            top: 0;
            text-align: center;
        }

        .login-wrapper>.layui-form>.layui-form-item.login-captcha-group {
            padding-right: 135px;
        }

        .login-wrapper>.layui-form>.layui-form-item.login-captcha-group>.login-captcha {
            height: 46px;
            width: 120px;
            cursor: pointer;
            box-sizing: border-box;
            border: 1px solid #e6e6e6;
            border-radius: 2px !important;
            position: absolute;
            right: 0;
            top: 0;
        }

        .login-wrapper>.layui-form>.layui-form-item>.layui-form-checkbox {
            margin: 0 !important;
            padding-left: 25px;
        }

        .login-wrapper>.layui-form>.layui-form-item>.layui-form-checkbox>.layui-icon {
            width: 15px !important;
            height: 15px !important;
        }

        .login-wrapper>.layui-form .layui-btn-fluid {
            height: 48px;
            line-height: 48px;
            font-size: 16px;
            border-radius: 2px !important;
        }

        .login-wrapper>.layui-form>.layui-form-item.login-oauth-group>a>.layui-icon {
            font-size: 26px;
        }

        .login-copyright {
            color: #eee;
            padding-bottom: 20px;
            text-align: center;
            position: relative;
            z-index: 1;
        }

        @media screen and (min-height: 550px) {
            .login-wrapper {
                margin: -250px auto 0;
                position: absolute;
                top: 50%;
                left: 0;
                right: 0;
                width: 100%;
            }

            .login-copyright {
                position: absolute;
                bottom: 0;
                right: 0;
                left: 0;
            }
        }

        .layui-btn {
            background-color: #5FB878;
            border-color: #5FB878;
        }

        .layui-link {
            color: #5FB878 !important;
        }

        .layui-input {
            border-top: none;
            border-left: none;
            border-right: none;
        }

        .layui-input:hover,
        .layui-textarea:hover {
            border-color: #00a65a !important;
        }
    </style>
    <div class="login-wrapper layui-anim layui-anim-scale">
        <form class="layui-form">
            <h2>登录</h2>
            <div class="layui-form-item layui-input-icon-group">
                <i class="layui-icon layui-icon-username"></i>
                <input class="layui-input" id="yyb_username" type="text" name="user" value=""  required="required" placeholder="　用户名"/ style="">
            </div>
            <div class="layui-form-item layui-input-icon-group">
                <i class="layui-icon layui-icon-password"></i>
                <input class="layui-input" id="yyb_password" type="password"  name="pass"  required="required" placeholder="　密码"/  style="display: inline;">
            </div>
            <div class="layui-form-item">
          
                <a href="/user/findpwd.php" class="layui-link">忘记密码</a>
                <a href="/user/reg.php" class="layui-link pull-right" style="float: right;">注册账号</a>
            </div>
            <div class="layui-form-item">
                <button class="layui-btn layui-btn-fluid" type="button" value="立即登陆" id="submit_login">登录</button>
            </div>
        </form>
    </div>
    <!-- js部分 -->
 <script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
        <script src="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="<?php echo $cdnpublic?>layer/2.3/layer.js"></script>
        <script src="../assets/js/login.js?ver=<?php echo VERSION ?>"></script>
  
</body>

</html>