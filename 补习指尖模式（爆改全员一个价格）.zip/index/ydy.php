<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>晨宇网络</title>
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<style>
body{
    background-image: url('https://pro.bkbk.club/index/707070.png');padding: 2% 5% 5% 5%;">--> 
    /*background: url("https://wx4.sinaimg.cn/mw2000/007hgDa3ly1h1aoyterc2j32yo1o0140.jpg");*/
}
/*.bg{*/
/*     background-image: url('123.png'); */
/*}*/
</style>
</head>

<script>
    function tz(){
       alert('xyz')
    }
</script>
<!--<body style="background-image: linear-gradient(to right,#d6ff7f,#cb5eee);padding: 12% 5% 5% 5%;">-->
<body>
    <div class="bg">
         <!--<img src="123.png">-->
    
    
    <div style="text-align:center;border-width:1px;border-style:solid;border-color:rgb(2, 204, 245);background-color:(to right,#a6c1ee,#fbc2eb);border-radius:20px;">
        
    <h1 style="color:#ffffff;"><strong><font size="7">请保存或收藏晨宇网络地址发布页(klhh.cloud和woaicc.icu和woaicc.top)！</font></strong></h1>
    <p style="font-size:2vh;color:#ff79bc;"><strong>记得将(klhh.cloud和woaicc.icu和woaicc.top)收藏到浏览器里 方便您下次打开</strong></p>

    <p style="line-height:4;">        
        <a style="border-radius:10px;padding:7px 30px;color:#ff5595;border-style:solid;text-decoration:none;"
           ><strong><span id="url2_title1"><font size="5">进入晨宇网站</font></span></a></strong>
        <br>
               <a style="border-radius:10px;padding:7px 30px;color:#ff5595;border-style:solid;text-decoration:none;"
           ><strong><span id="url2_title2"><font size="5" >进入晨宇小站(速度最快)</font></span></a></strong>
        <br>
        <p style="line-height:4;">        
        <a style="border-radius:10px;padding:7px 30px;color:#ff5595;border-style:solid;text-decoration:none;"
           ><strong><span id="url2_title3"><font size="5">进入晨宇小站(联通最快)</font></span></a></strong>
        <br> 
          <a style="border-radius:10px;padding:7px 30px;color:#ff5595;border-style:solid;text-decoration:none;"
           ><strong><span id="url2_title4"><font size="5">进入晨宇小站(移动最快)</font></span></a></strong>
        <br> 
           <p style="line-height:4;">        
        <a style="border-radius:10px;padding:7px 30px;color:#ff5595;border-style:solid;text-decoration:none;"
           href="https://chenyucd.top/"><strong><span id="url2_title"><font size="5">热门查单/补单地址</font></span></a></strong>
        <br>
        <p style="line-height:4;">        
        <a style="border-radius:10px;padding:7px 30px;color:#ff5595;border-style:solid;text-decoration:none;"
           href="https://klhh.work/"><strong><span id="url2_title2"><font size="5">冷门查单/补单地址</font></span></a></strong>
        <br>
        <!--   <p style="line-height:4;">        -->
        <!--<a style="border-radius:10px;padding:7px 30px;color:#ff5595;border-style:solid;text-decoration:none;"-->
        <!--   href="https://xiaozhancd.cloud/"><strong><span id="url2_title"><font size="5">热门软件查单地址</font></span></a></strong>-->
        <!--<br>-->
        <!--<p style="line-height:4;">        -->
        <!--<a style="border-radius:10px;padding:7px 30px;color:#ff5595;border-style:solid;text-decoration:none;"-->
        <!--   href="https://xiaozhancd.xyz/"><strong><span id="url2_title"><font size="5">冷门软件查单地址</font></span></a></strong>-->
        <!--<br>-->
    <div id="result"></div>
    </p><p style="color:#fff;">

  
       
    <a style="text-decoration:none;color:#ff79bc;" href=""><strong><font size="4">2015-2022 © 晨宇网络</font></strong>
    </a>

    </p>
</div>


</div>
<script src="//cdn.staticfile.org/jquery/1.12.4/jquery.min.js"></script>
<script src="//cdn.staticfile.org/jquery.lazyload/1.9.1/jquery.lazyload.min.js"></script>
<script src="//cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="//cdn.staticfile.org/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="//cdn.staticfile.org/layer/2.3/layer.js"></script>

<script>

  //在看吗？嗯嗯，输入你的域名，下面4个，nb

    $("#url2_title1").click(function(){
        url('woaicc.xyz');
    })
     $("#url2_title2").click(function(){
        url('woaicc.site');
    })
    $("#url2_title3").click(function(){
        url('woaicc.store');
    })
     $("#url2_title4").click(function(){
        url('woaicc.shop');
    })
    



    function url(a){
       var qz=0;
        for(var i=0;i<10;i++){
             qz=qz+'a'+randomNum(1,100);
        }
        window.open("http://"+qz+"."+a,"_blank");
    }
    function randomNum(minNum,maxNum){ 
    switch(arguments.length){ 
        case 1: 
            return parseInt(Math.random()*minNum+1,10); 
        break; 
        case 2: 
            return parseInt(Math.random()*(maxNum-minNum+1)+minNum,10); 
        break; 
            default: 
                return 0; 
            break; 
    } 
} 
</script>

</body>
</html>