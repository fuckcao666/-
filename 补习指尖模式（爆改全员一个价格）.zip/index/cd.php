<?php
$title='课程查询';
$mod='blank';
require_once('head.php');
?>
<link rel="stylesheet" href="assets/css/element.css">
<!DOCTYPE html>
<html lang=en>
<head>
<meta charset=utf-8>
<meta http-equiv=X-UA-Compatible content="IE=edge">
<meta name=viewport content="width=device-width,initial-scale=1">
<meta name="referrer" content="no-referrer"/>
<link href=//pro.bkbk.club/index/assets/lz/app.js rel=modulepreload as=script>
<link href=//pro.bkbk.club/index/assets/lz/chunk.js rel=modulepreload as=script>
</head>
<body>
<noscript>
<strong>We're sorry but wangke doesn't work properly without JavaScript enabled. Please enable it to continue.</strong>
</noscript>
<div id="content" class="lyear-layout-content" role="main">
<div class="app-content-body ">
<div id=app>
</div>
</div>
</div>
<script type=module src=//pro.bkbk.club/index/assets/lz/chunk.js>
</script>
<script type=module src=//pro.bkbk.club/index/assets/lz/ui.js>
</script>
<script>!function(){var e=document,t=e.createElement("script");if(!("noModule"in t)&&"onbeforeload"in t){var n=!1;e.addEventListener("beforeload",function(e){if(e.target===t)n=!0;else if(!e.target.hasAttribute("nomodule")||!n)return;e.preventDefault()},!0),t.type="module",t.src=".",e.head.appendChild(t),t.remove()}}();</script>
<script src=//pro.bkbk.club/index/assets/lz/chunk.js nomodule>
</script>
<script src=//pro.bkbk.club/index/assets/lz/app.js nomodule>
</script>
<script type="text/javascript" src="assets/LightYear/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/main.min.js"></script>
<script src="assets/js/aes.js"></script>
<br>
<center>
<h5>
<div style="color:red">本页面查询进度并非实时进度，具体以登录app查询为准！<br>如挤登后务必需要到本页面操作一下补单。<br>下单后如果查不到订单请等待几小时后查询<br>漏课程请咨询下单网站客服<br>请勿无脑补单 提交次数过多并不会有啥翻倍效果<br>如果补单后10分钟还没效果请再试一次</div>
</h5>
</center>
<div style="display:none">
<center>