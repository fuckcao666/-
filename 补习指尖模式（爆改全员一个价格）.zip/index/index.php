<?php
include('head.php');
$dd=$DB->count("select count(oid) from qingka_wangke_order where uid='{$userrow['uid']}' ");
?>

<div id="content" class="lyear-layout-content" role="main">
	<div class="container-fluid" id="userindex">
     	<div class="wrapper-md control" >

<style>
    .suxjia{
            box-shadow: 18px 18px 30px #d1d9e6, -18px -18px 30px #fff;

    }
</style>

<body>
<script src="https://cdn.bootcss.com/sweetalert/2.1.0/sweetalert.min.js"></script>
</body>


<div class="row">
          <div class="col-sm-6 col-lg-3" style="padding-right: 10px;">
            <div class="card bg-primary" data-toggle="modal" data-target="#myModal" style="border-radius: 8px; box-shadow: 18px 18px 30px #d1d9e6, -18px -18px 30px #fff; ">
              <div class="card-body clearfix">
                <div class="pull-right">
                  
                  <p class="h6 text-white m-t-0">账户余额</p>
                  <p class="h4 text-white m-b-0">{{row.money}}</p>
                </div>
                <div class="pull-left"> 
                <div class="img-avatar img-avatar-48 bg-translucent"> 
                   <svg  style=" height: 2em; width:2em; margin-left:10px;margin-top:10px;color:#fff;" aria-hidden="true"><use xlink:href="#icon-qianbao"></use></svg></div>
                  </div>
              </div>
            </div>
          </div>
          
          <div class="col-sm-6 col-lg-3" style="padding-right: 10px;">
            <div class="card bg-danger" style="border-radius: 8px; box-shadow: 18px 18px 30px #d1d9e6, -18px -18px 30px #fff;">
              <div class="card-body clearfix">
                <div class="pull-right">
                  <p class="h6 text-white m-t-0">好友总数</p>
                  <p class="h4 text-white m-b-0">{{row.dailitongji.dlzs}}人</p>
                </div>
                <div class="pull-left"> <div class="img-avatar img-avatar-48 bg-translucent"> 
                   <svg  style=" height: 2em; width:2em; margin-left:10px;margin-top:10px;color:#fff;" aria-hidden="true"><use xlink:href="#icon-tuandui1"></use></svg></div>
                  </div>
              </div>
            </div>
          </div>
          
          <div class="col-sm-6 col-lg-3" style="padding-right: 10px;">
            <div class="card bg-success" style="border-radius: 8px; box-shadow: 18px 18px 30px #d1d9e6, -18px -18px 30px #fff;">
              <div class="card-body clearfix">
                <div class="pull-right">
                       <!--a href="myprice"><span class="el-tag el-tag--mini el-tag--light" style="position: absolute;
    bottom: 25%;right: 25px;">查看</span></a-->
                  <p class="h6 text-white m-t-0">我的等级</p>
                  <!--p class="h4 text-white m-b-0">{{row.addprice}}</p-->
                  <p class="h4 text-white m-b-0">三好学生</p>
                </div>
                <div class="pull-left"> <div class="img-avatar img-avatar-48 bg-translucent"> 
                   <svg  style=" height: 2em; width:2em; margin-left:10px;margin-top:10px;color:#fff;" aria-hidden="true"><use xlink:href="#icon-VIP"></use></svg></div>
                  </div>
              </div>
            </div>
          </div>
          
          <div class="col-sm-6 col-lg-3" style="padding-right: 10px;">
            <div class="card bg-purple" style="border-radius: 8px; box-shadow: 18px 18px 30px #d1d9e6, -18px -18px 30px #fff;">
              <div class="card-body clearfix">
                <div class="pull-right">
                  <p class="h6 text-white m-t-0">补习总数</p>
                  <p class="h4 text-white m-b-0">{{row.dd}} 门</p>
                </div>
                <div class="pull-left"> <div class="img-avatar img-avatar-48 bg-translucent"> 
                   <svg  style=" height: 2em; width:2em; margin-left:10px;margin-top:10px;color:#fff;" aria-hidden="true"><use xlink:href="#icon-wodemaidan1"></use></svg></div>
                  </div>
              </div>
            </div>
          </div>
        </div>


			<div class="row">
			    <div class="col-lg-6">
            <div class="card" style="    box-shadow: 18px 18px 30px #d1d9e6, -18px -18px 30px #fff;
    border-radius: 8px;">
              <div class="card-header">
                <h4>项目管理</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-hover">
                   
                   
                      
                     
                     <li class="list-group-item">
                         <svg aria-hidden="true" class="flex"><use  xlink:href="#icon-licai"></use></svg>
                     <span class="malet">总充值</span><span class="badge label label-success">{{row.zcz==null?'0':row.zcz}}&nbsp;</span></li>
                     
   			         <!--li class="list-group-item"  > 
   			          <svg aria-hidden="true" class="flex"><use  xlink:href="#icon-huiyuan1"></use></svg>
   			         <span class="malet">邀请注册等级</span><span class="badge label label-info" @click="szyqprice">设置</span><span class="badge label label-warning">{{row.yqprice==''?'无':row.yqprice}} </li-->
   			         
   			         <li class="list-group-item"  > 
   			          <svg aria-hidden="true" class="flex"><use  xlink:href="#icon-zhengjian"></use></svg>
   			         <span class="malet">我的邀请码</span><span class="badge label label-danger">邀请码：{{row.yqm==''?'无':row.yqm}}</span> </li>
		             
		             <li class="list-group-item" href="">			             
				               	<span v-if="row.qq_openid==''" class="badge label label-dark" @click="connect_qq">立即绑定</span>
				               	<span v-else class="badge bg-danger" @click="layer.alert('为了账号安全，一经绑定不允许解绑，需要解绑请联系管理员',{icon:3})">解绑</span>
				               	 <svg aria-hidden="true" class="flex"><use  xlink:href="#icon-xiaoshuai"></use></svg>
			                <span class="malet">QQ绑定</span>
			         </li>	
			         
			         <li class="list-group-item"  > 
			          <svg aria-hidden="true" class="flex"><use  xlink:href="#icon-lizhishenqing"></use></svg>
			         <span class="malet">今日好友注册</span><span class="badge label label-secondary">{{row.dailitongji.dlzc}}人</span> </li>
			         <li class="list-group-item"  >
			              <svg aria-hidden="true" class="flex"><use  xlink:href="#icon-renlizhaopin"></use></svg>
			              <span class="malet">今日好友登录</span><span class="badge label label-purple">{{row.dailitongji.dldl}}人</span> </li>
			         <!--<li class="list-group-item"  > -->
			         <!-- <svg aria-hidden="true" class="flex"><use  xlink:href="#icon-hetong"></use></svg>-->
			         <!--<span class="malet">今日好友学习</span><span class="badge label label-cyan">{{row.dailitongji.dlxd}}门</span> </li>-->
			         
			         <li class="list-group-item" v-if="row.uid==1" > 
			          <svg aria-hidden="true" class="flex"><use  xlink:href="#icon-hetong"></use></svg>
			         <span class="malet">今日消耗</span><span class="badge label label-cyan">&yen;			                
			                <?php
			                	$a=$DB->query("select * from qingka_wangke_order where addtime>'$jtdate'  ");			                	
			                	  while($c=$DB->fetch($a)){
									  	 $zcz+=$c['fees'];
									}			                	
			                	echo $zcz;		                		                	
			                 ?>	学时</span> </li>
			            </div>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
			    
			    
			    
				<div class="col-sm-6">
		          <div class="card" style="    box-shadow: 18px 18px 30px #d1d9e6, -18px -18px 30px #fff;
    border-radius: 8px;">
		            <div class="card-header">						
			              <div class="clearfix">
			                <a class="pull-left thumb-md avatar  m-r">												  
			                  <img src="https://q2.qlogo.cn/headimg_dl?dst_uin=<?=$userrow['user'];?>&spec=100" style="border:0px;" class="img-circle" alt="User Image" />
			                </a>							
			                <div class="clear">
			                  <div v-if="row.nickname==''" class="h5 m-t-xs"><?=$conf['sitename'];?></div>								
			                  <div v-else class="h5 m-t-xs">{{row.nickname}}</div>							  
			                  <div class="text-muted">
							    <span style="color:red;">UID: {{row.uid}}</span>（{{row.user}}）<br> 	
							    <span style="color:green">KEY:</span>&nbsp;<span v-if="row.key==0">未开通API接口<button @click="ktapi" class="btn btn-xs " style="background-color: rgb(112, 136, 239); border-radius: 5px; color: rgb(255, 255, 255); margin-left: 20px;">开通</button></span><span v-else="">{{row.key}}</span>								
							  </div>						  
			                </div>
			              </div>			              
			        </div>
		          </div>
		           </div>
		       
		         
		         
		         
			  
							
						
							
						
						
					<div class="col-md-6">
            <div class="card">
             
              <div class="card-body" style="padding:0px;    box-shadow: 18px 18px 30px #d1d9e6, -18px -18px 30px #fff;    border-radius: 8px;
">
                
                <ul class="nav nav-tabs nav-justified active">
                    
                    
                    
                  <li class="" style="float:left;width:50%;">
                    <a data-toggle="tab" href="#messages-basic" aria-expanded="true">系统公告</a>
                  </li>
                
                  <li class="nav-item " style="float:right;width:50%;">
                    <a data-toggle="tab" href="#settings-basic" aria-expanded="false">上级公告</a>
                  </li>
                </ul>
                <div class="tab-content">
                  
                  <div class="tab-pane fade active in" id="messages-basic">
                 <p v-html="row.notice"></p>
                  </div>
                  <div class="tab-pane fade " id="settings-basic">
                    
                  <p v-html="row.sjnotice"></p>
                    <br>
                   <center>
                     <button class="btn btn-xs " style="border:0px ;    background-color: #934bfa;color:#fff;" @click="szgg()">设置</button>
                     </center>
                  </div>
                </div>
                
              </div>
            </div>
          </div><div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="display: none;">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                        <h4 class="modal-title" id="myModalLabel">充值余额</h4>
                      </div>
                      <div class="modal-body">
                      请联系您的上级QQ {{this.row.sjuser}}，进行充值。
                      </div>
                         <div class="modal-footer">
                        <button type="button" class="el-button el-button--default el-button--small" data-dismiss="modal">取消</button>
                        <button type="button" class="el-button el-button--default el-button--small el-button--primary " style="border:0px;background-color:#7366ff;" data-dismiss="modal" @click="layer.msg('好的，靓仔')">知道了</button>
                    </div>
                    </div>
                  </div>
                </div>	
						 
				</div>			
            </div>
       </div>
    </div>
</div>
   


<script type="text/javascript" src="assets/LightYear/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/main.min.js"></script>
<script src="assets/js/aes.js"></script>
<script src="https://cdn.staticfile.org/vue/2.6.11/vue.min.js"></script>
<script src="https://cdn.staticfile.org/vue-resource/1.5.1/vue-resource.min.js"></script>
<script src="https://cdn.staticfile.org/axios/0.18.0/axios.min.js"></script>
<script src="assets/js/sy.js"></script>



<script src="shuiyin.js"></script>
<script type="text/javascript">
 var now = getNow();
 watermark({"watermark_txt":"内部用户：uid:<?=$userrow['uid'];?>"});  
</script>




   
</html>






        <script type="text/javascript">

		    var vm=new Vue({
		     	el: "#userindex",
		    	data: {
		      		row:null,
		      		inte:'',
		        },
		      	methods:{
		    		userinfo:function(){
		    			var load=layer.load();
		     			this.$http.post("/apisub.php?act=userinfo")
				          .then(function(data){	
				          	   	layer.close(load);
				          	if(data.data.code==1){			                     	
				          		this.row=data.data			             			                     
				          	}else{
				                layer.alert(data.data.msg,{icon:2});
				          	}
				          });	
		    		},
		    		yecz:function(){
		    			layer.alert('请联系您的上级QQ：'+this.row.sjuser+'，进行充值。（好友点充值，此处将显示您的QQ）',{icon:1,title:"温馨提示"});
		    		},
		    		ktapi:function(){
		    			layer.confirm('后台余额满300学时可免费开通，反之需花费10学时开通', {title:'温馨提示',icon:1,
							  btn: ['确定','取消'] //按钮
							}, function(){
							  		var load=layer.load();
					     			axios.get("/apisub.php?act=ktapi&type=1")
							          .then(function(data){	
							          	   	layer.close(load);
							          	if(data.data.code==1){			                     	
	    			                        layer.alert(data.data.msg,{icon:1,title:"温馨提示"},function(){setTimeout(function(){window.location.href=""});});							          				             			                     
							          	}else{
							                layer.msg(data.data.msg,{icon:2});
							          	}
							        });	
							
						    });
		    	    },
		    	    szyqprice:function(){		    	    	
						layer.prompt({title: '设置好友默认等级，首次自动生成邀请码', formType: 3}, function(yqprice, index){
						  layer.close(index);
						  var load=layer.load();
			              $.post("/apisub.php?act=yqprice",{yqprice},function (data) {
					 	     layer.close(load);
				             if (data.code==1){
				             	vm.userinfo();  
				                layer.alert(data.msg,{icon:1});
				             }else{
				                layer.msg(data.msg,{icon:2});
				             }
			              });		    		    
					  });
		    	    },
		    	    connect_qq:function(){
		    	    	    var ii = layer.load(0, {shade:[0.1,'#fff']});
							$.ajax({
								type : "POST",
								url : "../apisub.php?act=connect",
								data : {},
								dataType : 'json',
								success : function(data) {
									layer.close(ii);
									if(data.code == 0){
										window.location.href = data.url;
									}else{
										layer.alert(data.msg, {icon: 7});
									}
								} 
							});	
		    	  },szgg:function(){
		    	  		layer.prompt({title: '设置代理公告，您的代理可看到', formType: 2}, function(notice, index){
						  layer.close(index);
						  var load=layer.load();
			              $.post("/apisub.php?act=user_notice",{notice},function (data) {
					 	     layer.close(load);
				             if (data.code==1){
				             	vm.userinfo();  
				                layer.msg(data.msg,{icon:1});
				             }else{
				                layer.msg(data.msg,{icon:2});
				             }
			              });		    		    
					  });   	  	
		    	  }
		    	
		     	},
		     	mounted(){
		     		this.userinfo();
		     		
		     	}
		      });
		  
       </script>
