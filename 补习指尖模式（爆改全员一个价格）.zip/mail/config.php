<?php
$dbconfig=array(
	'host' => 'localhost', //数据库服务器
	'port' => 3306, //数据库端口
	'user' => 'youxiang', //数据库用户名
	'pwd' => '3sf64NYtP6skfYZL', //数据库密码
	'dbname' => 'youxiang', //数据库名
	'dbqz' => 'mail' //数据表前缀
);
