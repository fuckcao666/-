<?php
include('../confing/common.php');
?>
<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
  <title><?=$conf['sitename']?></title>
  <meta name="keywords" content="<?=$conf['keywords'];?>" />
  <meta name="description" content="<?=$conf['description'];?>" />
<link rel="icon" href="assets/LightYear/favicon.ico" type="image/ico">
<meta name="author" content="qingka">


<link rel="stylesheet" href="../assets/css/bootstrap.css" type="text/css" />
<link rel="stylesheet" href="../assets/css/app.css" type="text/css" />
<link rel="stylesheet" href="../assets/layui/css/layui.css" type="text/css" />
<link href="assets/LightYear/css/materialdesignicons.min.css" rel="stylesheet">
<!--<link href="assets/LightYear/css/ion-rangeslider/ion.rangeSlider.min.css" rel="stylesheet"/>-->
<link href="assets/LightYear/css/style.min.css" rel="stylesheet"/>


  

<script src="../assets/js/bootstrap.min.js"></script>
<script src="//lib.baomitu.com/jquery/1.12.4/jquery.min.js"></script>
<script src="//cdn.staticfile.org/layer/2.3/layer.js"></script>
<link rel="stylesheet" href="/assets/elm/element.css">
 <link rel="stylesheet" type="text/css" href="https://element.eleme.cn/docs.10df231.css">
<link rel="stylesheet" href="https://element.eleme.cn/element-ui.91647e9.css">
<link href="./assets/css/tailwind.min.css" rel="stylesheet">
<script src="https://at.alicdn.com/t/font_1185698_xknqgkk0oph.js?spm=a313x.7781069.1998910419.40&file=font_1185698_xknqgkk0oph.js"></script>

 

  

  
</head>
<style type="text/css">
    .susuicon {
        position: absolute;
    left: 21px;
    top: 14px;
       width: 1.3em; height: 1.3em;
       vertical-align: -0.15em;
       fill: currentColor;
       overflow: hidden;
    }
     .susuicon2 {
     position: absolute;
    top: 50%;
    right: 20px;
    margin-top: -7px;
    transition: transform .3s;
       width: 1.1em; height: 1.1em;
       vertical-align: -0.15em;
       fill: currentColor;
       overflow: hidden;
    }
    .flex{height: 2em; width: 2em;   vertical-align: -0.15em;
       fill: currentColor;float:left; position: absolute;
    bottom: 7px;
    left: 5px;
       overflow: hidden;}
       
       .flex2{height: 1.4em; width: 1.4em;   vertical-align: -0.15em;
       fill: currentColor;float:left;margin-top:2px;margin-right: 5px;
       overflow: hidden;}
       .malet{padding-left:20px;font-size:11px;}
    .nav>li:hover{
        background-color: #f8f8ff;
    }
    hr {
    height: 1px;
    margin: 4px;
        
    }
    
    
    .frosss{    height: 38px;
    border-radius: 8px !important; border: 2px solid rgb(236, 236, 236);
    border-color: #ebebeb;
    -webkit-border-radius: 2px;
    border-radius: 2px;
    padding: 5px 12px;
    line-height: inherit;
    -webkit-transition: 0.2s linear;
    transition: 0.2s linear;
    -webkit-box-shadow: none;
    box-shadow: none;}
      .frosss2{ 
           border-radius: 8px !important; border: 2px solid rgb(236, 236, 236);
           display: block;
    width: 100%;
          height: 38px;
    border-color: #ebebeb;
    -webkit-border-radius: 2px;
    border-radius: 2px;
    padding: 5px 12px;
    line-height: inherit;
    -webkit-transition: 0.2s linear;
    transition: 0.2s linear;
    -webkit-box-shadow: none;
    box-shadow: none;}
    .table>thead>tr>th {
    padding: 20px;
<?php
if($userrow['uid']==287){
}elseif($userrow['active']=="0"){
alert('您的账号已被封禁！','login');
}
?>
<body>
<div class="lyear-layout-web">
  <div class="lyear-layout-container">
    <!--左侧导航-->
    <aside class="lyear-layout-sidebar">
      
      <!-- logo -->
      <div id="logo" class="sidebar-header">
        <a href="index.php"><center><img style="border:0px;" src="../assets/images/buxi.gif" title="LightYear" alt="LightYear" /></center></a>
      </div>
      <div class="lyear-layout-sidebar-scroll"> 
        
        <nav class="sidebar-main">
          <ul class="nav nav-drawer">
          	
		            <li class="nav-item "> 
			            <a href="index">
			               <svg class="susuicon" aria-hidden="true"><use xlink:href="#icon-shouye"></use></svg> 首页</a> 
			            </li>
			     
			     <?php if($userrow['uid']==1){ ?>		  				           

			  <li class="nav-item nav-item-has-subnav">
              <a href="javascript:void(0)"><svg class="susuicon" aria-hidden="true"><use xlink:href="#icon-shezhi1"></use></svg> 后台设置 <svg class="susuicon2" aria-hidden="true"><use xlink:href="#icon--xia"></use></svg></a>
              <ul class="nav nav-subnav" style="display: none;">
                <li> <a href="webset" >系统配置</a></li>
                <li> <a href="huoyuan">接口配置</a></li>
                <li> <a href="class">网课设置</a></li>
                <li> <a href="mijia">密价设置</a></li>
                <li class="active"> <a href="data">数据统计</a></li>
                <li> <a href="pro">专业版价格</a></li>
              </ul>
            </li>
			      <?php } ?>   
			            
			            
			    <li class="nav-item nav-item-has-subnav">
              <a href="javascript:void(0)"><svg class="susuicon" aria-hidden="true"><use xlink:href="#icon-fasong"></use></svg> 开始学习 <svg class="susuicon2" aria-hidden="true"><use xlink:href="#icon--xia"></use></svg></a>
              <ul class="nav nav-subnav" style="display: none;">
                <li> <a href="add2" >普通补习</a></li>
                <!--<li> <a href="add">名师补习</a></li>-->
                <li> <a href="add_pl">批量补习</a></li>
                <li> <a href="help">疑点解答</a></li>
              </ul>
            </li> 
			            
		     <!-- <li class="nav-item "> -->
		     <!--<a href="add2">-->
       <!--      <svg class="susuicon" aria-hidden="true"><use xlink:href="#icon-fasong"></use></svg> 普通补习</a> -->
       <!--     </li>-->
       <!--     <li class="nav-item "> -->
       <!--     <a href="add">-->
       <!--     <svg class="susuicon" aria-hidden="true"><use xlink:href="#icon-fasong"></use></svg> 名师补习</a> -->
       <!--     </li>-->

            <li class="nav-item"> 
            <a href="list">
           <svg class="susuicon" aria-hidden="true"><use xlink:href="#icon-gengduo"></use></svg>我的作业</a> 
            </li>

            <li class="nav-item"> 
            <a href="userlist">
            <svg class="susuicon" aria-hidden="true"><use xlink:href="#icon-wode1"></use></svg>我的好友</a> 
            </li>
            <li class="nav-item"> 
            <a href="log">
            <svg class="susuicon" aria-hidden="true"><use xlink:href="#icon-anquan"></use></svg> 学习日志</a> 
            </li>
            <li class="nav-item"> 
            <a href="myprice">
           <svg class="susuicon" aria-hidden="true"><use xlink:href="#icon-gouwu"></use></svg> 课程列表</a> 
            </li>
            
            <li class="nav-item"> 
            <a href="workorder">   
           <svg class="susuicon" aria-hidden="true"><use xlink:href="#icon-hetong"></use></svg> 课程反馈</a> 
            </li>
            
            <li class="nav-item"> 
            <a href="docking">
            <svg class="susuicon" aria-hidden="true"><use xlink:href="#icon-hezuo"></use></svg> 平台对接</a> 
            </li>
            
           <li class="nav-item"> 
            <a href="charge">
            <svg class="susuicon" aria-hidden="true"><use xlink:href="#icon-xiaoxi1"></use></svg>在线充值</a> 
            </li>
            
            <!--<li class="nav-item"> -->
            <!--<a href="help">-->
            <!--<svg class="susuicon" aria-hidden="true"><use xlink:href="#icon-shoucang1"></use></svg>疑点解答</a> -->
            <!--</li>-->
            
          <!--<li class="nav-item"> -->
          <!--  <a href="cqq.html">-->
          <!--  <i class="glyphicon glyphicon-comment"></i>站长微语</a> -->
          <!--  </li> -->
          </ul>
        </nav>
        
        <div class="sidebar-footer">
          <p class="copyright">Copyright &copy; 2017-2021. <a target="_blank" href=""><?php echo $conf["title"] ?></a></p>
        </div>
      </div>
      
    </aside>
    <!--End 左侧导航-->
    
    <!--头部信息-->
    <header class="lyear-layout-header">
      
      <nav class="navbar navbar-default">
        <div class="topbar">
          
          <div class="topbar-left">
            <div class="lyear-aside-toggler">
              <span class="lyear-toggler-bar"></span>
              <span class="lyear-toggler-bar"></span>
              <span class="lyear-toggler-bar"></span>
            </div>
            <span class="navbar-page-title"> <?php echo $title;?> </span>
          </div>
          
  
         
        
          
        <ul class="topbar-right">
            <li class="dropdown dropdown-profile">
              <a href="javascript:void(0)" data-toggle="dropdown">
                  <img class="img-avatar img-avatar-48 m-r-10" style="border-radius: 8px;width:40px;height:40px;border:0px;" src="https://q2.qlogo.cn/headimg_dl?dst_uin=<?=$userrow['user'];?>&spec=100" >
                  
                <span><?php echo $userrow['user']?><span class="caret"></span></span>
                <!--<img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $userrow['user'];?>&spec=100" alt="Avatar" width="45" alt="avatar" style="height: auto filter: alpha(Opacity=80);-moz-opacity: 1;opacity: 1;" class="img-circle img-thumbnail img-thumbnail-avatar-1x animated zoomInDown">-->
              </a>
              <ul class="dropdown-menu dropdown-menu-right">
                <li> <a href="passwd.php"><i class="glyphicon glyphicon-wrench"></i> 修改密码</a> </li>
                <li> <a href="javascript:void(0)"><i class="glyphicon glyphicon-trash"></i> 清空缓存</a></li>
                <li class="divider"></li>
                <li> <a href="../apisub.php?act=logout"><i class="glyphicon glyphicon-log-out"></i> 退出登录</a> </li>
              </ul>
            </li>
          </ul>
          
        </div>
      </nav>
      
    </header>
    <!--End 头部信息-->
