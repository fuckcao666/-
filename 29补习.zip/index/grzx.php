<?php
$mod='blank';
$title='个人中心';
require_once('head.php');
?>

<div id="content" class="lyear-layout-content" role="main">
	<div class="container-fluid" id="userindex">
     	<div class="wrapper-md control" >

<style>
    .suxjia{
            box-shadow: 18px 18px 30px #d1d9e6, -18px -18px 30px #fff;

    }
</style>

<body>
<script src="https://cdn.bootcss.com/sweetalert/2.1.0/sweetalert.min.js"></script>
<!-- 引入样式 -->
<link rel="stylesheet" href="https://unpkg.com/element-ui/lib/theme-chalk/index.css">
<!-- 引入组件库 -->
<script src="https://unpkg.com/element-ui/lib/index.js"></script>
</body>

<div class="row">
		
		<!--个人信息--->
		<div class="col-lg-8">
            <div class="card" style="box-shadow: 18px 18px 30px #d1d9e6, -18px -18px 30px #fff;border-radius: 8px;">
                
                <div class="card-body">
                    
                    <template align="center">
                    <el-descriptions class="margin-top" title="用户信息" :column="1" border>
                        
                        <el-descriptions-item>
                            <template slot="label"><i class="el-icon-user"></i>UID / 账号</template>
                            <el-button style="width: 200px">{{row.uid}}</el-button><el-button style="width: 200px">{{row.user}}</el-button>
                        </el-descriptions-item>
                        
                        <el-descriptions-item>
                            <template slot="label"><i class="el-icon-user"></i>学时</template>
                            <el-button style="width: 200px">{{row.money}}</el-button>
                        </el-descriptions-item>
                        
                        <el-descriptions-item>
                            <template slot="label"><i class="el-icon-user"></i>代理总数</template>
                            <el-button style="width: 200px">{{row.dailitongji.dlzs}}人</el-button><el-button type="success" style="width: 200px"><a href="./daili">添加代理</a></el-button>
                        </el-descriptions-item>
                        
                        <el-descriptions-item>
                            <template slot="label"><i class="el-icon-user"></i>我的费率</template>
                            <el-button style="width: 200px">{{row.addprice}}</el-button>
                            <el-button v-if="row.addprice==0.2" style="width: 200px">等级：作者</el-button>
                            <el-button v-if="row.addprice==0.3" style="width: 200px">等级：研究生</el-button>
                            <el-button v-if="row.addprice==0.4" style="width: 200px">等级：本科</el-button>
                            <el-button v-if="row.addprice==0.5" style="width: 200px">等级：高中</el-button>
                            <el-button v-if="row.addprice==0.6" style="width: 200px">等级：初中</el-button>
                            <el-button v-if="row.addprice==0.7" style="width: 200px">等级：小学</el-button>
                            <el-button v-if="row.addprice>0.7" style="width: 200px">等级：幼儿园</el-button>
                        </el-descriptions-item>
                        
                        <el-descriptions-item>
                            <template slot="label"><i class="el-icon-user"></i>订单总数</template>
                            <el-button style="width: 200px">{{row.dd}}</el-button>
                        </el-descriptions-item>
                        
                        <el-descriptions-item>
                            <template slot="label"><i class="el-icon-user"></i>邀请码</template>
                            <el-button style="width: 200px">{{row.yqm==''?'无':row.yqm}}</el-button>
                        </el-descriptions-item>
                        
                        <el-descriptions-item>
                            <template slot="label"><i class="el-icon-user"></i>邀请注册等级</template>
                            <el-button style="width: 200px">{{row.yqprice==''?'无':row.yqprice}}</el-button>
                            <el-button type="success" style="width: 200px" @click="szyqprice">设置</el-button>
                        </el-descriptions-item>
                        
                        <el-descriptions-item>
                            <template slot="label"><i class="el-icon-user"></i>KEY</template>
                            <el-button style="width: 200px" v-if="row.key==0">未开通API接口</el-button>
                            <el-button style="width: 200px" v-else="">{{row.key}}</el-button>
                            <el-button style="width: 200px" type="success" @click="ktapi" v-if="row.key==0">开通API接口</el-button>
                        </el-descriptions-item>
                        
                        
                    </el-descriptions>
                    </template>  
                    
                </div>
            </div>
        </div>
        <!--/个人信息--->  
          
        <!--头像---
		<div class="col-lg-3">
		    <div class="card" style="    box-shadow: 18px 18px 30px #d1d9e6, -18px -18px 30px #fff;border-radius: 8px;">
		        <div class="card-header">						
		            <div class="clearfix">
		                <a class="pull-left thumb-md avatar  m-r">												  
		                <img src="https://q2.qlogo.cn/headimg_dl?dst_uin=123456789&spec=100" style="border:0px;" class="img-circle" alt="User Image" />
		                </a>
		            <div class="clear">
                        <div v-if="row.nickname==''" class="h5 m-t-xs">白猫管理系统</div>								
                            <div v-else class="h5 m-t-xs">{{row.nickname}}</div>							  
                                <div class="text-muted">
							        <span style="color:red;">UID: {{row.uid}}</span>（{{row.user}}）<br> 	
							        <span style="color:green">KEY:</span>&nbsp;<span v-if="row.key==0">未开通API接口<button @click="ktapi" class="btn btn-xs " style="background-color: rgb(112, 136, 239); border-radius: 5px; color: rgb(255, 255, 255); margin-left:20px;">开通</button>
							        </span>
							        <span v-else="">{{row.key}}</span>								
							    </div>						  
			                </div>
			              </div>			              
			        </div>
		    </div>
		</div>
		!--/头像--->
</div>			
    </div>
        </div>
            </div>


   
<script type="text/javascript" src="assets/LightYear/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/main.min.js"></script>
<script src="assets/js/aes.js"></script>
<script src="https://cdn.staticfile.org/vue/2.6.11/vue.min.js"></script>
<script src="https://cdn.staticfile.org/vue-resource/1.5.1/vue-resource.min.js"></script>
<script src="https://cdn.staticfile.org/axios/0.18.0/axios.min.js"></script>
<script src="assets/js/sy.js"></script>
<!-- 引入样式 -->
<link rel="stylesheet" href="https://unpkg.com/element-ui/lib/theme-chalk/index.css">
<!-- 引入组件库 -->
<script src="https://unpkg.com/element-ui/lib/index.js"></script>
<!--水印开关，其他页面可以复制过去-->
<script src="assets/js/sy.js"></script>
// <script type="text/javascript">
// var now = getNow();
// watermark({"watermark_txt":"simon"});
// </script>
<script>
  export default {
    data () {
      return {
        size: ''
      };
    }
  }
</script>

</html>
<script type="text/javascript">

		    var vm=new Vue({
		     	el: "#userindex",
		    	data: {
		      		row:null,
		      		inte:'',
		        },
		      	methods:{
		    		userinfo:function(){
		    			var load=layer.load();
		     			this.$http.post("/apisub.php?act=userinfo")
				          .then(function(data){	
				          	   	layer.close(load);
				          	if(data.data.code==1){			                     	
				          		this.row=data.data			             			                     
				          	}else{
				                layer.alert(data.data.msg,{icon:2});
				          	}
				          });	
		    		},
		    		yecz:function(){
		    			layer.alert('请联系您的上级QQ：'+this.row.sjuser+'，进行充值。（下级点充值，此处将显示您的QQ）',{icon:1,title:"温馨提示"});
		    		},
		    		ktapi:function(){
		    			layer.confirm('后台余额满300学时可免费开通，反之需花费10学时开通', {title:'温馨提示',icon:1,
							  btn: ['确定','取消'] //按钮
							}, function(){
							  		var load=layer.load();
					     			axios.get("/apisub.php?act=ktapi&type=1")
							          .then(function(data){	
							          	   	layer.close(load);
							          	if(data.data.code==1){			                     	
	    			                        layer.alert(data.data.msg,{icon:1,title:"温馨提示"},function(){setTimeout(function(){window.location.href=""});});							          				             			                     
							          	}else{
							                layer.msg(data.data.msg,{icon:2});
							          	}
							        });	
							
						    });
		    	    },
		    	    szyqprice:function(){		    	    	
						layer.prompt({title: '设置下级默认费率，首次自动生成邀请码', formType: 3}, function(yqprice, index){
						  layer.close(index);
						  var load=layer.load();
			              $.post("/apisub.php?act=yqprice",{yqprice},function (data) {
					 	     layer.close(load);
				             if (data.code==1){
				             	vm.userinfo();  
				                layer.alert(data.msg,{icon:1});
				             }else{
				                layer.msg(data.msg,{icon:2});
				             }
			              });		    		    
					  });
		    	    },
		    	    connect_qq:function(){
		    	    	    var ii = layer.load(0, {shade:[0.1,'#fff']});
							$.ajax({
								type : "POST",
								url : "../apisub.php?act=connect",
								data : {},
								dataType : 'json',
								success : function(data) {
									layer.close(ii);
									if(data.code == 0){
										window.location.href = data.url;
									}else{
										layer.alert(data.msg, {icon: 7});
									}
								} 
							});	
		    	  },szgg:function(){
		    	  		layer.prompt({title: '设置代理公告，您的代理可看到', formType: 2}, function(notice, index){
						  layer.close(index);
						  var load=layer.load();
			              $.post("/apisub.php?act=user_notice",{notice},function (data) {
					 	     layer.close(load);
				             if (data.code==1){
				             	vm.userinfo();  
				                layer.msg(data.msg,{icon:1});
				             }else{
				                layer.msg(data.msg,{icon:2});
				             }
			              });		    		    
					  });   	  	
		    	  }
		    	
		     	},
		     	mounted(){
		     		this.userinfo();
		     		
		     	}
		      });
		  
       </script>
<script>
var vm=new Vue({
	el:"#userlist",
	data:{
		row:null,
		type:'1',
		qq:'',
		storeInfo:{}
	},
	methods:{
		get:function(page){
		  var load=layer.load();
 			this.$http.post("/apisub.php?act=userlist",{type:this.type,qq:this.qq,page:page},{emulateJSON:true}).then(function(data){	
	          	layer.close(load);
	          	if(data.data.code==1){			                     	
	          		this.row=data.body;			             			                     
	          	}else{
	                layer.msg(data.data.msg,{icon:2});
	          	}
	        });	
		},
		form:function(form){
		   var load=layer.load();
 			this.$http.post("/apisub.php?act="+form,{data:$("#form-"+form).serialize()},{emulateJSON:true}).then(function(data){	
	          	layer.close(load);
	          	if(data.data.code==1){			                     		          		
	          		this.get(this.row.current_page);
	          		$("#modal-" + form).modal('hide');
	          		layer.msg(data.data.msg,{icon:1});	             			                     
	          	}else{
	                layer.msg(data.data.msg,{icon:2});
	          	}
	        });	
		},
		adduser:function(){
	           var load=layer.load();
               $.post("/apisub.php?act=adduser",{data:$("#form-adduser").serialize()},function (data) {
		 	     layer.close(load);
	             if (data.code==1){    				
					layer.confirm(data.msg, {
					  btn: ['确定开通','取消'],title:'开通扣费'  //按钮
					}, function(){
					    var load=layer.load();
			 			vm.$http.post("/apisub.php?act=adduser",{data:$("#form-adduser").serialize(),type:1},{emulateJSON:true}).then(function(data){	
				          	layer.close(load);
				          	if(data.data.code==1){
				          	    vm.get(this.row.current_page);
	          		            $("#modal-adduser").modal('hide');			                     		          		
				          		layer.alert(data.data.msg,{icon:1});	             			                     
				          	}else{
				                layer.msg(data.data.msg,{icon:2});
				          	}
				        });	   
					}, function(){

					});					  									            
	             }else{
	                layer.msg(data.msg,{icon:2});
	             }	              
            });              
		},
		cz:function(uid,name){
			layer.prompt({title: '你将为<font color="red">'+name+'</font>充值请输入充值 学时', formType: 3}, function(money, index){
			  layer.close(index);
			  var load=layer.load();
              $.post("/apisub.php?act=userjk",{uid:uid,money:money},function (data) {
		 	     layer.close(load);
	             if (data.code==1){
	             	vm.get(vm.row.current_page);	   
	                layer.alert(data.msg,{icon:1});
	             }else{
	                layer.msg(data.msg,{icon:2});
	             }
              });		    		    
		  });
		},
		gj:function(uid,name){
			layer.prompt({title: '你将为<font color="red">'+name+'</font>调整等级，请先看规则在操作', formType: 3}, function(addprice, index){
			  layer.close(index);
	           var load=layer.load();
               $.post("/apisub.php?act=usergj",{uid:uid,addprice:addprice},function (data) {
		 	     layer.close(load);
	             if (data.code==1){    				
					layer.confirm(data.msg, {
					  btn: ['确定改价并充值','取消'],title:'改价扣费'  //按钮
					}, function(){
					    var load=layer.load();
			 			vm.$http.post("/apisub.php?act=usergj",{uid:uid,addprice:addprice,type:1},{emulateJSON:true}).then(function(data){	
				          	layer.close(load);
				          	if(data.data.code==1){
				          	    vm.get(vm.row.current_page);		                     		          		
				          		layer.alert(data.data.msg,{icon:1});	             			                     
				          	}else{
				                layer.msg(data.data.msg,{icon:2});
				          	}
				        });	   
					}, function(){

					});					  									            
	             }else{
	                layer.msg(data.msg,{icon:2});
	             }	              
             });             
		  });		 
		},
		czmm:function(uid){
		    var load=layer.load();
 			vm.$http.post("/apisub.php?act=user_czmm",{uid:uid},{emulateJSON:true}).then(function(data){	
	          	layer.close(load);
	          	if(data.data.code==1){			                     		          		
	          		layer.alert(data.data.msg,{icon:1});	             			                     
	          	}else{
	                layer.msg(data.data.msg,{icon:2});
	          	}
	        });	              	 
		},ktapi:function(uid){
			layer.confirm('给代理开通API，将扣除5学时余额', {title:'温馨提示',icon:1,
				  btn: ['确定','取消'] //按钮
				}, function(){
				  		var load=layer.load();
		     			axios.get("/apisub.php?act=ktapi&type=2&uid="+uid)
				          .then(function(data){	
				          	   	layer.close(load);
				          	if(data.data.code==1){
				          		vm.get(vm.row.current_page);		                     	
		                        layer.alert(data.data.msg,{icon:1,title:"温馨提示"});							          				             			                     
				          	}else{
				                layer.msg(data.data.msg,{icon:2});
				          	}
				        });	
				
			    });
		},
		yqm:function(uid,name){
			layer.prompt({title: '你将为<font color="red">'+name+'</font>设置邀请码，邀请码最低4位数', formType: 3}, function(yqm, index){
			  layer.close(index);
	           var load=layer.load();
               $.post("/apisub.php?act=szyqm",{uid,yqm},function (data) {
		 	     layer.close(load);
	             if (data.code==1){
	             	vm.get(vm.row.current_page);		             	 
	                layer.alert(data.msg,{icon:1});	                
	             }else{
	                layer.msg(data.msg,{icon:2});
	             }	              
              });            
		  });		
		},ban:function(uid,active){
			var load=layer.load();
               $.post("/apisub.php?act=user_ban",{uid,active},function (data) {
		 	     layer.close(load);
	             if (data.code==1){
	             	vm.get(vm.row.current_page);		             	 
	                layer.msg(data.msg,{icon:1});	                
	             }else{
	                layer.msg(data.msg,{icon:2});
	             }	              
              });  
		}  
	},
	mounted(){
		this.get(1);
	}
});
</script>