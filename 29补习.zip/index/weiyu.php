<?php
$title='站长微语';
require_once('head.php');
?>
 
 

  <div class="lyear-layout-content" role="main">
     <div class="app-content-body ">
        <div class="wrapper-md control">
        	
        	 <div class="card">
            <li class="list-group-item card bg-warning text-white">				            	
                 2021-9-2： 永远不要忘了你最初的那份干劲，如果它正在减退，说明你即将出局，不忘初心，方得始终！
            </li>   		          
          </div>   
        	
           <div class="card">
            <li class="list-group-item">				            	
                 2021-6-17： 任何时候都可以开始做自己想做的事年龄从来不是界限，除非你自己拿来为难自己。
 
          </div>
                 	
          <div class="card">
            <li class="list-group-item">				            	
                 2021-6-11：  人要懂得珍惜时光，不能丢了白天的太阳，又丢了夜晚的星星。天道酬勤的意思是，越努力，越幸运。你若不相信努力和时光，时光第一个辜负你
            </li>   		          
          </div>
          
           <div class="card">
            <li class="list-group-item">				            	
                 2021-6-10：  只求“少丢分”，不说“得高分”!
            </li>   		          
          </div>         
         
    </div>
   </div>
 </div>
 

<script type="text/javascript" src="assets/LightYear/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/main.min.js"></script>
<script src="assets/js/aes.js"></script>
<script src="https://cdn.staticfile.org/vue/2.6.11/vue.min.js"></script>
<script src="https://cdn.staticfile.org/vue-resource/1.5.1/vue-resource.min.js"></script>
<script src="https://cdn.staticfile.org/axios/0.18.0/axios.min.js"></script>



  <script type="text/javascript">
    /* 鼠标特效 */
    var a_idx = 0;
    jQuery(document).ready(function($) {
        $("body").click(function(e) {
            var a = new Array("富强","民主","文明","和谐","自由","平等","公正","法治","爱国","敬业","诚信","友善");
            var $i = $("<span />").text(a[a_idx]);
            a_idx = (a_idx + 1) % a.length;
            var x = e.pageX
              , y = e.pageY;
            $i.css({
                "z-index": 999999999999999999999999999999999999999999999999999999999999999999999,
                "top": y - 20,
                "left": x,
                "position": "absolute",
                "font-weight": "bold",
                "color": "#ff6651"
            });
            $("body").append($i);
            $i.animate({
                "top": y - 180,
                "opacity": 0
            }, 1500, function() {
                $i.remove();
            });
        });
    });
</script>
	