<?php
$title='普通补习';
require_once('head.php');
$addsalt=md5(mt_rand(0,999).time());
$_SESSION['addsalt']=$addsalt;
?>
<link rel="stylesheet" href="assets/css/element.css">
 <div id="content" class="lyear-layout-content" role="main">
     <div class="app-content-body ">

        <div class="wrapper-md control" id="add">
	       <div class="panel panel-default" style="box-shadow: 8px 8px 15px #d1d9e6, -18px -18px 30px #fff; border-radius:8px;">
		    <div class="panel-heading font-bold " style="border-top-left-radius: 8px; border-top-right-radius: 8px;background-color:#fff;"><div style="height:20px;width:5px;background-color:#af92ff;float:left;border-radius:4px;margin-right: 5px;"></div>
		    <div style="float:right;margin-right:20px"><el-link type="primary"><a href="./add">点我切换批量查课</a><li class="el-icon-arrow-right"></li></el-link></div>
			    登记信息
		     </div>
				<div class="panel-body">
					<form class="form-horizontal devform">
						<div class="form-group">
							<label class="col-sm-2 control-label">补习类别</label>
								<div class="col-sm-9">
							<!--<select class="form-control" v-model="cid" @change="tips(cid);">-->
							<el-select id="select"  v-model="cid"  @change="tips(cid)" filterable placeholder="请先选择平台，输入可进行搜索" style="    background: url('../index/arrow.png') no-repeat scroll 99%;   width:100%">
                                    <el-option
                                    
                                      v-for="class2 in class1"
                                      :key="class2.cid"
                                      :label="class2.name+'('+class2.price+'学时)'"
                                      :value="class2.cid">
                                    </el-option>
                                  </el-select>					
							</div>
						</div>
						
						
						<div class="form-group" v-if="activems==true">
							<label class="col-sm-2 control-label" for="checkbox1">是否秒刷</label>
							<div class="col-sm-9">
								<div class="checkbox checkbox-success"  @change="tips2">
        				            <input type="checkbox" v-model="miaoshua">
        				            	<label for="checkbox1" id="miaoshua"></label>
							    </div>
							</div>							
						</div>
                        <!--单学时备注定位点  在下面的v-if里面按格式添加cid即可-->
                        <div class="form-group " v-if="nochake==1">
							<div class="col-sm-2 col-xs-3 control-label" style="margin-top:9px">份数</div>
							<div class="col-sm-9 col-xs-8">
							    <el-input-number v-model="shu" :min="1" :max="100"></el-input-number>
							</div>
							<div class="col-sm-2 col-xs-3 control-label" style="margin-top:9px">课程名称</div>
							<div class="col-sm-9 col-xs-8">
							    <el-input v-model="bei" placeholder="请输入要刷的课程" style="margin-top:9px"></el-input>
							</div>
						</div>
                        <!--单学时备注定位点-->
						<div class="form-group">
							<label class="col-sm-2 control-label">账号信息</label>
							<div class="col-sm-9">
						    <input  class="frosss2" v-model="userinfo" required/> 	
						    <span class="help-block m-b-none" style="color:red;" id="warning"> 
						    	下单格式：</br>学校 账号 密码 (空格分开) /  例如： 北京大学  13872325008   123456  </br>手机号 密码 (空格分开) /  例如：  13872325008   123456
						    </span>			
							</div>
						</div>
				  	    <div class="col-sm-offset-2" v-if="nochake==1">
				  	    	<button style="margin-left: 6px; font-size: 13px;" type="button" @click="add" value="立即提交" class="el-button el-button--primary is-plain"/><i class="glyphicon glyphicon-ok"></i>  立即提交</button>
				  	    </div>
				  	    <div class="col-sm-offset-2" v-else>
				  	    	<button style="margin-left: 6px; font-size: 13px;" type="button" @click="get" value="立即查询" class="el-button el-button--success is-plain"/><i class="	glyphicon glyphicon-zoom-in"></i>  立即查询</button>
				  	    	<button style="margin-left: 6px; font-size: 13px;" type="button" @click="add" value="立即提交" class="el-button el-button--primary is-plain"/><i class="glyphicon glyphicon-ok"></i>  立即提交</button>
				  	    </div>
				  	    </div>

			        </form>
			        
			        
			        
			        
			        
			     <div style="height:10px"></div>
			         
			          
			        <form class="form-horizontal devform">	
					<div class="panel panel-default" style="8px 8px 15px, rgb(255, 255, 255) -18px -18px 30px; border-radius: 8px;" lay-size="lg">		    
    			       <table class="table table-striped">
            		          <thead>
            		              <tr>
                		              <th style="width:46px;font-size:14px"  id="s2">
                		                  <span >
                		                      
                		                       <input type="checkbox"  @click="check888(rs.userinfo,rs.userName,rs.data)"   id="btns"  v-for="(rs,key) in row">
                		                  </span>
                		              </th>
                		              <th style="font-size:14px">课程名称</th>
                		              <!--<th></th>-->
                		              <!--<th></th>-->
            		              </tr>
            		          </thead> 
            		          <tbody v-for="(rs,key) in row" id="s1">
            		            <tr  v-for="(res,key) in rs.data" :id="key"  >	 	         		
                		            <td   role="tabpanel" aria-labelledby="headingOne" style="font-size:13px" > 
                		             <!--<span   class="checkbox checkbox-success">-->
                		             <span   class="checkbox checkbox-success">
                		                  <input type="checkbox" :value="res.name" @click="checkResources(rs.userinfo,rs.userName,rs.data,res.name)" ><label for="checkbox1"></label></span>
                    				</td>	
                		            <td    role="tabpanel" aria-labelledby="headingOne" style="font-size:13px" > 
                		            <span   class="checkbox checkbox-success" style="margin-left:-20px">{{res.name}}</span> 
                    				</td>
                		            <!--<td></td>-->
                		            <!--<td></td>-->
            		            </tr>
            		          </tbody>
    		            </table>
    		                  <div style="text-align:center">
    		            <div v-for="(rs,key) in row" style=" ;width:100%; margin:0 auto"  >
				         <!--<b>{{rs.userName}}</b>  {{rs.userinfo}} -->
				        <span v-if="rs.msg=='查询成功'">
				             <!--<b style="color: green;">{{rs.msg}}</b>-->
				        </span>
				        <span v-else-if="rs.msg!='查询成功'" style="color:#999;">
				             {{rs.msg}}！{{rs.userinfo}}
				        </span>
				     	</div>
    		            
    		            </div>
                    </div>
		        </form>
		        </div>
	     </div>
     </div>
    </div>


<script type="text/javascript" src="assets/LightYear/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/main.min.js"></script>
<script src="assets/js/aes.js"></script>
<script src="../assets/js/vue.min.js"></script>
<script src="https://cdn.staticfile.org/vue-resource/1.5.1/vue-resource.min.js"></script>
<script src="https://cdn.staticfile.org/axios/0.18.0/axios.min.js"></script>
<script src="./assets/js/element.js"></script>


 

<script>
var vm=new Vue({
	el:"#add",
	data:{	
	    row:[],
	    shu:'',
	    bei:'',
	    nochake:0,
	    check_row:[],
		userinfo:'',
		cid:'',
		miaoshua:'',
		class1:'',
		class3:'',
		activems:false,
		checked:false,
	},
	methods:{
	    get:function(salt){
	    	if(this.cid=='' || this.userinfo==''){
	    		layer.msg("所有项目不能为空");
	    		return false;
	    	}
		    userinfo=this.userinfo.replace(/\r\n/g, "[br]").replace(/\n/g, "[br]").replace(/\r/g, "[br]");      	           	    
	   	    userinfo=userinfo.split('[br]');//分割
	   	    this.row=[];
	   	    this.check_row=[];    	
	   	    for(var i=0;i<userinfo.length;i++){	
	   	    	info=userinfo[i]
	   	    	if(info==''){continue;}
	   	    	var hash=getENC('<?php echo $addsalt;?>');
	   	    	var loading=layer.load();
	    	    this.$http.post("/apisub.php?act=get",{cid:this.cid,userinfo:info,hash:hash,salt:salt},{emulateJSON:true}).then(function(data){
	    		     if(data.body.code==-7){
	    	            salt=getENC(data.body.msg);
	    	            vm.get(salt);
	    	        }else{
	    	            layer.close(loading);	  
	    	            this.row.push(data.body);
	    	        }
	    			    
	    	    });
	   	    }	   	    	    
	    },
	    add:function(){
	    	if(this.cid==''){
	    	    if(this.nochake!=1){
    	    		layer.msg("请先查课");
    	    		return false;
	    	    }
	    	} 	
	    	if(this.check_row.length<1){
	    	    if(this.nochake!=1){
    	    		layer.msg("请先选择课程");
    	    		return false;
	    	    }
	    	} 	
	    	//console.log(this.check_row);
	        var loading=layer.load();
	    	this.$http.post("/apisub.php?act=add",{cid:this.cid,data:this.check_row,shu:this.shu,bei:this.bei,userinfo:this.userinfo,nochake:this.nochake},{emulateJSON:true}).then(function(data){
	    		layer.close(loading);
	    		if(data.data.code==1){
	    			this.row=[];
	    			this.check_row=[]; 
	    			this.$message({type: 'success', showClose: true,message: data.data.msg});
	    		}else{
	    			this.$message({type: 'error', showClose: true,message: data.data.msg});
	    		}
	    	});
	    },
	    check888:function(userinfo,userName,rs,name){
	        var btns=document.getElementById("btns");
	        var  zk= document.getElementById("s1");
	        var x= zk.getElementsByTagName("input");
        	if(btns.checked==true) {
        		for(var i=0   ; i < x.length; ++i) {
                    data={userinfo,userName,data:rs[i]};
        			x[i].checked=true;
        		    vm.check_row.push(data);
        		}
        	}else {
        		for(var i=0; i < x.length; ++i) {
        			x[i].checked=false; 
        		}
        		 this.check_row = []
        	}
	    },
	    selectAll:function () {            
            if(this.cid==''){
	    		layer.msg("请先查课");
	    		return false;
	    	} 	
	    	this.checked=!this.checked;  
	    	if(this.check_row.length<1){
		    	for(i=0;i<vm.row.length;i++){
		    		console.log(i);
		    		userinfo=vm.row[i].userinfo
		    		userName=vm.row[i].userName
		    		rs=vm.row[i].data
		            for(a=0;a<rs.length;a++){
			    		aa=rs[a]
			    		data={userinfo,userName,data:aa}
			    		vm.check_row.push(data);
			        } 				    	
				}     	          
            }else{
            	vm.check_row=[]
            }   	    
	    	console.log(vm.check_row);                            
        },
	    checkResources:function(userinfo,userName,rs,name){
	    	for(i=0;i<rs.length;i++){
	    		if(rs[i].name==name){
	    			aa=rs[i]
	    		}	    		
	    	}
	    	data={userinfo,userName,data:aa}
	    	if(this.check_row.length<1){
	    		vm.check_row.push(data); 
	    	}else{
	    	    var a=0;
		    	for(i=0;i<this.check_row.length;i++){		    		
		    		if(vm.check_row[i].userinfo==data.userinfo && vm.check_row[i].data.name==data.data.name){		    			
	            		var a=1;
	            		vm.check_row.splice(i,1);	
		    		}	    		
		    	}
               if(a==0){
               	   vm.check_row.push(data);
               }
	    	} 
	    },
	    getclass:function(){
		  var load=layer.load();
 			this.$http.post("/apisub.php?act=getclass").then(function(data){	
	          	layer.close(load);
	          	if(data.data.code==1){
	          		this.class1=data.body.data;     
	          	}else{
	                layer.msg(data.data.msg,{icon:2});
	          	}
	        });	
	    	
	    },
	    getnock:function(cid){
 			this.$http.post("/apisub.php?act=getnock").then(function(data){	
	          	if(data.data.code==1){			                     	
	          		this.nock=data.body.data;	
	          		for(i=0;this.nock.length>i;i++){
	          		    if(cid==this.nock[i].cid){
	          		        this.nochake=1;
	          		        break;
	          		    }else{
	          		        this.nochake=0;
	          		    }
	          		}
	          	}else{
	                layer.msg(data.data.msg,{icon:2});
	          	}
	        });	
	    	
	    },
	    tips: function (message) {
        	for(var i=0;this.class1.length>i;i++){
        	 	if(this.class1[i].cid==message){
                    this.$notify({
                        title: this.class1[i].name+'说明：',
                        dangerouslyUseHTMLString: true,
                        duration: 6000,
                        // showClose: false,
                        message:'<span style="font-size:14px;">'+this.class1[i].content+'</font>',
                    });
                    if(this.class1[i].miaoshua==1){
					   	 this.activems=true;
				   }else{
				   	 this.activems=false;
				   }
        	 		return false;
        	 	}
        	}
        },
        tips2: function () {
        	layer.tips('开启秒刷将额外收0.05的费用', '#miaoshua');      	  
		  
        }    
	},
	mounted(){
		this.getclass();		
	}
	
	
});
</script>