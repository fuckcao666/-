
<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title>盒子</title>
<meta name="keywords" content="盒子" />
<meta name="description" content="盒子后台管理系统" />
<link rel="icon" href="images/IMG_0118.png" type="image/ico">
<link href="http://cdn.bootcss.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/materialdesignicons.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="js/bootstrap-multitabs/multitabs.min.css">
<link rel="stylesheet" type="text/css" href="css/animate.min.css">
<link rel="stylesheet" type="text/css" href="css/style.min.css">
</head><link href="css/syggao.min.css?v=1.6.4.1" rel="stylesheet">
<body>
<section class="content" id="gg">
    <div class="row">
        <div class="col-md-12">
            <ul class="timeline">
                <li class="time-label">
                      <span class="bg-red">
                        通知公告
                      </span>
                </li>
                    <li v-for="res in row.data">
                        <i class="fa fa-commenting bg-aqua"></i>
                        <div class="timeline-item">
                            <span class="time"><i class="fa fa-clock-o"></i> {{res.time}}</span>
                            <h3 class="timeline-header no-border">
                                <p><strong>{{res.name}}:</strong></p>
                                <p v-html="res.neirong">公告内容</p>
                            </h3>
                        </div>
                    </li>


                <li>
                    <i class="fa fa-clock-o bg-gray"></i>
            </ul>
        </div>
    </div>
</section>
</body>

<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="https://cdn.staticfile.org/vue/2.6.11/vue.min.js"></script>
<script src="https://cdn.staticfile.org/vue-resource/1.5.1/vue-resource.min.js"></script>
<script src="js/lightyear.js"></script>
<script src="js/lyear-loading.js"></script>

<script>
vm=new Vue({
	el:"#gg",
	data:{
		  row:null
	},
	methods:{
		get:function(page){
		  var load=$('body').lyearloading({
                        opacity: 0.2,
                        backgroundColor: '#ffffff',
                        spinnerText: '资源加载中，请稍后...',
                        textColorClass: 'text-info'
                        });
		  data={cx:this.cx,page}
 			this.$http.post("/apisub.php?act=gonggao1",data,{emulateJSON:true}).then(function(data){	
	          	load.destroy();
	          	if(data.data.code==1){			                     	
	          		this.row=data.body;
	          	}else{
	          	    lightyear.notify(data.data.msg, 'danger', 3000, 'mdi mdi-check-circle-outline', 'top', 'right');
	          	}
	        });	
		},
		 
	},
	mounted(){
		this.get(1);
	}
});
</script>