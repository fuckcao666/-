<?php
define('SYSTEM_ROOT', dirname(__FILE__).'/');
define('ROOT', dirname(SYSTEM_ROOT).'/');
if(!$nosession)session_start();
$siteurl = ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://').$_SERVER['HTTP_HOST'].'/';
include_once(SYSTEM_ROOT."autoloader.php");
Autoloader::register();
include_once(SYSTEM_ROOT."security.php");
require ROOT.'config.php';
define('DBQZ', $dbconfig['dbqz']);
$DB = new \lib\PdoHelper($dbconfig);
$CACHE=new \lib\Cache();
$conf=$CACHE->pre_fetch();
define('SYS_KEY', $conf['syskey']);
if(!$conf['localurl'])$conf['localurl'] = $siteurl;
$password_hash='!@#%!s!0';
include_once(SYSTEM_ROOT."functions.php");
include_once(SYSTEM_ROOT."member.php");
?>