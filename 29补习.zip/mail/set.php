<?php
include("./includes/common.php");
$mod=isset($_GET['mod'])?$_GET['mod']:null;
$mods=['mail'=>'邮箱与短信'];
if($mod=='setmail'){
    $cs=trim(strip_tags(daddslashes($_GET['cs']))); //get传来的参数，如果想多加几个,，可以复制该段，然后把"cs"改成自己想要的参数即可。
	$title='邮件标题'; //这里是邮件标题。
    $content="get传入的参数是：$cs"; //这里是邮件内容，支持HTML代码，可传递get参数。
	// 基本HTML代码：
	// <span style="red">红色</span> 或 <span style="#FF0000">红色</span>
	// 十六进制颜色代码大全: https://blog.csdn.net/herb777/article/details/7652330
	// 换行:<br> 空格:&nbsp; 
	$mail_name = '35003061@qq.com' ;
	//这里填写收件人，也可以通过GET参数传递过来。如果需要GET传递收件人，则可以把下面注释的替换上即可。
 // $mail_name =trim(strip_tags(daddslashes($_GET['name'])));
	if(!empty($mail_name)){
	$result=send_mail($mail_name,$title,$content);
	if($result==1)
		showmsg('邮件发送成功！');
	else
		showmsg('邮件发送失败！');
	}
	else
		showmsg('未填写收件人！');
}
?>
