define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'admin/index' + location.search,
                    add_url: 'admin/add',
                    edit_url: 'admin/edit',
                    del_url: 'admin/del',
                    multi_url: 'admin/multi',
                    import_url: 'admin/import',
                    table: 'admin',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                columns: [
                    [
                        {checkbox: true},
                        //{field: 'id', title: __('Id'),visible: false},
                        //{field: 'admin_id', title: __('Admin_id')},
                        {field: 'username', title: __('Username'),operate:'LIKE'},
                        {field: 'nickname', title: __('Nickname')},
                        {field: 'money', title: __('Money')},
                        {field: 'ymoney', title: "余额（英语类）"},
                        {field: 'price', title: "单价"},
                        {field: 'yqm', title: __('Yqm')},
                        {field: 'email', title: __('Email')},                   
                        {field: 'logintime', title: "最后登录", operate:'RANGE', addclass:'datetimerange', autocomplete:false, formatter: Table.api.formatter.datetime},
                        //{field: 'loginip', title: __('Loginip'), operate: 'LIKE'},
                        //{field: 'createtime', title: __('Createtime'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, formatter: Table.api.formatter.datetime},
                        //{field: 'updatetime', title: __('Updatetime'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, formatter: Table.api.formatter.datetime},
                        {field: 'status', title: __('Status'), searchList: {"normal":"正常","hidden":"封禁"}, formatter: Table.api.formatter.status},
                        {field: 'operate', title: __('Operate'), table: table, 
                        buttons: [
                            {name: 'edit1', text: '编辑', title: '编辑', classname: 'btn btn-xs btn-primary btn-dialog', url: 'admin/edit'},
						    {name: 'czmoney', text: '充值', title: '充值', icon: 'fa fa-database', classname: 'btn btn-xs btn-success btn-dialog', url: 'admin/czmoney'},
						    {name: 'czmm', text: '重置密码', title: '重置密码', icon: 'fa fa-hourglass-half', classname: 'btn btn-xs btn-danger btn-ajax', url: 'admin/czmm',visible: false}
						],                       
                        events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        czmoney: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});