define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {
    function getwk(){   	
   	    var cid=$("#cid").val();
   	    var account=$("#account").val();
   	    if(cid==''){
   	    	Toastr.error("请先选择平台");
   	    	return false;
   	    }
   	    if(account==''){
   	    	Toastr.error("所有项目不能为空");
   	    	return false;
   	    }
   	    $("#tree").empty();
   	    account=account.replace(/\r\n/g, "[br]");
   	    account=account.replace(/\n/g, "[br]");
   	    account=account.replace(/\r/g, "[br]");	       	           	    
   	    account=account.split('[br]');//分割
   	    var load=layer.load();
   	    console.log(account.length);
   	    for(var i=0;i<account.length;i++){		       	    	
   	    	var userinfo=account[i];
   	    	if(userinfo!=''){
	   	    	 $.ajax({
					url:"add/get",
				    method:'post',
					data:{cid,userinfo},
					dataType:'json',
					success(data){
						layer.close(load);
						if(data.code==1){								
					        var aaa='';
					         for(i=0;i<data.data.length;i++){
					         	  var aa='<li class="list-group-item"><input type="checkbox" id="kcname" value="'+data.userinfo+"|"+data.data[i].name+'"/>'+data.data[i].name+'</li>'
					         	  var aaa=aaa+aa;
					         }
					        var a='<ul class="list-group"><li class="list-group-item node-tree"><span class="icon expand-icon glyphicon glyphicon-minus"></span><b><i>'+data.userinfo+'</i></b></li>'+aaa+'</ul>'  
				            $("#tree").append(a);								
							Toastr.success(data.msg);
						}else{
							Toastr.error(data.msg);
						}	
					},error(){
						layer.close(load);
						Toastr.error("服务器错误");
					}			
			   });  
   	      }    
   	    }  	
    }
    
    function addwk1(){   
		var cid=$("#cid").val();
   	    if(cid==''){
   	    	Toastr.error("请先查询");
   	    	return false;
   	    }   
    	if($("#kcname:checked").length<1){
   	    	Toastr.error("请先选中在提交");
   	    	return false;
        } 
        
        var con="";
        var con2="";
        $("#kcname:checked").each(function () {
			console.log($("#kcname:checked"));
			console.log(this.value);
			value=this.value.split('|');//分割
			info=value[0]
			kcname=value[1]			
			console.log(info);
			console.log(kcname);
			con='<tr><td>'+info+'</th><td>'+kcname+'</th></tr>';
            con2=con2+con;            
		});
		    var con3='<table class="table table-bordered table-striped" style="width:100%" ><tr><th>账号信息</th><th>课程名字</th></tr>'+con2+'</table>';
			layer.confirm(con3, {
			  btn: ['确认','取消'],title:'确认信息' //按钮
			}, function(index){
				$("#kcname:checked").each(function () {
					console.log($("#kcname:checked"));
					console.log(this.value);         
					var load=layer.load();
					$.ajax({
						url:"add/add",
					    method:'post',
						data:{cid,addinfo:this.value},
						dataType:'json',
						success(data){
							layer.close(load);
							if(data.code==1){							
								Toastr.success(data.msg);
							}else{
								Toastr.error(data.msg);
							}	
						},error(){
							layer.close(load);
							Toastr.error("服务器错误");
						}			
				   }); 
				});
				layer.close(index);
			});         
    }
    
    function addwk2(){   
        $("#kcname:checked").each(function () {
			console.log($("#kcname:checked"));
			console.log(this.value);         
			var load=layer.load();
			$.ajax({
				url:"add/add",
			    method:'post',
				data:{cid,addinfo:this.value},
				dataType:'json',
				success(data){
					layer.close(load);
					if(data.code==1){							
						Toastr.success(data.msg);
					}else{
						Toastr.error(data.msg);
					}	
				},error(){
					layer.close(load);
					Toastr.error("服务器错误");
				}			
		   }); 
		});
    }
    
    
    var Controller = {
        index: function () {
        	$("#serachCourse").click(function(){
        		getwk();
        	});
	        $("#addOrder").click(function(){ 
	        	addwk1();
        	});
        },
        yy: function () {
        	$("#serachCourse").click(function(){
        		getwk();
        	});
	        $("#addOrder").click(function(){ 
	        	addwk1();
        	});
        },
    };
    
    return Controller;
});
