define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'wk_class/index' + location.search,
                    add_url: 'wk_class/add',
                    edit_url: 'wk_class/edit',
                    del_url: 'wk_class/del',
                    multi_url: 'wk_class/multi',
                    import_url: 'wk_class/import',
                    table: 'wk_class',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'weigh',
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id')},
                        {field: 'name', title: __('Name'), operate: 'LIKE'},
                        {field: 'price', title: __('Price'), operate: 'LIKE'},
                        {field: 'gethy.name', title: "查询平台", operate: 'LIKE'},
                        //{field: 'cx_id', title: __('Cx_id'), operate: 'LIKE'},
                        {field: 'cx_cs', title: __('Cx_cs'), operate: 'LIKE'},
                        {field: 'addhy.name', title: "提交平台", operate: 'LIKE'},
                        //{field: 'add_id', title: __('Add_id'), operate: 'LIKE'},
                        {field: 'add_cs', title: __('Add_cs'), operate: 'LIKE'},
                        {field: 'active', title: "网课类型", searchList: {"1":"普通类","2":"英语类"}, formatter: Table.api.formatter.status},
                        {field: 'status', title: __('Status'), searchList: {"1":__('Status 1'),"0":__('Status 0')}, formatter: Table.api.formatter.status},
                        
                        {field: 'createtime', title: __('Createtime'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, formatter: Table.api.formatter.datetime},
                        {field: 'updatetime', title: __('Updatetime'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, formatter: Table.api.formatter.datetime},
                        {field: 'weigh', title: __('Weigh'), operate: false},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        index2: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'wk_class/index2' + location.search,
                    add_url: 'wk_class/add',
                    edit_url: 'wk_class/edit',
                    del_url: 'wk_class/del',
                    multi_url: 'wk_class/multi',
                    import_url: 'wk_class/import',
                    table: 'wk_class',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'weigh',
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id')},
                        {field: 'name', title: __('Name'), operate: 'LIKE'},
                        {field: 'price', title: __('Price'), operate: 'LIKE'},
                        {field: 'gethy.name', title: "查询平台", operate: 'LIKE'},
                        //{field: 'cx_id', title: __('Cx_id'), operate: 'LIKE'},
                        {field: 'cx_cs', title: __('Cx_cs'), operate: 'LIKE'},
                        {field: 'addhy.name', title: "提交平台", operate: 'LIKE'},
                        //{field: 'add_id', title: __('Add_id'), operate: 'LIKE'},
                        {field: 'add_cs', title: __('Add_cs'), operate: 'LIKE'},
                        {field: 'active', title: "网课类型", searchList: {"1":"普通类","2":"英语类"}, formatter: Table.api.formatter.status},
                        {field: 'status', title: __('Status'), searchList: {"1":__('Status 1'),"0":__('Status 0')}, formatter: Table.api.formatter.status},
                        
                        {field: 'createtime', title: __('Createtime'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, formatter: Table.api.formatter.datetime},
                        {field: 'updatetime', title: __('Updatetime'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, formatter: Table.api.formatter.datetime},
                        {field: 'weigh', title: __('Weigh'), operate: false},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});