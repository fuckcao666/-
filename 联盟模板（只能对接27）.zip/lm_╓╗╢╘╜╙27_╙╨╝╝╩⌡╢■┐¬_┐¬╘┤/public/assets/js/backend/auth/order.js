define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'auth/order/index' + location.search,
                    add_url: 'auth/order/add',
                    edit_url: 'auth/order/edit',
                    del_url: 'auth/order/del',
                    multi_url: 'auth/order/multi',
                    import_url: 'auth/order/import',
                    table: 'wk_order',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                columns: [
                    [
                        {checkbox: true},                       
                        {field: 'operate', title: __('Operate'), table: table,
                        buttons: [
						    {name: 'dock', text: '执行对接', title: '执行对接', classname: 'btn btn-xs btn-danger btn-ajax', url: 'auth/order/dock'},
						    {name: 'tongbu', text: '同步刷新', title: '同步刷新', classname: 'btn btn-xs btn-warning btn-ajax', url: 'auth/order/tongbu'},
                        ],events: Table.api.events.operate, formatter: Table.api.formatter.operate},
                        {field: 'id', title: __('Id')},
                        {field: 'admin_id', title: __('Admin_id'),operate: 'LIKE'},
//                      {field: 'cid', title: __('Cid')},
                        {field: 'yid', title: __('Yid'),operate: 'LIKE'},
                        {field: 'status', title: __('Status'), searchList: {"0":__('Status 0'),"1":__('Status 1'),"2":__('Status 2'),"3":__('Status 3'),"4":"待考试","5":"已退回"}, formatter: Table.api.formatter.status},
                        {field: 'dockstatus', title: __('Dockstatus'),searchList: {"0":"待处理","1":"对接成功","2":"对接失败","99":"自营"}, operate: 'LIKE', formatter: Table.api.formatter.status},

                      
//                      {field: 'huoyuan_id', title: __('Huoyuan_id')},
//                      {field: 'add_cs', title: __('Add_cs'), operate: 'LIKE'},
                        {field: 'ptname', title: __('Ptname'), operate: 'LIKE'},
//                      {field: 'userName', title: __('Username'), operate: 'LIKE'},
                        {field: 'school', title: __('School'), operate: 'LIKE'},
                        {field: 'user', title: __('User'), operate: 'LIKE'},
                        {field: 'pass', title: __('Pass'), operate: 'LIKE'},
                        {field: 'kcid', title: __('Kcid'), operate: 'LIKE'},
                        {field: 'kcname', title: __('Kcname'), operate: 'LIKE'},
                        {field: 'process', title: __('Process'), operate: 'LIKE'},
                        {field: 'remarks', title: __('Remarks'), operate: 'LIKE'},
                        {field: 'fees', title: __('Fees'), operate: 'LIKE'},
                        {field: 'kcks', title: __('Kcks'), operate: 'LIKE',visible: false},
                        {field: 'kcjs', title: __('Kcjs'), operate: 'LIKE',visible: false},
                        {field: 'ksks', title: __('Ksks'), operate: 'LIKE'},
                        {field: 'ksjs', title: __('Ksjs'), operate: 'LIKE',visible: false},
                        {field: 'ip', title: __('Ip'), operate: 'LIKE'},

                        {field: 'createtime', title: __('Createtime'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, formatter: Table.api.formatter.datetime},
                        {field: 'updatetime', title: __('Updatetime'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, formatter: Table.api.formatter.datetime},
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        recyclebin: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    'dragsort_url': ''
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: 'auth/order/recyclebin' + location.search,
                pk: 'id',
                sortName: 'id',
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id')},
                        {
                            field: 'deletetime',
                            title: __('Deletetime'),
                            operate: 'RANGE',
                            addclass: 'datetimerange',
                            formatter: Table.api.formatter.datetime
                        },
                        {
                            field: 'operate',
                            width: '130px',
                            title: __('Operate'),
                            table: table,
                            events: Table.api.events.operate,
                            buttons: [
                                {
                                    name: 'Restore',
                                    text: __('Restore'),
                                    classname: 'btn btn-xs btn-info btn-ajax btn-restoreit',
                                    icon: 'fa fa-rotate-left',
                                    url: 'auth/order/restore',
                                    refresh: true
                                },
                                {
                                    name: 'Destroy',
                                    text: __('Destroy'),
                                    classname: 'btn btn-xs btn-danger btn-ajax btn-destroyit',
                                    icon: 'fa fa-times',
                                    url: 'auth/order/destroy',
                                    refresh: true
                                }
                            ],
                            formatter: Table.api.formatter.operate
                        }
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});