<?php
namespace wangke;

use think\Db;

class Duijie{
	
function namelist(){
	$data=[
	    'wklm'=>'网课联盟',
	    '27'=>'27学习平台',
	    'zijian'=>'指尖网课',
	];
	return $data;
}	
	
	
function money($row){
	if($row['type']=='wklm'){
		   	$header = array(
                  'CLIENT-IP: '.$row['ip'],
                  'X-FORWARDED-FOR: '.$row['ip']
            ); 
     
   	    $result=$this->get_url("http://wklm.cn/general/profile?addtabs=1",false,$row['cookie'],$header);
 		$result=urldecode($result);
        $result=$this->getSubstr($result,"row[money]","price");
        $result=$this->getSubstr($result,"value="," disabled");
        $b=str_replace('"','',$result);      
        return $b; 	
	}elseif($row['type']=='27'){
		$data=array(
		   'uid'=>$row['user'],
		   'key'=>$row['pass']
		);
		$result=$this->get_url2("http://wk.27sq.cn/api.php?act=getmoney",$data);
		$result=json_decode($result,true);
		var_dump($result);
		return $result['money'];
	}elseif($row['type']=="zijian"){
   	    $result=$this->get_url("http://94zhijian.com/api/User/Money/?token=".$row['token']);
   	    $result=json_decode($result,true);
   	    return $result['Money']; 	   	
   	}
}
	
	
function get($hy,$id,$userinfo){	
		$userinfo2=explode(" ",$userinfo);//分割	
		if(count($userinfo2)>2){
			$school=$userinfo2[0];
			$username=$userinfo2[1];
			$password=$userinfo2[2];				
		}else{
			$school="自动识别";
			$username=$userinfo2[0];
			$password=$userinfo2[1];				
		}  
		$userinfo3=$school." ".$username." ".$password;
	if($hy['type']=='wklm'){
		    $data=array(
	    		'school'=>$school,
	    		'studentnumber'=>$username,
	    		'studentpwd'=>$password,
	    		'ptid'=>$id		
	    	);
	    	
		    $result=$this->get_curl("http://wklm.cn/index.php/api/course/search",$data);
    		$result=json_decode($result,true);
    		if($result['code']==1){
    			  foreach($result['data']['courseList'] as $row){	
		    			  	if(isset($row['recruitId'])){
		    			  		$id=$row['recruitId'];
		    			  	}else{
		    			  		$id=""; 
		    			  	}		  			
				    		$name=$row['name'];   			  	        
    			  	    	$b[]=array("id"=>$id,"name"=>$name);	    	   
    			  }
	  		    if(isset($result['data']['user']['realName'])){
			  		$userName=$result['data']['user']['realName'];//姓名
			  	}else{
			  		$userName="";//姓名
			  	}	   			    			
    			$result=['code'=>1,'msg'=>'查询成功','userinfo'=>$userinfo3,'data'=>$b,"userName"=>$userName]; 		
    		}else{				
				$msg=$result['msg'];
				if($msg==''){$msg="查询失败";}
				$result=array("code"=>-1,"msg"=>$msg);		
			}		
	}elseif($hy['type']=='27'){
		    $data=array(
		        'uid'=>$hy['user'],
		        'key'=>$hy['pass'],
	    		'school'=>$school,
	    		'user'=>$username,
	    		'pass'=>$password,
	    		'platform'=>$id		
	    	);
	    	
		    $result=$this->get_curl("http://wk.27sq.cn/api.php?act=get",$data);
    		$result=json_decode($result,true);
    		if($result['code']==1){
    			  foreach($result['data'] as $row){		  			
				    		$name=$row['name'];   			  	        
    			  	    	$b[]=array("id"=>$id,"name"=>$name);	    	   
    			  }  			    			
    			$result=['code'=>1,'msg'=>'查询成功','userinfo'=>$userinfo3,'data'=>$b]; 		
    		}else{				
				$msg=$result['msg'];
				if($msg==''){$msg="查询失败";}
				$result=array("code"=>-1,"msg"=>$msg);		
			}		
	}elseif($hy['type']=="zijian"){//指尖
    		$data=array(
    		   'token'=>$hy['token'],
    		   'lx'=>$id,
    		   'querytxt'=>$username.' '.$password
    		);
    		$result=$this->get_url("http://94zhijian.com/api/CourseQuery/getList/",$data);
    		$result=json_decode($result,true);
	        if($result['state']==200){//查询成功        	
				for($i=0;$i<count($result['datas']);$i++){
			   	 		$kcid=$result['datas'][$i]['id'];//指尖自定ID，非课程ID
			   	 		$kcname=$result['datas'][$i]['name'];
			   	 		$b[]=array("id"=>$kcid,"name"=>$kcname);
		       	 }  
		       	$result=['code'=>1,'msg'=>'查询成功','userinfo'=>$userinfo3,'data'=>$b];   	
	        }else{
	        	$result=array("code"=>-1,"msg"=>$result['message']);
	        }
    }	
	return $result;
}

function add($row,$class,$hy){
    if($hy['type']=='wklm'){
    	$data=array(
          'row[courses_id]_text'=>$row['school'],
          'row[courses_id]'=>$class['add_cs'],
          'row[school]'=>$row['school'],
          'row[studentnumber]'=>$row['user'],
          'row[studentpwd]'=>$row['pass'],
          'row[name]'=>$row['kcname'],
          'row[accountinfo]'=>"考试"
          );
        $header = array(
              'CLIENT-IP: '.$hy['ip'],
              'X-FORWARDED-FOR: '.$hy['ip']
        );
        $result=$this->get_curl("http://wklm.cn/orderrecord/add?dialog=1",$data,false,$hy['cookie'],$header);
        $result=urldecode($result);
        $result=$this->getSubstr($result,"<h1>","</h1>");		        
        if($result=="添加订单成功"){//提交成功	
      	    $b=array("code"=>1,"msg"=>"提交成功");
        }else{
        	$b=array("code"=>-1,"msg"=>$result);
        }		        		        	        
    }elseif($hy['type']=='27'){
    	$data=array(
			  'uid'=>$hy['user'],
	          'key'=>$hy['pass'],
	          'platform'=>$class['add_cs'],
	          'school'=>$row['school'],
	          'user'=>$row['user'],
	          'pass'=>$row['pass'],
	          'kcname'=>$row['kcname']
          );
        $result=$this->get_url("http://wk.27sq.cn/api.php?act=add",$data);
        $result=json_decode($result,true);	        
        if($result['code']=='0'){//提交成功	
      	    $b=array("code"=>1,"msg"=>"提交成功");
        }else{
        	$b=array("code"=>-1,"msg"=>$result['msg']);
        }		        		        	            
    }elseif($hy['type']=="zijian"){//指尖
	    		$result=$this->get_url("http://94zhijian.com/api/CourseQuery/api/?token=".$hy['token']."&platform=".$class['add_cs']."&school=".$row['school']."&account=".$row['user']."&password=".$row['pass']."&name=".$row['kcname']);
	    	    $result=json_decode($result,true);
	    	    if($result['code']=='0'){
	    			$b=array("code"=>1,"msg"=>$result['msg']);
	    		}else{
	    			$b=array("code"=>-1,"msg"=>$result['msg']);
	    		}
		        return $b;  
    }
    return $b;
}	
	
function update($row,$hy){
	if($hy['type']=="wklm"){
         $time=time();     
 		 $header = array(
 		      'X-Requested-With: XMLHttpRequest',
              'CLIENT-IP: '.$hy['ip'],
              'X-FORWARDED-FOR: '.$hy['ip']
         );     
          
	  	 $result=$this->get_url("http://wklm.cn/orderrecord/index?addtabs=1&sort=id&order=desc&offset=0&limit=10&filter=%7B%22studentnumber%22%3A%22".$row['user']."%22%7D&op=%7B%22studentnumber%22%3A%22LIKE%22%7D&_=".$time,false,$hy['cookie'],$header);
	     $result=json_decode($result,true);	
		   for($i=0;$i<count($result['rows']);$i++){ 	
		    		$id=$result['rows'][$i]['id'];//源站订单ID
		    		$kcname=$result['rows'][$i]['name'];//课程名字	    		
		    		$status_text=$result['rows'][$i]['status_text'];//状态文本
		    				    		
		    		if(isset($result['rows'][$i]['process'])){
		    			$process=$result['rows'][$i]['process'];//进度	    			
		    		}else{
		    			$process='';
		    		}
		    		
		    		if(isset($result['rows'][$i]['examtime'])){
		    			$ksks=$result['rows'][$i]['examtime'];
		    			$ksks=date('Y-m-d H:i:s', $ksks);
		    		}else{
		    			$ksks='';
		    		}
		    		
		    		if(isset($result['rows'][$i]['abnormalcauses'])){
		    			$remarks=$result['rows'][$i]['abnormalcauses'];
		    		}else{
		    			$remarks='';
		    		}
		    			    		
		    		if($status_text=="已完成"){
		    			$status='1';
		    		}elseif($status_text=="待处理"){
		    			$status='0';
		    		}elseif($status_text=="进行中" || $status_text=="执行中"){
		    			$status='2';
		    		}elseif($status_text=="待考试" || $status_text=="考试中"){
		    			$status='4';
		    		}elseif($status_text=="异常"){
		    			$status='3';
		    		}else{
		    			$status='3';
		    		}	
		    		
		    		$order_id=$row['id'];   		
		    		if($row['kcname']==$kcname){
		    			Db::name("wk_order")->update(['yid'=>$id,'status'=>$status,'process'=>$process,'ksks'=>$ksks,'remarks'=>$remarks,'id'=>$order_id]);	    		
		    		}  	
		  }		
	 }elseif($hy['type']=="27"){
		 	$data=array(
		 	  'username'=>$row['user']
		 	);
	 	 $result=$this->get_url("http://wk.27sq.cn/api.php?act=chadan",$data);
	     $result=json_decode($result,true);
	               foreach($result['data'] as $res){ 
	               	   $id=$res['id']; 
	               	   $kcname=$res['kcname'];
	               	   $status=$res['status'];
	               	  
	               	   	if(isset($res['process'])){
			    			$process=$res['process'];
			    		}else{
			    			$process='';
			    		}
	               		if(isset($res['remarks'])){
			    			$remarks=$res['remarks'];
			    		}else{
			    			$remarks='';
			    		}
			    		
				    	if($status=="已完成"){$status='1';}elseif($status=="待处理"){$status='0';}elseif($status=="进行中" || $status=="执行中" || $status=="考试中" || $status=="补刷中"){$status='2';}elseif($status=="异常"){$status='3';}else{$status='3';}	
			    		
				    	$order_id=$row['id'];   		
			    		if($row['kcname']==$kcname){
			    			Db::name("wk_order")->update(['yid'=>$id,'status'=>$status,'process'=>$process,'remarks'=>$remarks,'id'=>$order_id]);	    		
			    		}  	
	              }	
	 }elseif($hy['type']=="zijian"){
	  	 $data=array(
	         'token'=>$hy['token'],
	         's'=>$row['user'],
	         'page'=>'1',
	         'pageSize'=>'10'
	  	 );
	  	 $result=$this->get_url("http://94zhijian.com/api/Orders/getPageList/",$data);
	     $result=json_decode($result,true);
	     if($result['state']==200){
		  	 for($i=0;$i<count($result['datas']);$i++){ 	
			    		$id=$result['datas'][$i]['id'];//源站订单ID
			    		$yuser=$result['datas'][$i]['u'];//账号密码	    		
		                $ypass=$result['datas'][$i]['p'];//密码
		                $kcname=$result['datas'][$i]['km'];
		                //$kszt=$result['datas'][$i]['kszt'];		                
		                $status=$result['datas'][$i]['kczt'];//状态文本
		            
		            if($status=="已完成"){$status='1';}elseif($status=="待处理"){$status='0';}elseif($status=="进行中" || $status=="执行中" || $status=="考试中" || $status=="平时分进行中"){$status='2';}elseif($status=="异常"){$status='3';}else{$status='3';}	
					$order_id=$row['id'];   		
		    		if($row['kcname']==$kcname){
		    			Db::name("wk_order")->update(['yid'=>$id,'status'=>$status,'id'=>$order_id]);	    		
		    		}  
			  }	
	      }
    }
}

function budan($row,$hy){
	$yid=$row['yid'];
	if($hy['type']=="wklm"){
        $header = array(
              'X-Requested-With: XMLHttpRequest',
              'CLIENT-IP: '.$hy['ip'],
              'X-FORWARDED-FOR: '.$hy['ip']
        );
        $result=$this->get_url2("http://wklm.cn/orderrecord/retry3/ids/".$yid,'我是你爹',$hy['cookie'],$header);
        $result=json_decode($result,true);
        $b=array("code"=>1,"msg"=>$result['msg']);	        		        	        
        return $b; 
    }elseif($hy['type']=="27"){
        $data = array(
            'uid'=>$hy['uid'],
            'key'=>$hy['key'],
            'id'=>$yid
        );
        $result=$this->get_url("http://wk.27sq.cn/api.php?act=budan",$data);
        $result=json_decode($result,true);
        $b=array("code"=>1,"msg"=>$result['msg']);	        		        	        
        return $b; 
   	}elseif($type=="zijian"){
	  	 $data=array(
	         'token'=>$hy['token'],
	         'id'=>$yid
	  	 );
	  	 $result=$this->get_url("http://94zhijian.com/api/Orders/refresh/",$data);
	     $result=json_decode($result,true);
	     if($result['state']==200){
            $b=array("code"=>1,"msg"=>"操作成功");
		  }else{
		  	$b=array("code"=>-1,"msg"=>"接口异常，请联系管理员");	
		  }	  	
	  	 return $b;	  	 	
   	}
}


function getSubstr($str, $leftStr, $rightStr)
{
	$left = strpos($str, $leftStr);
	$right = strpos($str, $rightStr,$left);
	if($left < 0 or $right < $left) return '';
	return substr($str, $left + strlen($leftStr), $right-$left-strlen($leftStr));
}
function get_url($url,$post=false,$cookie=false,$header=false){//curl
    $ch = curl_init();
    if($header){
        //curl_setopt($ch,CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    }else{
        curl_setopt($ch,CURLOPT_HEADER, 0);
    }
    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36');//设置UA 否则会被拦截
    if($post){
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,http_build_query($post));
    }
    if($cookie){
        curl_setopt($ch, CURLOPT_COOKIE,$cookie);
    }
    
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
function get_url2($url,$post=false,$cookie=false,$header=false){//curl
    $ch = curl_init();
    if($header){
        //curl_setopt($ch,CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    }else{
        curl_setopt($ch,CURLOPT_HEADER, 0);
    }
    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36');//设置UA 否则会被拦截
    if($post){
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$post);
    }
    if($cookie){
        curl_setopt($ch, CURLOPT_COOKIE,$cookie);
    }
    
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}		
function get_curl($url,$post=0,$referer=0,$cookie=0,$header=0,$ua=0,$nobaody=0){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		$httpheader[] = "Accept: */*";
		$httpheader[] = "Accept-Encoding: gzip,deflate,sdch";
		$httpheader[] = "Accept-Language: zh-CN,zh;q=0.8";
		$httpheader[] = "Connection: close";
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		if($post){
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
		}
		curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
		if($header){
			curl_setopt($ch, CURLOPT_HEADER, TRUE);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIE, $cookie);
		}
		if($referer){
			if($referer==1){
				curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
			}else{
				curl_setopt($ch, CURLOPT_REFERER, $referer);
			}
		}
		if($ua){
			curl_setopt($ch, CURLOPT_USERAGENT,$ua);
		}else{
			curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36');
		}
		if($nobaody){
			curl_setopt($ch, CURLOPT_NOBODY,1);
		}
		curl_setopt($ch, CURLOPT_ENCODING, "gzip");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		$ret = curl_exec($ch);
		curl_close($ch);
		return $ret;
	}	
}



?>