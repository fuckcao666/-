<?php

return array (
  'name' => '1314网课开发',
  'beian' => '',
  'cdnurl' => '',
  'version' => '1.0.2',
  'timezone' => 'Asia/Shanghai',
  'forbiddenip' => '',
  'languages' => 
  array (
    'backend' => 'zh-cn',
    'frontend' => 'zh-cn',
  ),
  'fixedpage' => 'dashboard',
  'categorytype' => 
  array (
    'default' => 'Default',
    'page' => 'Page',
    'article' => 'Article',
    'test' => 'Test',
  ),
  'configgroup' => 
  array (
    'basic' => 'Basic',
    'email' => 'Email',
    'dictionary' => 'Dictionary',
    'user' => 'User',
    'example' => 'Example',
  ),
  'mail_type' => '1',
  'mail_smtp_host' => 'smtp.qq.com',
  'mail_smtp_port' => '465',
  'mail_smtp_user' => '10000',
  'mail_smtp_pass' => 'password',
  'mail_verify_type' => '2',
  'mail_from' => '10000@qq.com',
  'yqzc' => '1',
  'notice' => '<section class="content">
    <div class="row">
        <div class="col-md-12">
            <ul class="timeline">
                <li class="time-label">
                      <span class="bg-red">
                        通知公告
                      </span>
                </li>
                
                    <li>
                        <i class="fa fa-user bg-aqua"></i>
                        <div class="timeline-item">
                            <span class="time"><i class="fa fa-clock-o"></i>2021-08-04 21:52:30</span>
                            <h3 class="timeline-header no-border"><p>修复下单的时候会有错误提示,实际下单成功的问题</p></h3>
                        </div>
                    </li>
                
                    <li>
                        <i class="fa fa-user bg-aqua"></i>
                        <div class="timeline-item">
                            <span class="time"><i class="fa fa-clock-o"></i>2021-08-03 16:10:44</span>
                            <h3 class="timeline-header no-border"><p>知到由于官方平台登录更新暂时维护下架.</p><p>U校园提高做单速度1~12小时之内即可完成订单包时长!</p></h3>
                        </div>
                    </li>
                
                    <li>
                        <i class="fa fa-user bg-aqua"></i>
                        <div class="timeline-item">
                            <span class="time"><i class="fa fa-clock-o"></i>2021-08-03 15:05:05</span>
                            <h3 class="timeline-header no-border"><p>国开在线恢复接单.依旧只包课件+视频</p></h3>
                        </div>
                    </li>
                
                    <li>
                        <i class="fa fa-user bg-aqua"></i>
                        <div class="timeline-item">
                            <span class="time"><i class="fa fa-clock-o"></i>2021-07-25 21:50:59</span>
                            <h3 class="timeline-header no-border"><p>为方便各位操作 网站进行部分布局排版<br></p></h3>
                        </div>
                    </li>
                
                    <li>
                        <i class="fa fa-user bg-aqua"></i>
                        <div class="timeline-item">
                            <span class="time"><i class="fa fa-clock-o"></i>2021-07-18 18:32:36</span>
                            <h3 class="timeline-header no-border"><p>U校园恢复上架，包所有（时长+单元测试+课时+章节任务）做单目前速度24小时左右完成。</p></h3>
                        </div>
                    </li>
                
                    <li>
                        <i class="fa fa-user bg-aqua"></i>
                        <div class="timeline-item">
                            <span class="time"><i class="fa fa-clock-o"></i>2021-07-05 18:11:11</span>
                            <h3 class="timeline-header no-border"><p>ismart官方恢复正常</p><p>大家可以正常下单</p></h3>
                        </div>
                    </li>
                


                <li>
                    <i class="fa fa-clock-o bg-gray"></i>
                </li>
            </ul>
        </div>
    </div>
</section>',
  'gxlog' => '2021-7-28<br>
正式发布',
  'gdprice' => '0.1',
  'user_ktsx' => '100',
  'user_ktmoney' => '10',
  'help' => '略略略',
  'xjprice' => '0.5',
  'logo' => 'http://pan.27sq.cn/view.php/a68ec28f28e7e4c2d7f47579559e3e6c.jpg',
  'xjprice2' => '',
  'yqszprice' => '0.35',
  'ptcz' => '30',
  'pjcz' => '50',
);
