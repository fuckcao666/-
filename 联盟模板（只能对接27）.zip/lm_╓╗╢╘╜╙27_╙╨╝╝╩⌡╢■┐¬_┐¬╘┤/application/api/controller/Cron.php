<?php
namespace app\api\controller;

use app\common\controller\Api;
use think\Db;

class Cron extends Api{
	   // 无需登录的接口,*表示全部
    protected $noNeedLogin = ['*'];
    // 无需鉴权的接口,*表示全部
    protected $noNeedRight = [];
    protected $wk;

    public function _initialize()
    {
        parent::_initialize();
        $this->wk=new \wangke\Duijie;
    }
	
   public function cookie(){  	   
   	   $rs=Db::name("wk_huoyuan")->where("status=1")->select();
   	   foreach($rs as $row){
   	   	  $a=$this->wk->money($row);
   	   	  if($a!=""){
   	   	  	Db::name("wk_huoyuan")->update(['money'=>$a,'id'=>$row['id']]);
   	   	  }
   	   	  var_dump($a);
   	   }
   	   //Duijie::money();
   }
   
   public function add(){   	   
   	   $rs=Db::name("wk_order")->where("dockstatus=0")->select();
   	   foreach($rs as $row){
   	   	  $class=Db::name("wk_class")->where('id='.$row['cid'])->find();   	   	  
   	   	  if($class){
   	   	  	$hy=Db::name("wk_huoyuan")->where('id='.$class['add_id'])->find();
   	   	  	$result=$this->wk->add($row,$class,$hy);
   	   	  	  echo $result['msg']."<br>";
	   	   	  if($result['code']=='1'){	   	   	  	
	   	   	  	Db::name("wk_order")->update(['dockstatus'=>'1','huoyuan_id'=>$hy['id'],'add_cs'=>$class['add_cs'],'id'=>$row['id']]);
	   	   	  }  	
   	   	  }
   	   }
   }
	
   public function update(){  //同步待处理
   	   $rs=Db::name("wk_order")->where("dockstatus=1 and status='0'")->order('id desc')->select();
   	   foreach($rs as $row){
   	   	  $hy=Db::name("wk_huoyuan")->where('id='.$row['huoyuan_id'])->find();
   	   	  $result=$this->wk->update($row,$hy);   	   	   	    	 
   	   }
   }
	
   public function update2(){ //同步进行中
   	   $rs=Db::name("wk_order")->where("dockstatus=1 and status='2'")->order('id desc')->select();
   	   foreach($rs as $row){
   	   	  $hy=Db::name("wk_huoyuan")->where('id='.$row['huoyuan_id'])->find();
   	   	  $result=$this->wk->update($row,$hy);   	   	   	    	 
   	   }
   }	

   public function update3(){ //同步代考试
   	   $rs=Db::name("wk_order")->where("dockstatus=1 and status='4'")->order('id desc')->select();
   	   foreach($rs as $row){
   	   	  $hy=Db::name("wk_huoyuan")->where('id='.$row['huoyuan_id'])->find();
   	   	  $result=$this->wk->update($row,$hy);   	   	   	    	 
   	   }
   }

   public function update4(){ //同步异常
   	   $rs=Db::name("wk_order")->where("dockstatus=1 and status='3'")->order('id desc')->select();
   	   foreach($rs as $row){
   	   	  $hy=Db::name("wk_huoyuan")->where('id='.$row['huoyuan_id'])->find();
   	   	  $result=$this->wk->update($row,$hy);   	   	   	    	 
   	   }
   }
	
}

?>