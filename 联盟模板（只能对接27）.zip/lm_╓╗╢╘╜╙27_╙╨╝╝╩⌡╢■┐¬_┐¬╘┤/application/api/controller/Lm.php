<?php
namespace app\api\controller;

use app\common\controller\Api;
use think\Db;
use app\admin\model\Admin;

class Lm extends Api{
	
	protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];

    /**
     * 首页
     *
     */
    public function index()
    {
        //$this->success('请求成功');
    }
    
    
    public function get()
    {
    	$this->request->filter(['strip_tags', 'trim']);
    	$data=$this->request->param(); 
    	$api_token=$data['api_token'];
    	$user=$data['user'];
    	$pass=$data['pass'];
    	$school=$data['school'];
    	$cid=$data['cid'];
    	
        $row=DB::name("admin")->where("token",$api_token)->find();
        if($row){
        	$wk = new \wangke\Duijie;
        	$str=$school.' '.$user.' '.$pass;
        	$class=Db::name("wk_class")->where('id',$cid)->find();
			$huoyuan=Db::name("wk_huoyuan")->where('id',$class['cx_id'])->find();               
            $result=$wk->get($huoyuan,$class['cx_cs'],$str);	
            return json($result);
        }else{
        	 $this->success("密匙不存在");
        }
    } 
    
    
    public function add()
    {
    	$this->request->filter(['strip_tags', 'trim']);
    	$data=$this->request->param(); 
    	$api_token=$data['api_token'];
    	$user=$data['user'];
    	$pass=$data['pass'];
    	$school=$data['school'];
    	$cid=$data['cid'];
    	$kcname=$data['kcname'];
    	
        $row=DB::name("admin")->where("token",$api_token)->find();
        if($row){
	       $class=Db::name("wk_class")->where('id',$cid)->find();
	       $userrow=Db::name("admin")->where('id',$row['id'])->find();
	       if($class['active']=='1'){
	          $price=$class['price']*$userrow['price'];
	          if($userrow['money']<$price){
	          	 $data=['code'=>-1,'msg'=>'余额不足'.$class['price']];
	          	 return json($data);
	          }
	       }else{
	          $price=$class['price'];
	       	  if($userrow['ymoney']<$price){
	          	 $data=['code'=>-1,'msg'=>'余额不足'.$class['price']];
	          	 return json($data);
	          }	       	 
	       }
			   $data = [
			     'cid'=>$cid,
			     'admin_id'=>$row['id'],
			     'huoyuan_id'=>$class['add_id'],
			     'add_cs'=>$class['add_cs'],
			     'ptname'=>$class['name'],
			     'school'=>$school,
			     'user'=>$user,
			     'pass'=>$pass,
			     'kcid'=>'',
			     'kcname'=>$kcname,
			     'fees'=>$price,
			     'ip'=>request()->ip(),
			     'createtime'=>time()
			   ];
			   $list = Db::name('wk_order')->insert($data);
		    	if($list){    	    
		    	    if($class['active']=='1'){
		    	    	$m=$userrow['money']-$price;
		    	        Db::name("admin")->update(['money'=>$m,'id'=>$row['id']]); 
		    	    	Db::name("wk_xflog")->insert(['admin_id'=>$row['id'],'type'=>'API交单','money'=>$price,'smoney'=>$m,'createtime'=>time()]);	  		   
		    	    }else{
		    	    	$m=$userrow['ymoney']-$price;
		    	        Db::name("admin")->update(['ymoney'=>$m,'id'=>$row['id']]); 	
		    	    	Db::name("wk_xflog_yy")->insert(['admin_id'=>$row['id'],'type'=>'API交单','money'=>$price,'smoney'=>$m,'createtime'=>time()]);
		    	    }
		    		$data=['code'=>1,'msg'=>'提交成功'];
		    	}else{
		    		$data=['code'=>-1,'msg'=>'未知异常'];
		    	}	    
	    	return json($data);  
        }else{
        	 $this->success("密匙不存在");
        }
    }
}
?>