<?php

return [
    'Name'     => '平台名字',
    'Price'    => '定价',
    'Cx_id'    => '查询平台',
    'Cx_cs'    => '查询参数',
    'Add_id'   => '交单平台',
    'Add_cs'   => '交单参数',
    'Content'  => '说明',
    'Status'   => '状态',
    'Status 1' => '上架',
    'Status 0' => '下架'
];
