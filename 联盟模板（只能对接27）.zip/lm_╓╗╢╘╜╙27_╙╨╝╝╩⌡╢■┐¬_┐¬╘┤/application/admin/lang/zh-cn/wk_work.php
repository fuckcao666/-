<?php

return [
    'Order_id' => '订单ID',
    'Type'     => '工单类型',
    'Content'  => '信息',
    'Status'   => '状态',
    'Status 0' => '待处理',
    'Status 1' => '已完成',
    'Status 2' => '处理中'
];
