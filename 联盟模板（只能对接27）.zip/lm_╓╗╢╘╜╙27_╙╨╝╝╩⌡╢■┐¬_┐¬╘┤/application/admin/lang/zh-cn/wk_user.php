<?php

return [
    'Uid'        => '上级ID',
    'User'       => '账号',
    'Pass'       => '密码',
    'Money'      => '余额',
    'Yqm'        => '邀请码',
    'Status'     => '状态',
    'Status 1'   => '正常',
    'Status 0'   => '封禁',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间'
];
