<?php

return [
    'Yid'         => '源站ID',
    'Admin_id'    => '用户ID',
    'Huoyuan_id'  => '下单接口ID',
    'Add_cs'      => '下单参数',
    'Ptname'      => '平台名字',
    'School'      => '学校',
    'User'        => '账号',
    'Pass'        => '密码',
    'Kcid'        => '课程ID',
    'Kcname'      => '课程名字',
    'Fees'        => '下单金额',
    'Kcks'        => '课程开始时间',
    'Kcjs'        => '课程结束时间',
    'Ksks'        => '考试开始时间',
    'Ksjs'        => '考试结束时间',
    'Ip'          => '下单ip',
    'Process'     => '进度',
    'Remarks'     => '备注',
    'Status'      => '状态',
    'Status 0'    => '待处理',
    'Status 1'    => '已完成',
    'Status 2'    => '进行中',
    'Status 3'    => '异常',
    'Status 4'    => '已退回',
    'Status_text' => '状态文本'
];
