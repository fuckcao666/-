<?php

return [
    'Name'      => '名称',
    'Type'      => '对接平台',
    'Type wklm' => '网课联盟',
    'Type 27'   => '27学习平台',
    'User'      => '账号',
    'Pass'      => '密码',
    'Money'     => '剩余余额',
    'Cookie'    => 'cookie',
    'Token'     => 'token',
    'Ip'        => '模拟IP',
    'Status'    => '状态',
    'Status 1'  => '正常',
    'Status 0'  => '关闭'
];
