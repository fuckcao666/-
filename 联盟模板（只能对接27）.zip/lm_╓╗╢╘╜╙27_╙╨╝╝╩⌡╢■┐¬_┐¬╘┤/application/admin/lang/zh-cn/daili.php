<?php

return [
    'User' => '账号',
    'Pass' => '密码'
];
