<?php

return [
    'Admin_id' => '代理ID',
    'Type'     => '消费类型',
    'Money'    => '消费金额',
    'Smoney'   => '剩余金额'
];
