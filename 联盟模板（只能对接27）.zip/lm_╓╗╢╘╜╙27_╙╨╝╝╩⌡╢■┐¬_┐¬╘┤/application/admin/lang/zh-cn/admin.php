<?php

return [
    'Id'           => 'ID',
    'Admin_id'     => '上级ID',
    'Username'     => '用户名',
    'Nickname'     => '昵称',
    'Password'     => '密码',
    'Money'        => '余额',
    'Yqm'          => '邀请码',
    'Salt'         => '密码盐',
    'Avatar'       => '头像',
    'Email'        => '电子邮箱',
    'Loginfailure' => '失败次数',
    'Logintime'    => '登录时间',
    'Loginip'      => '登录IP',
    'Createtime'   => '创建时间',
    'Updatetime'   => '更新时间',
    'Token'        => 'Session标识',
    'Status'       => '状态'
];
