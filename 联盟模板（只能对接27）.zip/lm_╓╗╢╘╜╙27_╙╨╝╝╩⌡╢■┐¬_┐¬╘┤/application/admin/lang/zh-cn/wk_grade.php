<?php

return [
    'Name'  => '等级名字',
    'Price' => '等级费率',
    'Money' => '需要金额'
];
