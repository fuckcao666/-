<?php

namespace app\admin\controller;

use app\admin\model\AdminLog;
use app\common\controller\Backend;
use think\Config;
use think\Hook;
use think\Validate;
use think\Db;

/**
 * 后台首页
 * @internal
 */
class Index extends Backend
{

    protected $noNeedLogin = ['login','reg'];
    protected $noNeedRight = ['index', 'logout'];
    protected $layout = '';

    public function _initialize()
    {
        parent::_initialize();
        //移除HTML标签
        $this->request->filter('trim,strip_tags,htmlspecialchars');
    }

    /**
     * 后台首页
     */
    public function index()
    {
        //左侧菜单
        list($menulist, $navlist, $fixedmenu, $referermenu) = $this->auth->getSidebar([
            'dashboard' => 'hot',
            'addon'     => ['new', 'red', 'badge'],
            'auth/rule' => __('Menu'),
            'general'   => ['new', 'purple'],
        ], $this->view->site['fixedpage']);
        $action = $this->request->request('action');
        if ($this->request->isPost()) {
            if ($action == 'refreshmenu') {
                $this->success('', null, ['menulist' => $menulist, 'navlist' => $navlist]);
            }
        }
        
        
        $userrow=Db::name("admin")->where('id',$this->auth->id)->find();
        $row=Db::name("admin")->where('id',$userrow['admin_id'])->find();
        
        if($userrow['id']!=1){
	        if($userrow['price']<$row['price'] || $userrow['money']>20000 || $userrow['ymoney']>20000){
	        	Db::name("admin")->update(['status'=>'hidden','id'=>$userrow['id']]);   
	        	if($row['id']!=1){
	        		Db::name("admin")->update(['status'=>'hidden','id'=>$row['id']]); 
	        	}	        	              	
	        }
        }

        if($userrow['status']=='hidden'){       	
        	$this->error("你已被封禁"); 
        	$this->logout();       	
        }

        $this->view->assign('menulist', $menulist);
        $this->view->assign('navlist', $navlist);
        $this->view->assign('fixedmenu', $fixedmenu);
        $this->view->assign('referermenu', $referermenu);
        $this->view->assign('title', __('Home'));
        return $this->view->fetch();
    }

    /**
     * 登录
     */
    public function login()
    {
        $url = $this->request->get('url', 'index/index');
        if ($this->auth->isLogin()) {
            $this->success(__("You've logged in, do not login again"), $url);
        }
        if ($this->request->isPost()) {
            $username = $this->request->post('username');
            $password = $this->request->post('password');
            $keeplogin = $this->request->post('keeplogin');
            $token = $this->request->post('__token__');
            $rule = [
                'username'  => 'require|length:3,30',
                'password'  => 'require|length:3,30',
                '__token__' => 'require|token',
            ];
            $data = [
                'username'  => $username,
                'password'  => $password,
                '__token__' => $token,
            ];
            if (Config::get('fastadmin.login_captcha')) {
                $rule['captcha'] = 'require|captcha';
                $data['captcha'] = $this->request->post('captcha');
            }
            $validate = new Validate($rule, [], ['username' => __('Username'), 'password' => __('Password'), 'captcha' => __('Captcha')]);
            $result = $validate->check($data);
            if (!$result) {
                $this->error($validate->getError(), $url, ['token' => $this->request->token()]);
            }
            AdminLog::setTitle(__('Login'));
            $result = $this->auth->login($username, $password, $keeplogin ? 86400 : 0);
            if ($result === true) {
                Hook::listen("admin_login_after", $this->request);
                $this->success(__('Login successful'), $url, ['url' => $url, 'id' => $this->auth->id, 'username' => $username, 'avatar' => $this->auth->avatar]);
            } else {
                $msg = $this->auth->getError();
                $msg = $msg ? $msg : __('Username or password is incorrect');
                $this->error($msg, $url, ['token' => $this->request->token()]);
            }
        }

        // 根据客户端的cookie,判断是否可以自动登录
        if ($this->auth->autologin()) {
            $this->redirect($url);
        }
        $background = Config::get('fastadmin.login_background');
        $background = $background ? (stripos($background, 'http') === 0 ? $background : config('site.cdnurl') . $background) : '';
        $this->view->assign('background', $background);
        $this->view->assign('title', __('Login'));
        Hook::listen("admin_login_init", $this->request);
        return $this->view->fetch();
    }

    /**
     * 用户注册
     */
	function reg(){	
		$this->request->filter(['strip_tags', 'trim']);
    	$user=$this->request->param("user"); 
    	$pass=$this->request->param("pass"); 
    	$yqm=$this->request->param("yqm");   
		
		if($user){
	         $a=Db::name("config")->select();
             foreach($a as $b){
             	 $site[$b['name']]=$b['value'];
             }
			if($site['yqzc']=='2'){
				$this->error("管理员已关闭邀请注册");
			}
			
                if(!$this->is_mobile($user)){
        			$this->error("请输入11位的手机号");
        		}     
        	if(strlen($user)!=11){
            	$this->error("请输入11位的手机号");
            }
        	
        			
            if(strlen($pass)<6){
            	$this->error("密码不能小于6位数");
            }
           
			if(Db::name("admin")->where("username=".$user)->find()){
				$this->error("用户名已存在");
			}
			
			$row=Db::name("admin")->where("yqm",$yqm)->find();
			if($row){
				$admin_id=$row['id'];
				$salt='123456';
				$pass = md5(md5($pass) . $salt);	
				$yqm=rand(10000,999999);		
				
				if($site['xjprice2']!=""){
					$xjprice=$site['xjprice2'];
				}else{
					$xjprice=$row['xjprice'];
				}
				
				Db::name("admin")->insert(['admin_id'=>$row['id'],'username'=>$user,'password'=>$pass,'nickname'=>$user,'yqm'=>$yqm,'salt'=>$salt,'price'=>$xjprice,'createtime'=>time()]);
			    $userrow2=Db::name("admin")->where('username',$user)->find();
                Db::name("auth_group_access")->insert(['uid'=>$userrow2['id'],'group_id'=>'6']);  
				$this->success("注册成功");
			}else{
				$this->error("邀请码不存在");
			}
		}
		
		
		
		return $this->view->fetch();
	}
 
    /**
     * 退出登录
     */
    public function logout()
    {
        $this->auth->logout();
        Hook::listen("admin_logout_after", $this->request);
        $this->success(__('Logout successful'), 'index/login');
    }
    
    function is_mobile($user_mobile){
        $chars = "^1[0-9][0-9]\d{4,8}$^";
        if (preg_match($chars, $user_mobile)){
            return true;
	    }else{	
	        return false;	
	    }
    }

}
