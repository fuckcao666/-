<?php

namespace app\admin\controller\general;

use app\admin\model\Admin;
use app\common\controller\Backend;
use fast\Random;
use think\Session;
use think\Validate;
use think\Db;

/**
 * 个人配置
 *
 * @icon fa fa-user
 */
class Profile extends Backend
{

    /**
     * 查看
     */
    public function index()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if ($this->request->isAjax()) {
            $this->model = model('AdminLog');
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();

            $list = $this->model
                ->where($where)
                ->where('admin_id', $this->auth->id)
                ->order($sort, $order)
                ->paginate($limit);

            $result = array("total" => $list->total(), "rows" => $list->items());

            return json($result);
        }
        
        $userrow=Db::name("admin")->where('id', $this->auth->id)->find();
       // $grade=Db::name("wk_grade")->where('id',$userrow['grade_id'])->find();
        //$this->view->assign("price",$grade['price']);
        $this->view->assign("userrow",$userrow);
        return $this->view->fetch();
    }

    /**
     * 更新个人信息
     */
    public function update()
    {
        if ($this->request->isPost()) {
            $this->token();
            $params = $this->request->post("row/a");
            $params = array_filter(array_intersect_key(
                $params,
                array_flip(array('email','information','nickname', 'password', 'avatar','xjprice'))
            ));
            unset($v);
            if (!Validate::is($params['email'], "email")) {
                $this->error(__("Please input correct email"));
            }
            
             $a=Db::name("config")->select();
             foreach($a as $b){
             	 $site[$b['name']]=$b['value'];
             }
            
            
            $userrow=Db::name("admin")->where('id', $this->auth->id)->find();
            
             if($params['xjprice']<$userrow['price']){
             	$this->error("下级默认单价不能低于你的费率");
             }
            
             if($params['xjprice']<$site['xjprice']){
             	$this->error("下级默认单价不能低于".$site['xjprice']);
             }
            

            if (isset($params['password'])) {
                if (!Validate::is($params['password'], "/^[\S]{6,16}$/")) {
                    $this->error(__("Please input correct password"));
                }
                $params['salt'] = Random::alnum();
                $params['password'] = md5(md5($params['password']) . $params['salt']);
            }
            $exist = Admin::where('email', $params['email'])->where('id', '<>', $this->auth->id)->find();
            if ($exist) {
                $this->error(__("Email already exists"));
            }
            if ($params) {
                $admin = Admin::get($this->auth->id);
                $admin->save($params);
                //因为个人资料面板读取的Session显示，修改自己资料后同时更新Session
                Session::set("admin", $admin->toArray());
                $this->success();
            }
            $this->error();
        }
        return;
    }
    
       /**
     * 重置API
     */
    public function update_API()
    {
    	$token=$this->random(16);
    	Admin::update(['token'=>$token,'id'=>$this->auth->id]);
        $data=array(
            'code'=>1,
            'msg'=>'重置成功',
            'token'=>$token
        );       
        return json($data);
    } 
    
    public function docking()
    {
    	$row=Db::name("wk_class")->where('status=2')->order('weigh desc')->select();
        foreach($row as $res){
        	$classlist[$res['id']]=$res['name'];        	
        }
        $this->view->assign('classlist',$classlist); 	
        return $this->view->fetch();
    } 
    
    function random($length, $numeric = 0) {
		$seed = base_convert(md5(microtime().$_SERVER['DOCUMENT_ROOT']), 16, $numeric ? 10 : 35);
		$seed = $numeric ? (str_replace('0', '', $seed).'012340567890') : ($seed.'zZ'.strtoupper($seed));
		$hash = '';
		$max = strlen($seed) - 1;
		for($i = 0; $i < $length; $i++) {
			$hash .= mt_rand(0, $max);
		}
		return $hash;
    }
    
}
