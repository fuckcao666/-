<?php

namespace app\admin\controller;

use app\admin\model\Admin;
use app\admin\model\User;
use app\common\controller\Backend;
use app\common\model\Attachment;
use fast\Date;
use think\Db;

/**
 * 控制台
 *
 * @icon   fa fa-dashboard
 * @remark 用于展示当前系统中的统计数据、统计报表及重要实时数据
 */
class Dashboard extends Backend
{

    /**
     * 查看
     */
    public function index()
    {
        try {
            \think\Db::execute("SET @@sql_mode='';");
        } catch (\Exception $e) {

        }
        $column = [];
        $starttime = Date::unixtime('day', -6);
        $endtime = Date::unixtime('day', 0, 'end');

        if($this->auth->id=='1'){
	        $this->view->assign([
	            'totaladmin'      => Admin::count(),
	            'order_count'     => Db::name("wk_order")->count(),
	            'todayusersignup' => Admin::whereTime('createtime', 'today')->count(),//今日注册
	            'todayuserlogin'  => Admin::whereTime('logintime', 'today')->count(),//今日登录
	            'sevendau'        => Admin::whereTime('createtime|logintime', '-7 days')->count(),
	            'thirtydau'       => Admin::whereTime('createtime|logintime', '-30 days')->count(),
	            'threednu'        => Admin::whereTime('createtime', '-3 days')->count(),
	            'order_jr_dl'     => Db::name("wk_order")->whereTime('createtime', 'today')->count()
	        ]);       	
        }else{
        	$a=Admin::where("admin_id",$this->auth->id)->select();
        	$d=0;
        	foreach($a as $b){
        		$c=Db::name("wk_order")->where("admin_id",$b['id'])->whereTime('createtime', 'today')->count();
        		$d=$d+$c;
        	}

        	$this->view->assign([
	            'totaladmin'      => Admin::where("admin_id",$this->auth->id)->count(),
	            'order_count'     => Db::name("wk_order")->where("admin_id",$this->auth->id)->count(),
	            'todayusersignup' => Admin::whereTime('createtime', 'today')->where("admin_id",$this->auth->id)->count(),//今日注册
	            'todayuserlogin'  => Admin::whereTime('logintime', 'today')->where("admin_id",$this->auth->id)->count(),//今日登录
	            'sevendau'        => Admin::whereTime('createtime|logintime', '-7 days')->where("admin_id",$this->auth->id)->count(),
	            'thirtydau'       => Admin::whereTime('createtime|logintime', '-30 days')->where("admin_id",$this->auth->id)->count(),
	            'threednu'        => Admin::whereTime('createtime', '-3 days')->where("admin_id",$this->auth->id)->count(),	
	            'order_jr_dl'     => $d 
	        ]);     	
        }
        return $this->view->fetch();
    }
    
    
    function admincount(){	
	    $starttime = Date::unixtime('day', -6);
        $endtime = Date::unixtime('day', 0, 'end');
		$this->view->assign([
            'admin_count'      => Admin::count(),
            'order_count'     => Db::name("wk_order")->count(),            
            'admin_jr_zc' => Admin::whereTime('createtime', 'today')->count(),//今日注册
            'admin_jr_dl'  => Admin::whereTime('logintime', 'today')->count(),//今日登录
            'admin_30_dl'  => Admin::whereTime('logintime', '-30 days')->count(),//30天内登录
            'order_jr'     => Db::name("wk_order")->whereTime('createtime', 'today')->count(),   
        ]);  	
        
        
        $jrcount=[];
        $class=Db::name("wk_class")->select();
        foreach($class as $row){
        	$count=Db::name("wk_order")->whereTime('createtime', 'today')->where('cid',$row['id'])->count();
        	$jrcount[$row['name']]=$count;
        }
             
        $this->view->assign("jrcount",$jrcount);
    	return $this->view->fetch();
    }  
     
     //充值与帮助
    function czhelp(){
    	
    	$userrow=Db::name("admin")->where('id',$this->auth->id)->find();
    	$row=Db::name("admin")->where('id',$userrow['admin_id'])->find();
    	$this->view->assign("row",$row);
    	return $this->view->fetch();
    }




}
