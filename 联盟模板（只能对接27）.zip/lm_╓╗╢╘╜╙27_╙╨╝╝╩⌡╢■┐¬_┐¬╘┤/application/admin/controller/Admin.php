<?php

namespace app\admin\controller;

use app\common\controller\Backend;
use think\Db;
use fast\Random;

/**
 * 管理员管理
 *
 * @icon fa fa-circle-o
 */
class Admin extends Backend
{
    
    /**
     * Admin模型对象
     * @var \app\admin\model\Admin
     */
    protected $model = null;
    protected $relationSearch = true;
    
	protected $modelValidate = true; //是否开启Validate验证，默认是false关闭状态
	protected $modelSceneValidate = true; //是否开启模型场景验证，默认是false关闭状态
    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\Admin;
               
//      $userrow=$this->model->get($this->auth->id);   
//      $grade1=Db::name("wk_grade")->where('id',$userrow['grade_id'])->find();             
//      $grade=Db::name("wk_grade")->where("price>".$grade1['price'])->order("price desc")->select();
//	    foreach($grade as $res){
//	    	$gradelist[$res['id']]=$res['name']."（单价：".$res['price']."）";        	
//	    }	    
//	    $this->view->assign('gradelist',$gradelist); 
    }

    public function import()
    {
        parent::import();
    }

    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */

    public function index()
    {    	
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }

            list($where, $sort, $order, $offset, $limit) = $this->buildparams();

                $total = $this->model
                ->where($where)
                ->where("admin_id=".$this->auth->id)
                ->order($sort, $order)
                ->count();
                $list = $this->model
	            ->where($where)
	            ->where("admin_id=".$this->auth->id)
	            ->order($sort, $order)
	            ->limit($offset, $limit)
	            ->select();
            
            $result = array("total" => $total, "rows" => $list);

            return json($result);
        }
        return $this->view->fetch();
    }
   
   
    public function add()
    {
        if ($this->request->isPost()) {
        	$this->token();
            $params = $this->request->post("row/a");
            if ($params) {
                $params = $this->preExcludeFields($params);

                if ($this->dataLimit && $this->dataLimitFieldAutoFill) {
                    $params[$this->dataLimitField] = $this->auth->id;
                }
                
                
                if(!$this->is_mobile($params['username'])){
        			$this->error("请输入11位的手机号");
        		}   
        	if(strlen($params['username'])!=11){
            	$this->error("请输入11位的手机号");
            }
                $result = false;
                Db::startTrans();
                try {
                    //是否采用模型验证
                    if ($this->modelValidate) {
                        $name = str_replace("\\model\\", "\\validate\\", get_class($this->model));
                        $validate = is_bool($this->modelValidate) ? ($this->modelSceneValidate ? $name . '.add' : $name) : $this->modelValidate;
                        $this->model->validateFailException(true)->validate($validate);
                    }
                    
                     $a=Db::name("config")->select();
                     foreach($a as $b){
                     	 $site[$b['name']]=$b['value'];
                     }

                     $jrzc=Db::name("admin")->whereTime('createtime', 'today')->where("admin_id",$this->auth->id)->count();                    
                     
                     if($jrzc>=$site['user_ktsx']){
                     	 $this->error("已超过当日开户上限".$site['user_ktsx']."个");
                     }

                    $userrow=$this->model->get($this->auth->id); 
//                  $grade1=Db::name("wk_grade")->where('id',$params['grade_id'])->find();
//                  $grade2=Db::name("wk_grade")->where('id',$userrow2['grade_id'])->find();
                    $params['yqm']=rand(10000,999999);

                    if($params['price']>$userrow['price']){                    	
                    	if(($params['price']*100 % 5)!=0){
	            		    $this->error("请输入单价为0.05的倍数");
	            	    }

	                    $params['admin_id']=$this->auth->id;
	                    $params['salt'] = Random::alnum();
	                    $params['password'] = md5(md5($params['password']) . $params['salt']);
	                    $result = $this->model->allowField(true)->save($params);
	                     
	                    $userrow2=Db::name("admin")->where('username',$params['username'])->find();
	                    Db::name("auth_group_access")->insert(['uid'=>$userrow2['id'],'group_id'=>'6']);                                      
	                    Db::commit();    	
                    }else{
                    	$this->error("用户单价不能比你低哦，也不能相等");
                    }
                   
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success();
                } else {
                    $this->error(__('No rows were inserted'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }
        return $this->view->fetch();
    }
    
     /**
     * 代理充值余额
     */
    function czmoney(){
    	$this->request->filter(['strip_tags', 'trim']);
    	$res=$this->request->param();
    	$ids=$res['ids'];   
    	if(isset($res['row'])){
    		$this->token();
    		$active=$res['row']['active'];
    		$row=$this->model->get($ids); 	
    		$userrow=$this->model->get($this->auth->id); 
    		if($row['admin_id']==$this->auth->id || $this->auth->id==1){
    			if(!preg_match('/^[0-9.]+$/', $res['row']['newmoney'])){
    				$this->error("充值金额不合法");
    			}
    			if($res['row']['newmoney']<0){$this->error("金额异常");}
    			    	
				 $a=Db::name("config")->select();
	             foreach($a as $b){
	             	 $site[$b['name']]=$b['value'];
	             }    	
    			    	
    			    			
    			if($active=='1'){
    				   if($res['row']['newmoney']<$site['ptcz']){
    				     	$this->error("普通最低充值金额为".$site['ptcz']);
    				   }
    				   				
    				   $money=$res['row']['newmoney']*($userrow['price']/$row['price']);//扣除金额
		    		   if($money<=$userrow['money']){		    		   			    		   	     
		    		   	     $w_money=$userrow['money']-$money;
		    		   	     $x_money=$row['money']+$res['row']['newmoney'];    		   	        		   	      
		    		     	 Db::name("wk_xflog")->insert(['admin_id'=>$this->auth->id,'type'=>'充值'.$row['username'],'money'=>$money,'smoney'=>$w_money,'createtime'=>time(),'updatetime'=>0]);
		    		     	 Db::name("wk_xflog")->insert(['admin_id'=>$ids,'type'=>'被邀请码'.$userrow['yqm'].'充值','money'=>$res['row']['newmoney'],'smoney'=>$x_money,'createtime'=>time(),'updatetime'=>0]);
		    		     	 Db::name("admin")->update(['money'=>$w_money,'id'=>$this->auth->id]);
		    		     	 Db::name("admin")->update(['money'=>$x_money,'id'=>$ids]);
		    		     	 $this->success("成功给下级充值".$res['row']['newmoney']."元，扣除".$money."元");
		    		   }else{    		   	 
		    		   	   $this->error("余额不足");
		    		   }  
    			}elseif($active=='2'){
    				   if($res['row']['newmoney']<$site['pjcz']){
    				     	$this->error("平价最低充值金额为".$site['pjcz']);
    				   }
    				   
		    		   if($res['row']['newmoney']<=$userrow['ymoney']){
		    		   	     $w_money=$userrow['ymoney']-$res['row']['newmoney'];
		    		   	     $x_money=$row['ymoney']+$res['row']['newmoney'];    		   	        		   	      
		    		     	 Db::name("wk_xflog_yy")->insert(['admin_id'=>$this->auth->id,'type'=>'充值'.$row['username'],'money'=>$res['row']['newmoney'],'smoney'=>$w_money,'createtime'=>time()]);
		    		     	 Db::name("wk_xflog_yy")->insert(['admin_id'=>$ids,'type'=>'被邀请码'.$userrow['yqm'].'充值','money'=>$res['row']['newmoney'],'smoney'=>$x_money,'createtime'=>time()]);
		    		     	 Db::name("admin")->update(['ymoney'=>$w_money,'id'=>$this->auth->id]);
		    		     	 Db::name("admin")->update(['ymoney'=>$x_money,'id'=>$ids]);
		    		     	 $this->success("成功给下级充值".$res['row']['newmoney']."元,扣除".$res['row']['newmoney']."元");
		    		   }else{    		   	 
		    		   	   $this->error("余额不足");
		    		   }      				   				
    			}else{
    				$this->error("未知异常");
    			}    			   		     		
    		}else{
    			$this->error("无权限");
    		}	
  	    }else{
    		 $row=$this->model->get($ids);    	
             $this->view->assign('row',$row);
  	    }
    	return $this->view->fetch();	
    }
    
    /**
     * 重置密码
     */   
    function czmm(){
    	$this->request->filter(['strip_tags', 'trim']);
    	$res=$this->request->param();
    	$ids=$res['ids'];
    	$row=$this->model->get($ids); 
    	if($row['admin_id']==$this->auth->id || $this->auth->id==1){
              $pass = md5(md5('123456') . $row['salt']);
    		  Db::name("admin")->update(['password'=>$pass,'id'=>$ids]);    	
    	      $this->success("成功重置密码为123456");
    	}else{
    		  $this->error("无权限");
    	}    
    }
     /**
     * 编辑
     */     
    function edit($ids = null){
    	$this->request->filter(['strip_tags', 'trim']);
    	$row = $this->model->get(['id' => $ids]);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        if ($this->request->isPost()) {
            $this->token();
            $params = $this->request->post("row/a");
            $userrow = $this->model->get(['id' => $this->auth->id]);
            if ($params) { 
            	if($params['yqm']!=''){
            		if(strlen($params['yqm'])<4){
            			$this->error("邀请码不能低于4位");
            		}                 	
            				
	            	$yqm=Db::name("admin")->where('yqm',$params['yqm'])->find();                        
	                if($yqm){
	                	if($row['id']!=$yqm['id']){
	                	  $this->error("邀请码已存在");	                		
	                	}
	                } 
	                
	                 $a=Db::name("config")->select();
                     foreach($a as $b){
                     	 $site[$b['name']]=$b['value'];
                     }
	                
	                
	                if($yqm['yqm']!=$row['yqm']){
	                	if($userrow['price']>$site['yqszprice']){
                         	$this->error("0.35以下的单价用户没有权限设置邀请码");	
                        }
	                }
	                   
            	}
            	
                if($params['password']!=''){                        
                    $pass = md5(md5($params['password']) . $row['salt']);
                }else{
                	$pass=$row['password'];
                }
                
//              $grade1=Db::name("wk_grade")->where('id',$params['grade_id'])->find();
//              $grade2=Db::name("wk_grade")->where('id',$userrow['grade_id'])->find(); 
                if($params['price']!=''){
                   if($params['price']<$userrow['price']){
                	  $this->error("你下级的单价不能比你低哦");
                   }
	               	if(strlen($params['price']/0.05)>2){
	            		$this->error("请输入单价为0.05的倍数");
	            	} 
	            	
	            	if($params['price']<$row['price']){
	            		$money=$row['money']*($params['price']/$row['price'] );//当前金额x新费率/旧费率
	            	}else{
	            		$money=$row['money'];
	            	}

                }else{
                	 $this->error("单价不能为空");
                }
              
                Db::name("admin")->update(['password'=>$pass,'money'=>$money,'price'=>$params['price'],'yqm'=>$params['yqm'],'status'=>$params['status'],'id'=>$ids]);
                $this->success();
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }

        $this->view->assign("row", $row);
        return $this->view->fetch();	
    }
    function del($ids = null){
    	$this->error("你在干啥？");  	
    }
    
    
    function is_mobile($user_mobile){
        $chars = "^1[0-9][0-9]\d{4,8}$^";
    if (preg_match($chars, $user_mobile)){
            return true;
	    }else{	
	        return false;	
	    }
    }
}
