<?php

namespace app\admin\controller\auth;

use app\common\controller\Backend;
use think\Db;
        
/**
 * 
 *
 * @icon fa fa-circle-o
 */
class Order extends Backend
{
    
    /**
     * Order模型对象
     * @var \app\admin\model\auth\Order
     */
    protected $model = null;
    protected $wk = null;
    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\auth\Order;
        $this->wk=new \wangke\Duijie;
        $this->view->assign("statusList", $this->model->getStatusList());
    }

    public function import()
    {
        parent::import();
    }

    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */
    
    function dock($ids=null){
    	  $row=$this->model->get($ids);   	  
    	  if($row['dockstatus']=='1'){
    	  	 $this->error("该订单已经对接成功了哦");
    	  }
   	   	  $class=Db::name("wk_class")->where('id='.$row['cid'])->find();   	   	  
   	   	  if($class){
   	   	  	$hy=Db::name("wk_huoyuan")->where('id='.$class['add_id'])->find();
   	   	  	$result=$this->wk->add($row,$class,$hy);
	   	   	  if($result['code']=='1'){	   	   	  	
	   	   	  	 Db::name("wk_order")->update(['dockstatus'=>'1','huoyuan_id'=>$hy['id'],'add_cs'=>$class['add_cs'],'id'=>$row['id']]);
	   	   	     $this->success($result['msg']);
	   	   	  }else{
	   	   	  	 $this->error($result['msg']);
	   	   	  } 
   	   	  }
 
    }
    function tongbu($ids=null){
    	  $row=$this->model->get($ids);   	  
   	   	  $hy=Db::name("wk_huoyuan")->where('id='.$row['huoyuan_id'])->find();
   	   	  $result=$this->wk->update($row,$hy);   	   	   	    	 
	   	  $this->success($ids."订单同步成功");
    }

}
