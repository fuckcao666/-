<?php

namespace app\admin\controller;

use app\common\controller\Backend;
use think\Db;
use think\Config;
use app\admin\model\Admin;
use app\admin\model\WkClass;
/**
 * 
 *
 * @icon fa fa-circle-o
 */
class Add extends Backend
{
    
    /**
     * Add模型对象
     * @var \app\admin\model\Add
     */
    protected $wk = null;
    protected $model = null;
    protected $childrenGroupIds = [];
    protected $childrenAdminIds = [];
    protected $relationSearch = false;//是否关联查询
    
    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\Add;
        $this->wk = new \wangke\Duijie;
    }

    public function import()
    {
        parent::import();
    }

    public function index(){     	
    	$userrow=Admin::where('id='.$this->auth->id)->find();
    	//$grade=Db::name("wk_grade")->where('id='.$userrow['grade_id'])->find();
        //$row=Db::name("wk_class")->where('active=1 and status=2')->order('weigh desc')->select(); 
        $row=WkClass::where('active=1 and status=2')->order('weigh desc')->select();
        foreach($row as $res){
        	$price=$userrow['price']*$res['price'];
        	$classlist[$res['id']]="【".$res['name']."】单课".$price;  
        	$classprice[$res['name']]=$res['price'];         	
        }
        $this->view->assign('classlist',$classlist);
        $this->view->assign('classprice',$classprice);
        $this->view->assign('myprice',$userrow['price']); 	  	
    	return $this->view->fetch();  	
    }
    
    public function yy(){  
        $row=Db::name("wk_class")->where('active=2 and status=2')->order('weigh desc')->select();
        foreach($row as $res){
        	$classlist[$res['id']]="【".$res['name']."】单课".$res['price'];        	
        }
        $this->view->assign('classlist',$classlist); 	  	
    	return $this->view->fetch();  	
    }
    
     /**
     * 查询
     */
    public function get(){
    	//设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
    	$cid=$this->request->param("cid"); 
    	$userinfo=$this->request->param("userinfo"); 	
    	if($cid=='' || $userinfo==''){
    		$data=['code'=>-1,'msg'=>'所有项目不能为空'];
    	}else{   		
	    	$kms = str_replace(array("\r\n", "\r", "\n"), "[br]", $userinfo);
			$info=explode("[br]",$kms);				
			$str = preg_replace("/\s+/"," ",trim($info[0]));
			$class=Db::name("wk_class")->where('id='.$cid)->find();
			$huoyuan=Db::name("wk_huoyuan")->where('id='.$class['cx_id'])->find();               
            $result=$this->wk->get($huoyuan,$class['cx_cs'],$str);		 
    	}     
    	return json($result);   	
    }
     
     /**
     * 提交订单
     */
    public function add(){
    	$this->request->filter(['strip_tags', 'trim']);
    	$cid=$this->request->param("cid"); 
    	$addinfo=$this->request->param("addinfo");   	
    	if($cid=='' || $addinfo==''){
    		$data=['code'=>-1,'msg'=>'所有项目不能为空'];
    	} 
    	$a=explode("|",$addinfo);
    	$userinfo=explode(" ",$a[0]);
    	$school=$userinfo[0];
    	$user=$userinfo[1];
    	$pass=$userinfo[2];
    	$kcname=$a[1];
    	
       $class=Db::name("wk_class")->where('id='.$cid)->find();
       $userrow=Db::name("admin")->where('id='.$this->auth->id)->find();
//     $grade=Db::name("wk_grade")->where('id='.$userrow['grade_id'])->find();
       if($class['active']=='1'){
          $price=$class['price']*$userrow['price'];
          if($userrow['money']<$price){
          	 $data=['code'=>-1,'msg'=>'余额不足'.$class['price']];
          	 return json($data);
          }
       }else{
          $price=$class['price'];
       	  if($userrow['ymoney']<$price){
          	 $data=['code'=>-1,'msg'=>'余额不足'.$class['price']];
          	 return json($data);
          }
       	 
       }
		   $data = [
		     'cid'=>$cid,
		     'yid'=>'',
		     'userName'=>'',
		     'kcks'=>'',
		     'kcjs'=>'',
		     'ksks'=>'',
		     'ksjs'=>'',
		     'admin_id'=>$this->auth->id,
		     'huoyuan_id'=>$class['add_id'],
		     'add_cs'=>$class['add_cs'],
		     'ptname'=>$class['name'],
		     'school'=>$school,
		     'user'=>$user,
		     'pass'=>$pass,
		     'kcid'=>'',
		     'kcname'=>$kcname,
		     'fees'=>$price,
		     'ip'=>request()->ip(),
		     'createtime'=>time(),
		     'updatetime'=>time()
		   ];
		   $list = Db::name('wk_order')->insert($data);
	    	if($list){    	    
	    	    if($class['active']=='1'){
	    	    	$m=$userrow['money']-$price;
	    	        Db::name("admin")->update(['money'=>$m,'id'=>$this->auth->id]); 
	    	    	//Db::name("wk_xflog")->insert(['admin_id'=>$this->auth->id,'type'=>'交单','money'=>$price,'smoney'=>$m,'createtime'=>time()]);	  		   
	    	    }else{
	    	    	$m=$userrow['ymoney']-$price;
	    	        Db::name("admin")->update(['ymoney'=>$m,'id'=>$this->auth->id]); 	
	    	    	//Db::name("wk_xflog_yy")->insert(['admin_id'=>$this->auth->id,'type'=>'交单','money'=>$price,'smoney'=>$m,'createtime'=>time()]);
	    	    }
	    		$data=['code'=>1,'msg'=>'提交成功'];
	    	}else{
	    		$data=['code'=>-1,'msg'=>'未知异常'];
	    	}	    
    	return json($data); 
    }
    
    

}
?>