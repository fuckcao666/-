<?php
    $website_name = '小八网课系统';#网站名称
    $default_password = '123456';#默认开户密码
?>