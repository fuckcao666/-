<?php
setcookie('Admin-Token');
echo '{"code":20000,"data":"success"}';
?>