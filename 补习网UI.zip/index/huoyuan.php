<?php
$title='编辑平台网课';
require_once('head.php');
if($userrow['uid']!=1){exit("<script language='javascript'>window.location.href='login.php';</script>");}
?>
    <style> .spss{
                 background: linear-gradient( 
45deg , #42e695, #3bb2b8)!important;border-radius:5px;    width: 100%!important;color:#fff;    padding: .35em .65em;
    font-size: .75em;
    font-weight: 700;}</style>
  <div class="lyear-layout-content" role="main">
     <div class="app-content-body ">
        <div class="wrapper-md control" id="orderlist">
        	
	    <div class="panel panel-default" style="box-shadow: 8px 8px 15px #d1d9e6, -18px -18px 30px #fff; border-radius:8px;">
		    <div class="panel-heading font-bold" style="border-top-left-radius: 8px; border-top-right-radius: 8px;background-color:#fff;"><div style="height:20px;width:5px;background-color:#af92ff;float:left;border-radius:4px;margin-right: 5px;"></div>平台列表&nbsp;<button class="btn btn-xs" data-toggle="modal" data-target="#modal-add" style="background-color: rgb(112, 136, 239); border-radius: 5px; color: rgb(255, 255, 255); margin-left: 20px;">添加</button></div>
				 <div class="panel-body">
		      <div class="table-responsive">
		        <table class="table table-striped">
		          <thead><tr><th>ID</th><th>名称</th><th>平台</th><th>账号</th><th>密码</th><th>网址</th><th>密钥/token</th><th>添加时间</th><th>操作</th></tr></thead>
		          <tbody>
		            <tr v-for="res in row.data">
		            	<td>{{res.hid}}</td>		            	
		            	<td>{{res.name}}</td>
		            	<td>{{res.pt}}</td>
		            	<td>{{res.user}}</td>
		            	<td>{{res.pass}}</td>
		            	<td>{{res.url}}</td>
		            	<td>{{res.token}}</td>
		            	<td>{{res.addtime}}</td>
		                <td><button class="spss" data-toggle="modal" data-target="#modal-update" @click="storeInfo=res">编辑</button></td>    	
		            </tr>
		          </tbody>
		        </table>
		      </div>
		      
			     <ul class="pagination" v-if="row.last_page>1"><!--by 青卡 Vue分页 -->
			         <li class="disabled"><a @click="get(1)">首页</a></li>
			         <li class="disabled"><a @click="row.current_page>1?get(row.current_page-1):''">&laquo;</a></li>
		             <li  @click="get(row.current_page-3)" v-if="row.current_page-3>=1"><a>{{ row.current_page-3 }}</a></li>
						    <li  @click="get(row.current_page-2)" v-if="row.current_page-2>=1"><a>{{ row.current_page-2 }}</a></li>
						    <li  @click="get(row.current_page-1)" v-if="row.current_page-1>=1"><a>{{ row.current_page-1 }}</a></li>
						    <li :class="{'active':row.current_page==row.current_page}" @click="get(row.current_page)" v-if="row.current_page"><a>{{ row.current_page }}</a></li>
						    <li  @click="get(row.current_page+1)" v-if="row.current_page+1<=row.last_page"><a>{{ row.current_page+1 }}</a></li>
						    <li  @click="get(row.current_page+2)" v-if="row.current_page+2<=row.last_page"><a>{{ row.current_page+2 }}</a></li>
						    <li  @click="get(row.current_page+3)" v-if="row.current_page+3<=row.last_page"><a>{{ row.current_page+3 }}</a></li>		       			     
			         <li class="disabled"><a @click="row.last_page>row.current_page?get(row.current_page+1):''">&raquo;</a></li>
			         <li class="disabled"><a @click="get(row.last_page)">尾页</a></li>	    
			     </ul>      
		    </div>
		  </div>
  
  
  
        <div class="modal fade primary" id="modal-update">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
                        </button>
                        <h4 class="modal-title">平台修改</h4>
                    </div>
           
                    <div class="modal-body">
                        <form class="form-horizontal" id="form-update">
                            <input type="hidden" name="action" value="update"/>
                            <input type="hidden" name="hid" :value="storeInfo.hid"/>
                             <div class="form-group">
                               <label class="col-sm-3 control-label">名称</label>
                                <div class="col-sm-9">             
                                  <input type="text" name="name" class="form-control" :value="storeInfo.name" placeholder="输入自定义名称">
                               </div>
                            </div>
                            <div class="form-group">
                               <label class="col-sm-3 control-label">平台</label>
	                            <div class="col-sm-9">   
		                            <select name="pt" class="form-control" :value="storeInfo.pt">
		                            	<?php
		                            		$a=wkname();
		                            		   foreach($a as $key => $value){ 	                            		   	
		                            		      echo	'<option value="'.$key.'">'.$value.'</option>';													
										        }
										?>
		                            </select>
		                        </div>
                            </div>
                            <div class="form-group">
                               <label class="col-sm-3 control-label">域名</label>
                                <div class="col-sm-9">             
                                  <input type="text" name="url" class="form-control" :value="storeInfo.url" placeholder="输入域名">
                               </div>
                            </div>
                            <div class="form-group">
                               <label class="col-sm-3 control-label">账号</label>
                                <div class="col-sm-9">             
                                  <input type="text" name="user" class="form-control" :value="storeInfo.user" placeholder="输入账号,27填uid">
                               </div>
                            </div>
                            <div class="form-group">
                               <label class="col-sm-3 control-label">密码</label>
                                <div class="col-sm-9">             
                                  <input type="text" name="pass" class="form-control" :value="storeInfo.pass" placeholder="输入密码,27填key">
                               </div>
                            </div>
                            <div class="form-group">
                               <label class="col-sm-3 control-label">密匙/token</label>
                                <div class="col-sm-9">             
                                  <input type="text" name="token" class="form-control" :value="storeInfo.token" placeholder="输入密匙/token，没有则不输入">
                               </div>
                            </div>
                            <!--<div class="form-group">-->
                            <!--   <label class="col-sm-3 control-label">IP</label>-->
                            <!--    <div class="col-sm-9">             -->
                            <!--      <input type="text" name="ip" class="form-control" :value="storeInfo.ip" placeholder="模拟指定IP对接，请输入ip地址，不指定留空">-->
                            <!--   </div>-->
                            <!--</div>                           -->
                            <div class="form-group">
                               <label class="col-sm-3 control-label">cookie</label>
                                <div class="col-sm-9"> 
                                  <textarea name="cookie"  placeholder="没必要，不用输入" class="form-control" :value="storeInfo.cookie" rows="4"></textarea>           
                               </div>
                            </div>                              
                         </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="el-button el-button--default el-button--small" data-dismiss="modal">取消</button>
                        <button type="button" class="el-button el-button--default el-button--small el-button--primary " style="border:0px;background-color:#7366ff;" @click="form('update')">确定</button>
                    </div>
                </div>
            </div>
        </div>
  
  
        <div class="modal fade primary" id="modal-add">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
                        </button>
                        <h4 class="modal-title">平台添加</h4>
                    </div>
           
                    <div class="modal-body">
                        <form class="form-horizontal" id="form-add">
                            <input type="hidden" name="action" value="add"/>
                            <div class="form-group">
                               <label class="col-sm-3 control-label">名称</label>
                                <div class="col-sm-9">             
                                  <input type="text" name="name" class="form-control"  placeholder="输入自定义名称">
                               </div>
                            </div>
                            <div class="form-group">
                               <label class="col-sm-3 control-label">平台</label>
	                            <div class="col-sm-9">   
		                            <select name="pt" class="form-control">
		                            	<?php
		                            		$a=wkname();
		                            		   foreach($a as $key => $value){ 	                            		   	
		                            		      echo	'<option value="'.$key.'">'.$value.'</option>';													
										        }
										?>
		                            </select>
		                        </div>
                            </div>
                            <div class="form-group">
                               <label class="col-sm-3 control-label">域名</label>
                                <div class="col-sm-9">             
                                  <input type="text" name="url" class="form-control"  placeholder="输入域名">
                               </div>
                            </div>
                            <div class="form-group">
                               <label class="col-sm-3 control-label">账号</label>
                                <div class="col-sm-9">             
                                  <input type="text" name="user" class="form-control"  placeholder="输入账号,27填uid">
                               </div>
                            </div>
                            <div class="form-group">
                               <label class="col-sm-3 control-label">密码</label>
                                <div class="col-sm-9">             
                                  <input type="text" name="pass" class="form-control"  placeholder="输入密码,27填key">
                               </div>
                            </div>
                            <div class="form-group">
                               <label class="col-sm-3 control-label">密匙/token</label>
                                <div class="col-sm-9">             
                                  <input type="text" name="token" class="form-control" placeholder="输入密匙/token，没有则不输入">
                               </div>
                            </div>
                            <!--<div class="form-group">-->
                            <!--   <label class="col-sm-3 control-label">IP</label>-->
                            <!--    <div class="col-sm-9">             -->
                            <!--      <input type="text" name="ip" class="form-control" placeholder="模拟指定IP对接，请输入ip地址，不指定留空">-->
                            <!--   </div>-->
                            <!--</div>                           -->
                            <div class="form-group">
                               <label class="col-sm-3 control-label">cookie</label>
                                <div class="col-sm-9"> 
                                  <textarea name="cookie"  placeholder="没必要，不用输入"  class="form-control" rows="4"></textarea>           
                               </div>
                            </div>                           
                         </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">取消</button>
                        <button type="button" class="btn btn-success" @click="form('add')">确定</button>
                    </div>
                </div>
            </div>
        </div>
  
  
  
  
    </div>
   </div>
 </div>
 
 
 
 
 
 
<?php require_once("footer.php");?>	
<script>
new Vue({
	el:"#orderlist",
	data:{
		row:null,
		storeInfo:{}
	},
	methods:{
		get:function(page){
		  var load=layer.load();
 			this.$http.post("/apisub.php?act=huoyuanlist",{page:page},{emulateJSON:true}).then(function(data){	
	          	layer.close(load);
	          	if(data.data.code==1){			                     	
	          		this.row=data.body;			             			                     
	          	}else{
	                layer.msg(data.data.msg,{icon:2});
	          	}
	        });	
		},
		form:function(form){
		   var load=layer.load();
 			this.$http.post("/apisub.php?act=uphuoyuan",{data:$("#form-"+form).serialize()},{emulateJSON:true}).then(function(data){	
	          	layer.close(load);
	          	if(data.data.code==1){			                     		          		
	          		this.get(this.row.current_page);
	          		$("#modal-" + form).modal('hide');
	          		layer.msg(data.data.msg,{icon:1});	             			                     
	          	}else{
	                layer.msg(data.data.msg,{icon:2});
	          	}
	        });	
		},
		bs:function(oid){
			layer.msg(oid);
		}
	},
	mounted(){
		this.get(1);
	}
});
</script>