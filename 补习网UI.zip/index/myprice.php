<?php
$mod='blank';
$title='价格列表';
require_once('head.php');
?>
  
<div class="lyear-layout-content" role="main">
     <div class="app-content-body ">
         <div class="container-fluid">
         <div class="row">
             
             <div class="col-sm-12 col-lg-12">
            <div class="card" style=" border-radius:8px;box-shadow: 8px 8px 15px #d1d9e6, -18px -18px 30px #fff;" >
              <div class="card-header" style="">
                <h4 > <b><div style="height:20px;width:5px;background-color:#af92ff;float:left;border-radius:4px;margin-right: 5px;"></div>注意：我的价格=倍数X我的费率</b></h4>
                <ul class="card-actions">
                  <li>
                    <button type="button"></button>
                  </li>
                </ul>
              </div>
              <style> .spss{
                 background: linear-gradient( 
45deg , #42e695, #3bb2b8)!important;border-radius:5px;    width: 100%!important; height:13px;color:#fff;    padding: .35em .65em;
    font-size: .75em;
    font-weight: 700;}</style>
              <div class="card-body" style="margin-top:10px;">
                 <div class="table-responsive"> 
				         <table class="table ">
				              <thead><tr><th style="padding: 20px;">ID</th><th style="padding: 20px;">开户价格</th><th style="padding: 20px;">一次性充值</th><th style="padding: 20px;">3000元</th><th style="padding: 20px;">1000元</th><th style="padding: 20px;">700元</th><th style="padding: 20px;">500元</th><th style="padding: 20px;">300元</th><th style="padding: 20px;">100元</th><th style="padding: 20px;">我的价格（<?php echo $userrow['addprice']?>）</th></thead>
				          <thead><tr><th style="padding: 20px;">ID</th><th style="padding: 20px;">平台名称</th><th style="padding: 20px;">倍数X我的费率</th><th style="padding: 20px;">0.1</th><th style="padding: 20px;">0.2</th><th style="padding: 20px;">0.3</th><th style="padding: 20px;">0.4</th><th style="padding: 20px;">0.5</th><th style="padding: 20px;">0.6</th><th style="padding: 20px;">我的价格（<?php echo $userrow['addprice']?>）</th></thead>
				          <tbody>				          	
							<?php 
	                     	 $a=$DB->query("select * from qingka_wangke_class where status=1 ");
	                     	 while($rs=$DB->fetch($a)){
	                     	 	  echo "<tr><td style='padding: 20px;'>".$rs['cid']."</td>
	                     	 	  	<td style='padding: 20px;'>".$rs['name']."</td>
	                     	 	  	<td style='padding: 20px;'>(".$rs['price']."倍) X 我的费率</td>
	                     	 	
	                     	    	<td style='padding: 20px;'>".($rs['price']*0.1). "</td>
	                     	 	  	<td style='padding: 20px;'>".($rs['price']*0.2). "</td>
	                     	 	  	<td style='padding: 20px;'>".($rs['price']*0.3). "</td>
	                     	 	  	<td style='padding: 20px;'>".($rs['price']*0.4). "</td>
	                     	 	  	<td style='padding: 20px;'>".($rs['price']*0.5). "</td>
	                     	 	  	<td style='padding: 20px;'>".($rs['price']*0.6). "</td>
	                     	 	  	<td  style='padding: 20px;'><span class='spss'>".($rs['price']*$userrow['addprice'])."</span></td>
	                     	 	  	</tr>"; 
	                     	 }
	                     	?>		           
				          </tbody>
				        </table>
				      </div>
              </div>
            </div>   </div> </div>   </div>
            
     
    </div>
</div>

<script src="./assets/js/shuiyin.js"></script>
<script type="text/javascript">
var now = getNow();
watermark ({"watermark_txt":"simon"});
</script>

<script type="text/javascript" src="assets/LightYear/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/main.min.js"></script>
<script src="assets/js/aes.js"></script>
<script src="https://cdn.staticfile.org/vue/2.6.11/vue.min.js"></script>
<script src="https://cdn.staticfile.org/vue-resource/1.5.1/vue-resource.min.js"></script>
<script src="https://cdn.staticfile.org/axios/0.18.0/axios.min.js"></script>

 



