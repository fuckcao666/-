<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
   <title><?=$conf['sitename'];?>用户登录</title>
        <meta name="keywords" content="<?=$conf['sitename'];?>"/>
        <meta name="description" content="<?=$conf['sitename'];?>"/>
        
       <link rel="stylesheet" type="text/css" href="https://element.eleme.cn/docs.10df231.css">
    <link rel="stylesheet" href="https://element.eleme.cn/element-ui.91647e9.css">
    <link rel="stylesheet" href="assets/css/element.css">
		<link rel="stylesheet" href="../assets/elm/layui.css">
		<link href="../assets/elm/tailwind.min.css" rel="stylesheet">
		<link href="../assets/elm/loginstyle.css" rel="stylesheet">
	</head>
    <style>

element.style {
}
.mt-12 {
    margin-top: 0.1rem;}
        .dlbox .weixin, .dlbox .reg .login {
            display: inline-block;
            width: 32px;
            height: 32px;
            background-size: cover;
        }
.sss{display: inline-block;width: 32px;height: 32px;background-size: cover;border:0px;}
        .dlbox .weixin {
            background-image: url(/index/assets/images/qq.png);
            
        }

      .dlbox .login {
            background-image: url(/index/assets/images/login.png);
              display: inline-block;
                  : 32px;
    height: 32px;
             background-size: cover;
  
}
   
		.bg-indigo-100 {
    background-color: #ebf4ff;
}.border-gray-200 {
    border-color: #edf2f7;
}.bg-gray-100 {
    background-color: #f7fafc;
}.bg-indigo-500 {
    background-color: #667eea;
}
    </style>
</head>

<body class="min-h-screen bg-gray-100 text-gray-900 flex justify-center dlbox">
    <div class="max-w-screen-xl m-0 sm:m-20 bg-white shadow sm:rounded-lg flex justify-center flex-1">
      
        <div class="flex-1 bg-indigo-100 text-center hidden lg:flex">
            <div class="m-12 xl:m-16 w-full bg-contain bg-center bg-no-repeat" style="background-image: url('../assets/images/27xxpt.png');"></div>
        </div>
        <?php $login=$_GET['login'];
        if(isset($login)){?>
        <!--用户注册-->
                      <div class="lg:w-1/2 xl:w-5/12 p-6 sm:p-12" id="regtype">
              <div class="mt-12 flex flex-col items-center" id="login1">
                <h1 class="text-2xl xl:text-3xl font-extrabold">注册用户</h1>
                <div class="w-full flex-1 mt-8" id="form-login">

                  
                    <div class="my-12 border-b text-center">
                        <div class="leading-none px-2 inline-block text-sm text-gray-600 tracking-wide font-medium bg-white transform translate-y-1/2">使用账号密码登录</div>
                    </div>

                    <div class="mx-auto max-w-xs">
                        <input class="w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 focus:bg-white mt-5 el-input__inner" type="text" v-model="reg.name" required lay-verify="required" placeholder="昵称" autocomplete="off">
                        
                          <input class="w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 focus:bg-white mt-5 el-input__inner" type="text" v-model="reg.user" required lay-verify="required" placeholder="账号（账号必须为QQ号）" autocomplete="off" >
                          
                            <input class="w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 focus:bg-white mt-5 el-input__inner" type="password" v-model="reg.pass" required lay-verify="required" placeholder="密码" autocomplete="off">
                            
                              <input class="w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 focus:bg-white mt-5 el-input__inner" type="text" v-model="reg.yqm" required lay-verify="required" placeholder="邀请码" autocomplete="off">
                       
                      
                           <button  class="mt-5  el-button el-button--primary is-plain"  style="width: 100%" @click="register"><span>注册用户</span></button>
                  
                    </div>  
                    <!--用户登录结束-->
                
                    
                    
                        <a href="/index/login"><div id="sulogin" class="flex flex-col items-center" style="margin-top:40px;">
                        <button class="w-full max-w-xs font-bold shadow-sm rounded-lg py-3 bg-indigo-100 text-gray-800 flex items-center justify-center ease-in-out focus:outline-none hover:shadow focus:shadow-sm focus:shadow-outline">
                               <img src="/index/assets/images/login.png" class="sss">
                            <div class="login" ></div>
                           
                            <span class="ml-4" >用户登录</span>
                        </button>
                       
                    </div></a>

                </div>     </div>
                    <!--用户注册结束-->
        <?php }else{?>
        <!--用户登录-->
          <div class="lg:w-1/2 xl:w-5/12 p-6 sm:p-12" id="logintype">
            <div class="mt-12 flex flex-col items-center" id="login1">
                <h1 class="text-2xl xl:text-3xl font-extrabold">用户登录</h1>
                <div class="w-full flex-1 mt-8">

                  
                    <div class="my-12 border-b text-center">
                        <div class="leading-none px-2 inline-block text-sm text-gray-600 tracking-wide font-medium bg-white transform translate-y-1/2">使用账号密码登录</div>
                    </div>

                    <div class="mx-auto max-w-xs">
                        <input class="w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 focus:bg-white el-input__inner" v-model="dl.user" required lay-verify="required" placeholder="请输入账号" autocomplete="off">
                        <input class="w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 focus:bg-white mt-5 el-input__inner" type="password" v-model="dl.pass" required lay-verify="required" placeholder="请输入密码" autocomplete="off">
                      
                           <button  @click="login"style="width: 100%;" class="mt-5  el-button el-button--primary is-plain"><!----><!----><span>登录</span></button>
                  
                    </div>  
                    <!--用户登录结束-->
                      <div id="connect_qq" class="flex flex-col items-center" style="margin-top:20px;">
                        <button class="w-full max-w-xs font-bold shadow-sm rounded-lg py-3 bg-indigo-100 text-gray-800 flex items-center justify-center ease-in-out focus:outline-none hover:shadow focus:shadow-sm focus:shadow-outline">
                            <div class="reg"> </div>
                            <img src="/index/assets/images/qq.png" class="sss">
                            <span class="ml-4">使用QQ登录</span>
                        </button>
                       
                    </div>
                    
                         <a href="/index/login?login=1"><div id="sureg" class="flex flex-col items-center" style="margin-top:20px;">
                        <button class="w-full max-w-xs font-bold shadow-sm rounded-lg py-3 bg-indigo-100 text-gray-800 flex items-center justify-center ease-in-out focus:outline-none hover:shadow focus:shadow-sm focus:shadow-outline">
                            <div class="reg" ></div>
                            <img src="/index/assets/images/reg.png" class="sss">
                            <span class="ml-4" >用户注册</span>
                        </button>
                       
                    </div></a>
                  
                   <br> <br> <br>
                   
                               <a href="/index/zcxy"><div id="sureg" class="flex flex-col items-center" style="margin-top:20px;">
                            <span class="ml-4" ><p style="color: blue">《网站声明与使用条款》</p></span>
                        </button>
                       
                    </div></a>
                       
                </div>
                </div>
                </div>
                <?php }?>
                
      
      
<script src="../assets/js/bootstrap.min.js"></script>
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/layer-v3.5.1/layer/layer.js"></script>

<script src="//cdn.staticfile.org/layer/2.3/layer.js"></script>
<script src="https://cdn.staticfile.org/vue/2.6.11/vue.min.js"></script>
<script type="text/javascript" src="../assets/js/aes.js"></script>
<script src="https://libs.baidu.com/jquery/2.1.1/jquery.min.js"></script>

<script src="../assets/js/vue.min.js"></script>
<script src="https://cdn.staticfile.org/vue-resource/1.5.1/vue-resource.min.js"></script>
<script src="./assets/js/element.js"></script>
<!--<script src="../assets/layui/js/axios.min.js"></script>-->
<!--<script src="../assets/layui/js/Mouse.js"></script>-->
<!--<script src="../assets/layui/js/jquery.min.js"></script>-->
<!--<script src="../assets/layui/js/login.js"></script>-->


<script> 
/*var su = 0;
if (su == "0"){
     $("#regtype").css("display","none");
}
$(document).ready(function(){
  $("#sureg").click(function(){
  $("#logintype").css("display","none");
   $("#regtype").css("display","block");
   var su=1;
  });
  
})
$(document).ready(function(){
  $("#sulogin").click(function(){
  $("#regtype").css("display","none");
  $("#logintype").css("display","block");
  var su=0;
  });
   
})*/
</script>
<script>
    var vm = new Vue({
        el: "#login1",
        data: {
            loginType: true,
            title: "你在看什么呢？我写的代码好看吗",
            dl: {},
            reg: {}
        },
        methods: {
            newlogin: function() {
                this.loginType = !this.loginType
            },
            login: function() {
                if (!this.dl.user || !this.dl.pass) {
                    this.$message({message: '账号密码不能为空',type: 'error'});
                    
                    return
                }
                var loading = layer.load();
                vm.$http.post("/apisub.php?act=login", {
                    user: this.dl.user,
                    pass: this.dl.pass
                }, {
                    emulateJSON: true
                }).then(function(data) {
                    layer.close(loading);
                    if (data.data.code == 1) {
                        this.$message({message: '靓仔，欢迎回家！',type: 'success'});
                        setTimeout(function() {
                            window.location.href = "index.php"
                        }, 1000);
                    } else if (data.data.code == 5) {
                        vm.login2();
                    } else {
                         this.$message({message:data.data.msg,type: 'error'});
                     
                    }
                });

            },
            register: function() {
                if (!this.reg.user || !this.reg.pass || !this.reg.name || !this.reg.yqm) {
                    layer.msg('所有项不能为空', {
                        icon: 5
                    });
                    return
                }
                var loading = layer.load();
                this.$http.post("/apisub.php?act=register", {
                    name: this.reg.name,
                    user: this.reg.user,
                    pass: this.reg.pass,
                    yqm: this.reg.yqm
                }, {
                    emulateJSON: true
                }).then(function(data) {
                    layer.close(loading);
                    if (data.data.code == 1) {
                        this.loginType = true;
                        this.dl.user = this.reg.user;
                        this.dl.pass = this.reg.pass;
                        this.$message({message: '靓仔，欢迎加入我们！',type: 'success'});
                        setTimeout(function() {
                            window.location.href = ""
                        }, 1000);
                    } else {
                        this.$message({message: data.data.msg,type: 'error'});
                    }
                });
            },
            login2: function() {
                layer.prompt({
                    title: '管理二次验证',
                    formType: 3
                }, function(pass2, index) {
                    var loading = layer.load();
                    vm.$http.post("/apisub.php?act=login", {
                        user: vm.dl.user,
                        pass: vm.dl.pass,
                        pass2: pass2
                    }, {
                        emulateJSON: true
                    }).then(function(data) {
                        layer.close(loading);
                        if (data.data.code == 1) {
                             this.$message({message: '欢迎大佬回家！',type: 'success'});
                              
                  
                            setTimeout(function() {
                                window.location.href = "index.php"
                            }, 1000);
                        } else {
                             this.$message({message: data.data.msg,type: 'error'});
                        }
                    });
                });
            }
        }
    });

    $('#connect_qq').click(function() {
        var ii = layer.load(0, {
            shade: [0.1, '#fff']
        });
        $.ajax({
            type: "POST",
            url: "../apisub.php?act=connect",
            data: {},
            dataType: 'json',
            success: function(data) {
                layer.close(ii);
                if (data.code == 0) {
                    window.location.href = data.url;
                } else {
                    layer.alert(data.msg, {
                        icon: 7
                    });
                }
            }
        });
    });
</script>
<script type="text/javascript">
    /* 鼠标特效 */
    var a_idx = 0;
    jQuery(document).ready(function($) {
        $("body").click(function(e) {
            var a = new Array("富强","民主","文明","和谐","自由","平等","公正","法治","爱国","敬业","诚信","友善");
            var $i = $("<span />").text(a[a_idx]);
            a_idx = (a_idx + 1) % a.length;
            var x = e.pageX
              , y = e.pageY;
            $i.css({
                "z-index": 999999999999999999999999999999999999999999999999999999999999999999999,
                "top": y - 20,
                "left": x,
                "position": "absolute",
                "font-weight": "bold",
                "color": "#ff6651"
            });
            $("body").append($i);
            $i.animate({
                "top": y - 180,
                "opacity": 0
            }, 1500, function() {
                $i.remove();
            });
        });
    });
</script>


</body>
</html>