<?php
$title='疑点解答';
require_once('head.php');
?>
 
<div class="lyear-layout-content" role="main">
     <div class="app-content-body ">
         <div class="container-fluid">
         <div class="row">
         
             <div class="col-sm-12 col-lg-12">
            <div class="card" style="border-radius:8px;box-shadow: 8px 8px 15px #d1d9e6, -18px -18px 30px #fff;">
             
              <div class="card-body" style="margin-top:10px;">
                  
                      <div class="clo-sm-12">
                 <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                  <div class="panel panel-primary" style="    color: #2f2f2f;border-radius: 0px;border-color: #33cabb05;">
                    <div class="panel-heading" role="tab" id="headingOne" style=" background-color: #ffffff;color:#464646;">
                      <h4 class="panel-title">
                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne" class="">
                         <div style="height:25px;width:7px;background-color:#af92ff;float:left;border-radius:4px;margin-right: 5px;"></div> <b>公告通知</b>
                        </a>
                      </h4>
                    </div>
                    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne" aria-expanded="true" style="">
                      <div class="panel-body" style="border-top-color: #c2c2c2;">
                        <li class="list-group-item">
                  <span style="color: rgb(226, 139, 65);"><b><span style="font-size: 1.25em;"><span style="font-size: 14px; color: rgb(226, 139, 65);">主要完成类型：单选题 多选题 判断题 填空题 （支持图片题） ；不包英语听力完形填空 等异类题型 ！另外专业课请谨慎下单避免个别低分出现造成不必要的麻烦！</span></span></b><br></p><p><b><span style="font-size: 1.25em;"><span style="font-size: 14px;"><b style="color: rgb(32, 147, 97);">请勿手动打开考试</b><b style="color: rgb(227, 55, 55);">，最好不要提交规定时间的限时考试！</b></span>			            	  </li>  
            
                     <div class="card-body" style="margin-top:10px;">
                 <div class="table-responsive"> 
				         <table class="table ">
				             
				          <thead><tr><th style="padding: 20px;">ID</th><th style="padding: 20px;">平台名称</th><th style="padding: 20px;">课程说明</th><th style="padding: 20px;">我的价格（<?php echo $userrow['addprice']?>）</th></thead>
				          <tbody>				          	
							<?php 
	                     	 $a=$DB->query("select * from qingka_wangke_class where status=1 ");
	                     	 while($rs=$DB->fetch($a)){
	                     	 	  echo "<tr><td style='padding: 20px;'>".$rs['cid']."</td>
	                     	 	  	<td style='padding: 20px;'>".$rs['name']."</td>
	                     	    	<td style='padding: 20px;'>".$rs['content']."</td>
	                     	 	  	<td  style='padding: 20px;'><span class='spss'>".($rs['price']*$userrow['addprice'])."</span></td>
	                     	 	  	</tr>"; 
	                     	 }
	                     	?>		           
				          </tbody>
				        </table>
				      </div>
              </div>
            </div>   </div> </div>   </div>
            
     
    </div>
</div>
                      </div>
                    </div>
                  </div>
                  
      
                  
                 
                  
              </div>
            </div>   </div>
           
      
        	
      </div>
    </div>


<script type="text/javascript" src="assets/LightYear/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/main.min.js"></script>
<script src="assets/js/aes.js"></script>
<script src="https://cdn.staticfile.org/vue/2.6.11/vue.min.js"></script>
<script src="https://cdn.staticfile.org/vue-resource/1.5.1/vue-resource.min.js"></script>
<script src="https://cdn.staticfile.org/axios/0.18.0/axios.min.js"></script>

 
	

 
	     
<script src="assets/layui/layui.js"></script> 
<script>
//注意：折叠面板 依赖 element 模块，否则无法进行功能性操作
layui.use('element', function(){
  var element = layui.element;
  
  //…
});
</script>
      