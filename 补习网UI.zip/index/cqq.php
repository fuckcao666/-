<?php
$title='普通补习';
require_once('head.php');
$addsalt=md5(mt_rand(0,999).time());
$_SESSION['addsalt']=$addsalt;
?>
<html>
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
		<link rel="stylesheet" href="https://unpkg.com/element-ui/lib/theme-chalk/index.css">
		<script src="https://unpkg.com/vue/dist/vue.js"></script>
		  <script src="https://unpkg.com/element-ui/lib/index.js"></script>
		<title></title>
	</head>
	<body>
		<div id="app" style="text-align: center;">
			<h2>查Q绑</h2>
			<el-input id="qq" v-model="qq" placeholder="请输入查询QQ"></el-input>
			<br>
			<br>
			<el-button type="primary" style="width: 100%;" @click="chaxun" type="button">查询</el-button>
			
			<br>
			<br>
			<br>
			<h4 style="color: red;">仅供学习交流，请勿有其他想法</h4>
			
			
			
			
			
			<el-dialog
			  title="信息"
			  :visible.sync="dialogVisible"
			  width="30%">
			  <div style="text-align: left;">
				  查询QQ：{{data.qq}} <br>
				  手机号：{{data.phone}} <br>
				  号码归属地：{{data.phonediqu}} <br>
			  </div>
			  <span slot="footer" class="dialog-footer">
			    <el-button type="primary" @click="dialogVisible = false">关 闭</el-button>
			  </span>
			</el-dialog>
			
		</div>
		
		
	</body>
	<style>
		#app{
			width: 50%;
			margin: auto;
			margin-top: 10%;
		}
	</style>
	<script>
	let vue = new Vue({
		el:"#app",
		data: function() {
		        return { 
					qq:"",
					data:{},
					dialogVisible:false
				}
		},methods:{
			chaxun(){
				//开启框架加载事件
				this.$loading({
					text:"查询中"
				})
				//使用Jquery发起请求
				$.get("https://zy.xywlapi.cc/qqapi?qq="+this.qq).then(res=>{
					//校验返回状态码
					if(res.status==500){
						this.$message.warning(res.message);
					}else if(res.status==200){
						//保存相应对象
						this.data = res
						//开启弹窗
						this.dialogVisible = true
					}
					//关闭ui组件加载
					this.$loading().close()
				})
				//捕捉异常
				.catch(()=>{
					//关闭ui组件加载
					
					this.$loading().close()
					//提醒用户查询错误
					this.$message.error("请求错误！");
				})
			}
		}
	})
	</script>
</html>