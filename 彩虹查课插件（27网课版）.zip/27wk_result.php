<?php
include("./includes/common.php");
/*
*------------------------------------------------------
* Title : 彩虹对接27学习平台 进度同步文件
*------------------------------------------------------
* Author : 青卡
*------------------------------------------------------
* Time : 2021-7-17
*------------------------------------------------------
* 监控本文件，建议5~10分钟执行一次 
* http://你的代刷网域名/27wk_result.php?act=order
* 
*/
$act=isset($_GET['act'])?daddslashes($_GET['act']):null;
@header('Content-Type: application/json; charset=UTF-8');

switch($act){
    case 'order':
		$rs=$DB->query("SELECT * FROM pre_orders WHERE djorder='订单号登录后台自行查看，老子懒得写了' and result is null ORDER BY id ASC");
		while($res = $rs->fetch(PDO::FETCH_ASSOC)){
			$input=$res['input'];
			$kcname=$res['input4'];	
			$result=get_curl("http://wk.27sq.cn/api.php?act=chadan","username={$input}");
			$result=json_decode($result,true);
			foreach($result['data'] as $row){				
				$per='进度：'.$row['process'];
				if($kcname==$row['kcname']){
					$DB->query("update pre_orders set result='$per' where id='{$res['id']}' ");	
					break;				
				}
			}
			echo 'ok';
		}
	break;
}




?>