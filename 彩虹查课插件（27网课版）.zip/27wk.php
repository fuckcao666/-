<?php
include("./includes/common.php");
/*
*------------------------------------------------------
* Title : 彩虹对接27学习平台内所选课程API接口
*------------------------------------------------------
* Author : 青卡
*------------------------------------------------------
* Time : 2021-4-3
*------------------------------------------------------
* Tips : 请勿恶意调用此接口【此文件为配置文件】
*------------------------------------------------------
*/

$uid="";//这里填ID
$key="";//这里填密匙
//请将您在27学习学习平台的UID ，还有密匙填在上面↑↑↑↑↑↑↑↑↑↑

$user= $_REQUEST['account'];
$pass = $_REQUEST['pwd'];
$school = $_REQUEST['school'];
$platform = $_REQUEST['platform'];
$hash = $_REQUEST['hash'];
$hashsalt=$_SESSION['addsalt'];
if ($hash != $hashsalt){
    die('{"code":1,"msg":"\u9a8c\u8bc1\u5931\u8d25\uff0c\u8bf7\u5237\u65b0\u754c\u9762\u91cd\u8bd5","data":""}');
}

$result=get_curl("http://wk.27sq.cn/api.php?act=getclass",$data);
$result=json_decode($result,true);
foreach($result['data'] as $row){
	if(strpos($platform,$row['name']) !== false){
	   $pid = $row['cid'];
	   break;
	}
}

$apiurl = 'http://wk.27sq.cn/api.php?act=get';//27学习平台接口地址    非必要情况请勿修改。
$data=array(
    'uid'=>$uid,
    'key'=>$key,
    'school'=>$school,
    'platform'=>$pid,
    'user'=>$user,
    'pass'=>$pass
);

$wk=get_curl($apiurl,$data);
exit($wk);
?>