<?php
include("./includes/common.php");
$account = $_REQUEST['account'];
$pwd = $_REQUEST['pwd'];
$school = $_REQUEST['school'];
$platform = $_REQUEST['platform'];
$key = $_REQUEST['key'];

$hashsalt=$_SESSION['addsalt'];
if ($key != $hashsalt){
    die('{"code":1,"msg":"\u9a8c\u8bc1\u5931\u8d25\uff0c\u8bf7\u5237\u65b0\u754c\u9762\u91cd\u8bd5","data":""}');
}

$url='https://api.imeo5.com/api/imeo5ck-Free?platform='.$platform.'&school='.$school.'&account='.$account.'&pwd='.$pwd;
echo file_get_contents($url);

?>