<script>
    window.location.href='/index/index';
</script>