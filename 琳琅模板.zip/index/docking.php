<?php
$mod='blank';
$title='平台对接';
require_once('head.php');
?>

<div class="app-content-body ">
        <div class="wrapper-md control">
		  <div class="panel panel-default" style="margin-bottom: 24px;border-radius:8px;">
		    <div class="panel-heading font-bold " style="background-color:#fff;border-top-left-radius: 8px; border-top-right-radius: 8px;"> <div style="height:20px;width:5px;background-color:#89BFFC;float:left;border-radius:4px;margin-right: 5px;"></div>订单提交<button class="btn btn-xs " data-toggle="modal" data-target="#modal-platform" style="background-color: #000000;border-radius:5px;color:#fff;margin-left:20px;">查看平台ID</button></div>
			 <div class="panel-body">
			 <div class="tab-pane fade active in" id="home">
                                    <pre><h5>POST:</h5>https://<?echo($_SERVER['SERVER_NAME']);?>/api.php?act=add</pre>
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                        <tr>
                                            <th class="text-center" style="width:100px">请求参数</th>
                                            <th>
                                                说明<br>
                                            </th>
                                            <th class="text-center" style="width:100px">
                                                传输类型<br>
                                            </th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <th class="text-center" scope="row">uid</th>
                                            <td><code>登录验证</code></td>
                                            <td class="text-center"><code>必传</code></td>
                                        </tr>
                                        <tr>
                                            <th class="text-center" scope="row">key</th>
                                            <td><code>登录验证</code></td>
                                            <td class="text-center"><code>必传</code></td>
                                        </tr>
                                        <tr>
                                            <th class="text-center" scope="row">platform</th>
                                            <td><code>平台ID</code></td>
                                            <td class="text-center"><code>必传</code></td>
                                        </tr>

                                        <tr>
                                            <th class="text-center" scope="row">user</th>
                                            <td><code>学生账号</code></td>
                                            <td class="text-center"><code>必传</code></td>
                                        </tr>
                                        <tr>
                                            <th class="text-center" scope="row">pass</th>
                                            <td><code>账号密码</code></td>
                                            <td class="text-center"><code>必传</code></td>
                                        </tr>
                                        <tr>
                                            <th class="text-center" scope="row">kcname</th>
                                            <td><code>课程名字</code></td>
                                            <td class="text-center"><code>必传</code></td>
                                        </tr>
                                        <tr>
                                            <th class="text-center" scope="row">kcid</th>
                                            <td><code>课程ID</code></td>
                                            <td class="text-center"><code>必传</code></td>
                                        </tr>
                                        </tbody>
                                    </table>
                              </div>
		                </div>
		            </div>
		  
		  <div class="panel panel-default" style="margin-bottom: 24px;border-radius:8px;">
		    <div class="panel-heading font-bold " style="background-color:#fff;border-top-left-radius: 8px; border-top-right-radius: 8px;"> <div style="height:20px;width:5px;background-color:#89BFFC;float:left;border-radius:4px;margin-right: 5px;"></div>课程查询</div>
			 <div class="panel-body">
    			                <pre><h5>POST:</h5>https://<?echo($_SERVER['SERVER_NAME']);?>/api.php?act=get</pre>
                                <table class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th class="text-center" style="width:100px">请求参数</th>
                                        <th>
                                            说明<br>
                                        </th>
                                        <th class="text-center" style="width:100px">
                                            传输类型<br>
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <tr>
                                            <th class="text-center" scope="row">uid</th>
                                            <td><code>登录验证</code></td>
                                            <td class="text-center"><code>必传</code></td>
                                        </tr>
                                        <tr>
                                            <th class="text-center" scope="row">key</th>
                                            <td><code>登录验证</code></td>
                                            <td class="text-center"><code>必传</code></td>
                                        </tr>
                                        <tr>
                                            <th class="text-center" scope="row">platform</th>
                                            <td><code>平台ID</code></td>
                                            <td class="text-center"><code>必传</code></td>
                                        </tr>

                                        <tr>
                                            <th class="text-center" scope="row">user</th>
                                            <td><code>学生账号</code></td>
                                            <td class="text-center"><code>必传</code></td>
                                        </tr>
                                        <tr>
                                            <th class="text-center" scope="row">pass</th>
                                            <td><code>学生密码</code></td>
                                            <td class="text-center"><code>必传</code></td>
                                        </tr>
                                         <tr>
                                            <th class="text-center" scope="row">school</th>
                                            <td><code>学生学校</code></td>
                                            <td class="text-center"><code>必传</code></td>
                                        </tr>
                                    </tr>
                                    </tbody>
                                </table>
		      </div>
		  </div>
		  <div class="panel panel-default" style="margin-bottom: 24px;border-radius:8px;">
		    <div class="panel-heading font-bold " style="background-color:#fff;border-top-left-radius: 8px; border-top-right-radius: 8px;"> <div style="height:20px;width:5px;background-color:#89BFFC;float:left;border-radius:4px;margin-right: 5px;"></div>订单查询</div>
			 <div class="panel-body">
    			 <pre><h5>POST:</h5>https://<?echo($_SERVER['SERVER_NAME']);?>/api.php?act=chadan</pre>
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                        <tr>
                                            <th class="text-center" style="width:100px">请求参数</th>
                                            <th>
                                                说明<br>
                                            </th>
                                            <th class="text-center" style="width:100px">
                                                传输类型<br>
                                            </th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                            <th class="text-center" scope="row">uid</th>
                                            <td><code>登录验证</code></td>
                                            <td class="text-center"><code>必传</code></td>
                                        </tr>
                                        <tr>
                                            <th class="text-center" scope="row">key</th>
                                            <td><code>登录验证</code></td>
                                            <td class="text-center"><code>必传</code></td>
                                        </tr>
                                        <tr>
                                            <th class="text-center" scope="row">user</th>
                                            <td><code>订单账号</code></td>
                                            <td class="text-center"><code>必传</code></td>
                                        </tr>
                                        </tbody>
                                    </table>
		      </div>
		  </div>
		  <div class="panel panel-default" style="margin-bottom: 24px;border-radius:8px;">
		    <div class="panel-heading font-bold " style="background-color:#fff;border-top-left-radius: 8px; border-top-right-radius: 8px;"> <div style="height:20px;width:5px;background-color:#89BFFC;float:left;border-radius:4px;margin-right: 5px;"></div>订单补刷</div>
			 <div class="panel-body">
    			 <pre><h5>POST:</h5>https://<?echo($_SERVER['SERVER_NAME']);?>/api.php?act=budan</pre>
                                <table class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th class="text-center" style="width:100px">请求参数</th>
                                        <th>
                                            说明<br>
                                        </th>
                                        <th class="text-center" style="width:100px">
                                            传输类型<br>
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <th class="text-center" scope="row">uid</th>
                                        <td><code>登录验证</code></td>
                                        <td class="text-center"><code>必传</code></td>
                                    </tr>
                                    <tr>
                                        <th class="text-center" scope="row">key</th>
                                        <td><code>登录验证</code></td>
                                        <td class="text-center"><code>必传</code></td>
                                        </tr>
                                    <tr>
                                        <th class="text-center" scope="row">id</th>
                                        <td><code>订单账号</code></td>
                                        <td class="text-center"><code>必传</code></td>
                                    </tr>
                                    </tbody>
                                </table>
		      </div>
		  </div>
	      <div class="panel panel-default" style="margin-bottom: 24px;border-radius:8px;">
		    <div class="panel-heading font-bold " style="background-color:#fff;border-top-left-radius: 8px; border-top-right-radius: 8px;"> <div style="height:20px;width:5px;background-color:#89BFFC;float:left;border-radius:4px;margin-right: 5px;"></div>彩虹代刷对接/小储云对接（自定义访问URL）<button class="btn btn-xs " data-toggle="modal" data-target="#modal-platform" style="background-color: #000000;border-radius:5px;color:#fff;margin-left:20px;">查看平台ID</button></div>
				 <div class="panel-body">
				 	
  <span style="color:#8d8d8d;font-size:15px;">自定义访问域名URL：</span><input style="border-radius:8px;border:2px solid #ececec;" type="text" class="frosss2" name="pass" value="https://<?echo($_SERVER['SERVER_NAME']);?>/api.php?act=add" required>
  <br>
				<span style="color:#8d8d8d;font-size:15px;"> POST提交参数：</span>				 
            <input  style="border-radius:8px;border:2px solid #ececec;" type="text" class="frosss2" name="pass" value="uid=你的uid&key=你的key密匙&platform=平台ID&school=学校&user=账号&pass=密码&kcname=课程名字"><br/>
		    </div>
		  </div>
		  

        <div class="modal fade primary" id="modal-platform">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
                        </button>
                        <h4 class="modal-title">平台ID</h4>
                    </div>
                         		      <div class="table-responsive"> 
														         <table class="table table-striped">
														          <thead><tr><th>ID</th><th>平台名称</th></thead>
														          <tbody>
														          	
																						<?php 
											                     	 $a=$DB->query("select * from qingka_wangke_class where status=1 ");
											                     	 while($rs=$DB->fetch($a)){
											                     	 	  echo "<tr><td>".$rs['cid']."</td><td>".$rs['name']."</td></tr>"; 
											                     	 }
											                     	?>

														           
														          </tbody>
														        </table>
														      </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">取消</button>
                        <button type="button" class="btn btn-success" data-dismiss="modal" @click="layer.msg('好的，靓仔')">知道了</button>
                    </div>
                </div>
            </div>
        </div>
   </div>
 </div>
 

<script type="text/javascript" src="assets/LightYear/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/main.min.js"></script>
<script src="assets/js/aes.js"></script>
<script src="https://cdn.staticfile.org/vue/2.6.11/vue.min.js"></script>
<script src="https://cdn.staticfile.org/vue-resource/1.5.1/vue-resource.min.js"></script>
<script src="https://cdn.staticfile.org/axios/0.18.0/axios.min.js"></script>

<script>
new Vue({
	el:"#loglist",
	data:{
		row:null
	},
	methods:{
		get:function(page){

		}
	},
	mounted(){
		this.get(1);
	}
});
</script>