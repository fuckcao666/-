<?php
$mod='blank';
$title='日志列表';
require_once('head.php');
 $a=$DB->get_row("select * from qingka_wangke_user where uid='{$userrow['uuid']}' ");
?>
     <div class="app-content-body ">
        <div class="wrapper-md control" id="charge">
        	<div class="row">
        	<div class="col-sm-12">
        	     <div class="wrapper-md control">
				         <div class="card" class="" style="margin-bottom: 24px;border-radius:8px;">
				             <div class="card-header">	
				             	 充值方法一
				             </div>	
				             
				            <li class="list-group-item">				            	
				            	请联系您的上级进行充值！<br />
								上级联系方式（QQ/微信）：<b style="color: red;"><?php echo $a['user']?></b> <br />
								上级邀请码：<b style="color: blue;"><?php echo $a['yqm']?></b> <br />
								上级上次在线时间：<b><?php echo $a['endtime']?></b> <br />
				            </li>   		          
				          </div>
				          
				          
				          
				          
				         <div class="card" class="" style="margin-bottom: 24px;border-radius:8px;">
				             <div class="card-header">	
				             	 充值方法二
				             </div>		
				             <div class="card-body">
						      <div class="form-group" style="overflow:hidden">									
				                    <input style="width: 150px; float: left;" type="text" class="form-control" placeholder="请输入充值金额" v-model="money"/><button style="background-color:blue; border-radius: 5px; color: rgb(255, 255, 255); margin-left: 20px;" class="btn btn-success" @click="pay">立即充值</button>							
							  </div>
							        <font color="red">
									<font color="blue">注意事项：</font> <br>
									1.其他充值方式不能用时，请用支付宝充值！<br>
									2.扫码支付时务必在二维码页面停留等待支付成功！如果未支付成功就返回会造成支付不跳转！导致充值不到账问题！<br>
									3.经大量测试后支付宝充值目前最稳定！建议用支付宝充值！<br>
									4.上家如若连续7天未登录平台可选择在线充值。<br>
									5.作者直属代理可直接使用，无上面限制。<br>
				                   </font>
				             </div>		          
				          </div>
				           
				           
	<div class="col-sm-12" id="pay2" style="display: none;">
    	<form action="/epay/epay.php" method="post">
    		<div><center style="margin-top:15px;"><h3>￥{{money}}</h3></center></div>
    		<input type="hidden" name="out_trade_no" v-model="out_trade_no"/><br>
			<button type="radio" name="type" value="alipay" class="btn btn-primary btn-block" >支付宝</button><br>
			<!--<button type="radio" name="type" value="qqpay" class="btn btn-danger btn-block">QQ</button><br>-->
			<button type="radio" name="type" value="wxpay" class="btn btn-info btn-block">微信</button><br>
		</form>	
    </div> 
				           
				           
				        <!--<div style="margin-top: 20px;">
				          <div class="card" class="">
				             <div class="card-header">	
				             	我设置的公告
				             </div>			             
				            <li class="list-group-item">				            	
                                 <span><?php
                                	echo $userrow['notice'];
                                 	?></span>
				            </li>   	          
				          </div>
			            </div>	     
				         <div style="margin-top: 20px;">
				          <div class="card" class="">
				             <div class="card-header">	
				             	上级公告
				             </div>			             
				            <li class="list-group-item">				            	
                                 <span><?php
                                 	echo $a['notice'];
                                 	?></span>
				            </li>   
				          
				          </div>
			             </div>	-->

          </div>
          </div>
   </div>
 </div>
 
 
 
 
<?php require_once("footer.php");?>
	<script type="text/javascript">
var now = getNow();
watermark({"watermark_txt":"<?php echo $userrow['name']?>"});
</script>
	
	
<script>
$("pay2").hide();
new Vue({
	el:"#charge",
	data:{
       money:'',
       out_trade_no:''
	},
	methods:{
		pay:function(page){
		    var load=layer.load();
 			this.$http.post("/apisub.php?act=pay",{money:this.money},{emulateJSON:true}).then(function(data){	
	          	layer.close(load);
	          	if(data.data.code==1){	
	          		$("pay2").show();
	          		this.out_trade_no=data.data.out_trade_no;	
	          		layer.msg(data.data.msg,{icon:1});		  
 					layer.open({
					  type: 1,
					  title: '请选择支付方式',
					  closeBtn: 0,
					  area: ['250px', '300px'],
					  skin: 'layui-bg-gray', //没有背景色
					  shadeClose: true,
					  content: $('#pay2'),
			  		  end: function(){ 
					    $("#pay2").hide();
					  }
					});          		                   	          			             			                     
	          	}else{	          		
	                layer.msg(data.data.msg,{icon:2});
	          	}
	        });	
		}
	},
	mounted(){
		
	}
});
</script>
<script>
    layer.alert("扫码支付时务必在二维码页面停留等待支付成功！如果未支付成功就返回会造成支付不跳转！导致充值不到账问题！");
</script>