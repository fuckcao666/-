<?php
include('../confing/common.php');
if($islogin!=1){exit("<script language='javascript'>window.location.href='login';</script>");  }
?>
<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
  <title><?=$conf['sitename']?></title>
  <meta name="keywords" content="<?=$conf['keywords'];?>" />
  <meta name="description" content="<?=$conf['description'];?>" />
<link rel="icon" href="assets/LightYear/favicon.ico" type="image/ico">
<meta name="author" content="qingka">
<link rel="stylesheet" href="../assets/css/bootstrap.css" type="text/css" />
<link rel="stylesheet" href="../assets/css/app.css" type="text/css" />
<link rel="stylesheet" href="../assets/layui/css/layui.css" type="text/css" />
<link href="assets/LightYear/css/materialdesignicons.min.css" rel="stylesheet">
<!--<link href="assets/LightYear/css/ion-rangeslider/ion.rangeSlider.min.css" rel="stylesheet"/>-->
<link href="assets/LightYear/css/style.min.css" rel="stylesheet"/>
<script src="../assets/js/bootstrap.min.js"></script>
<script src="//lib.baomitu.com/jquery/1.12.4/jquery.min.js"></script>
<script src="//cdn.staticfile.org/layer/2.3/layer.js"></script>
<link rel="stylesheet" href="/assets/elm/element.css">
 <link rel="stylesheet" type="text/css" href="https://element.eleme.cn/docs.10df231.css">
<link rel="stylesheet" href="https://element.eleme.cn/element-ui.91647e9.css">
<link href="./assets/css/tailwind.min.css" rel="stylesheet">
<script src="https://at.alicdn.com/t/font_1185698_xknqgkk0oph.js?spm=a313x.7781069.1998910419.40&file=font_1185698_xknqgkk0oph.js"></script>

</head>
<style type="text/css">
    .susuicon {
        position: absolute;
    left: 21px;
    top: 14px;
       width: 1.3em; height: 1.3em;
       vertical-align: -0.15em;
       fill: currentColor;
       overflow: hidden;
    }
     .susuicon2 {
     position: absolute;
    top: 50%;
    right: 20px;
    margin-top: -7px;
    transition: transform .3s;
       width: 1.1em; height: 1.1em;
       vertical-align: -0.15em;
       fill: currentColor;
       overflow: hidden;
    }
    .flex{height: 2em; width: 2em;   vertical-align: -0.15em;
       fill: currentColor;float:left; position: absolute;
    bottom: 7px;
    left: 5px;
       overflow: hidden;}
       
       .flex2{height: 1.4em; width: 1.4em;   vertical-align: -0.15em;
       fill: currentColor;float:left;margin-top:2px;margin-right: 5px;
       overflow: hidden;}
       .malet{padding-left:20px;font-size:11px;}
    .nav>li:hover{
        background-color: #f8f8ff;
    }
    hr {
    height: 1px;
    margin: 4px;
        
    }
    
    
    .frosss{    height: 38px;
    border-radius: 8px !important; border: 2px solid rgb(236, 236, 236);
    border-color: #ebebeb;
    -webkit-border-radius: 2px;
    border-radius: 2px;
    padding: 5px 12px;
    line-height: inherit;
    -webkit-transition: 0.2s linear;
    transition: 0.2s linear;
    -webkit-box-shadow: none;
    box-shadow: none;}
      .frosss2{ 
           border-radius: 8px !important; border: 2px solid rgb(236, 236, 236);
           display: block;
    width: 100%;
          height: 38px;
    border-color: #ebebeb;
    -webkit-border-radius: 2px;
    border-radius: 2px;
    padding: 5px 12px;
    line-height: inherit;
    -webkit-transition: 0.2s linear;
    transition: 0.2s linear;
    -webkit-box-shadow: none;
    box-shadow: none;}
    .table>thead>tr>th {
    padding: 15px;
</style>
<?php
if($userrow['active']=="0"){
alert('您的账号已被封禁！','login');
}
?>
    <!--End 头部信息-->
