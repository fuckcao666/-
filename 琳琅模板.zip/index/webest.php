<?php
$title='系统设置';
require_once('head.php');
if($userrow['uid']!=1){
	alert("你来错地方了","index.php");
}
?>
     <div class="app-content-body ">
        <div class="wrapper-md control" id="add">
	       <div class="panel panel-default" style="box-shadow: 8px 8px 15px #d1d9e6, -18px -18px 30px #fff; border-radius:8px;">
		    <div class="panel-heading font-bold" style="border-top-left-radius: 8px; border-top-right-radius: 8px;background-color:#fff;"><div style="height:20px;width:5px;background-color:#af92ff;float:left;border-radius:4px;margin-right: 5px;"></div>
			    填写信息
		     </div>
		     
				<div class="panel-body">
								
				
					<form class="form-horizontal devform" id="form-web">
						<div class="form-group">
							<label class="col-sm-2 control-label">站点名字</label>
								<div class="col-sm-9">
									<input type="text" class="frosss2" name="sitename" value="<?=$conf['sitename']?>" placeholder="AM学习平台" required>
							</div>
						</div>

						<div class="form-group">
							<label class="col-sm-2 control-label">SEO关键词</label>
								<div class="col-sm-9">
									<input type="text" class="frosss2" name="keywords" value="<?=$conf['keywords']?>" placeholder="AM学习平台" required>
							</div>
						</div>
												
						<div class="form-group">
							<label class="col-sm-2 control-label">SEO介绍</label>
								<div class="col-sm-9">
									<input type="text" class="frosss2" name="description" value="<?=$conf['description']?>" placeholder="AM学习平台" required>
							</div>
						</div>
					
						<div class="form-group">
							<label class="col-sm-2 control-label">彩虹api聚合登录</label>
								<div class="col-sm-9">
									<input type="text" class="frosss2" name="login_apiurl" value="<?=$conf['login_apiurl']?>" placeholder="请输入聚合登录地址" required>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label">应用ID</label>
								<div class="col-sm-9">
									<input type="text" class="frosss2" name="login_appid" value="<?=$conf['login_appid']?>" placeholder="请输入聚合登录应用ID" required>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label">应用key</label>
								<div class="col-sm-9">
									<input type="text" class="frosss2" name="login_appkey" value="<?=$conf['login_appkey']?>" placeholder="请输入聚合登录应用key" required>
							</div>
						</div>
						
						
						<div class="form-group">
							<label class="col-sm-2 control-label">是否允许邀请码注册</label>
								<div class="col-sm-9">
									<select name="user_yqzc" class="frosss2">
	                            	    <option value="1" <?php if($conf['user_yqzc']==1){ echo 'selected';}?>>1_允许</option> 
	                            	    <option value="0" <?php if($conf['user_yqzc']==0){ echo 'selected';}?>>0_拒绝</option>                           	                            	
	                                </select>
							   </div>
						</div>	

						<div class="form-group">
							<label class="col-sm-2 control-label">是否允许后台开户</label>
								<div class="col-sm-9">
									<select name="user_htkh" class="frosss2">	
	                            	   <option value="1" <?php if($conf['user_htkh']==1){ echo 'selected';}?>>1_允许</option>   
	                            	   <option value="0" <?php if($conf['user_htkh']==0){ echo 'selected';}?>>0_拒绝</option>                           	                            	
	                                </select>
							</div>
						</div>
						
						<div class="form-group">
							<label class="col-sm-2 control-label">代理开通价格</label>
								<div class="col-sm-9">
									<input type="text" class="frosss2" name="user_ktmoney" value="<?=$conf['user_ktmoney']?>" placeholder="" required>
							</div>
						</div>
						
						<div class="form-group">
							<label class="col-sm-2 control-label">公告</label>
								<div class="col-sm-9">
									<textarea type="text" name="notice" class="frosss2" style="height:100px;"  rows="5"><?=$conf['notice']?></textarea>
							</div>
						</div>																		
				  	    <div class="col-sm-offset-2 col-sm-4">
				  	    	<input type="button" @click="add" value="立即修改" class="btn btn-primary"/>
				  	    </div>

			        </form>
	     </div>
      </div>
    </div>


<?php require_once("footer.php");?>

<script>
new Vue({
	el:"#add",
	data:{

	},
	methods:{
	    add:function(){
	        var loading=layer.load();
	    	this.$http.post("/apisub.php?act=webset",{data:$("#form-web").serialize()},{emulateJSON:true}).then(function(data){
	    		layer.close(loading);
	    		if(data.data.code==1){
	    			layer.alert(data.data.msg,{icon:1,title:"温馨提示"},function(){setTimeout(function(){window.location.href=""});});
	    		}else{
	    			layer.alert(data.data.msg,{icon:2,title:"温馨提示"});
	    		}
	    	});
	    }   
	},
	mounted(){
		//this.getclass();		
	}
	
	
});
</script>