<?php

$mod='blank';

$title='修改密码';
require_once('head.php');

?>
 
 
<div class="wrapper-md control">
	       <div class="panel panel-default" id="add" style="box-shadow: 8px 8px 15px #d1d9e6, -18px -18px 30px #fff; border-radius:8px;">
		      <div class="panel-heading font-bold" style="border-top-left-radius: 8px; border-top-right-radius: 8px;background-color:#fff;">修改密码</div>
			        <div class="panel-body">
			          <form action="" method="post" class="form-horizontal" role="form">
			            <div class="input-group">
			              <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
			              <input type="text" v-model="oldpass" value="" class="form-control" placeholder="旧密码" required="required"/>
			            </div><br/>
			            <div class="input-group">
			              <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
			              <input type="text" v-model="newpass" class="form-control" placeholder="新密码" required="required"/>
			            </div><br/>
			            <div class="form-group">
			              <div class="col-xs-12"><input type="button" @click="passwd" name="submit" value="修改" class="btn btn-primary form-control"  style="background-color:#89BFFC;"/></div>
			            </div>
			          </form>
			        </div>
          </div>
  </div>


<script type="text/javascript" src="assets/LightYear/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/main.min.js"></script>
<script src="assets/js/aes.js"></script>
<script src="https://cdn.staticfile.org/vue/2.6.11/vue.min.js"></script>
<script src="https://cdn.staticfile.org/vue-resource/1.5.1/vue-resource.min.js"></script>
<script src="https://cdn.staticfile.org/axios/0.18.0/axios.min.js"></script>

	
	
<script>
	new Vue({
		el:"#add",
		data:{
			oldpass:'',
			newpass:''
		},
		methods:{
			passwd:function(){
			  var load=layer.load();
              $.post("/apisub.php?act=passwd",{oldpass:this.oldpass,newpass:this.newpass},function (data) {
		 	     layer.close(load);
	             if (data.code==1){	   
	                layer.alert(data.msg,{icon:1});
	             }else{
	                layer.msg(data.msg,{icon:2});
	             }
              });
			}
		}
	});
	
</script>