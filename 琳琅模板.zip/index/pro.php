<?php
$title='密价价格';
require_once('head.php');
if($userrow['uid']!=1){exit("<script language='javascript'>window.location.href='login.php';</script>");}
?>
<link rel="stylesheet" href="assets/css/element.css">

	<div class="app-content-body ">
		<div class="wrapper-md control" id="add">
		    <div class="col-xs-12 col-sm-12 col-lg-6 col-md-6">
		    <el-card class="box-card">
                <div slot="header" class="clearfix">
                    <span>密价价格</span>
                    <el-button style="float: right; padding: 3px 0" type="text" @click="show=!show">查看/修改价格<li class="el-icon-arrow-down"></li></el-button>
                </div>
                <div class="text item">
                    <el-collapse-transition>
                        <div v-if="show==false">
                            
                            <!--密价价格设置-->
                            <el-divider><span style="color:red">价格设置</span></el-divider>
                            <table class="table table-hover" style="font-size:14px">
    						    <thead>
    							    <tr>
    							        <th>cid</th>
    							        <th>平台</th>
    								    <th>专业版价格</th>
    								    <th>普通版价格</th>
    								    <th>操作</th>
    								</tr>
    							</thead>
    							<tbody>
    						        <tr v-for="res in row.data">
    						            <td>{{res.cid}}</td>
    						            <td>{{res.name}}</td>
    						            <td>{{res.pro}}</td>
    						            <td>{{res.pro1}}</td>
    						            <td><el-button type="primary" size="mini" @click="revise=!revise;info2(res.cid)" plain>
    											修改
    								        </el-button>
    								    </td>
    					            </tr>
    				            </tbody>
    				        </table>
    				        <!--密价价格设置-->
    				        
    				        <!--修改分站价格-->
                            <el-dialog title="修改价格" :visible.sync="revise">
                                <el-form :model="form2">
                                    <el-form-item label="分站">
                                        <el-select v-model="form2.pro" placeholder="请选择要修改的分站">
                                            <el-option label="专业版" value="1"></el-option>
                                            <el-option label="普通版" value="2"></el-option>
                                        </el-select>
                                    </el-form-item>
                                    <el-form-item label="价格">
                                        <el-input v-model="form2.price" placeholder="请输入要修改的价格"></el-input>
                                    </el-form-item>
                                </el-form>
                                <div slot="footer" class="dialog-footer">
                                    <el-button @click="revise=false">取 消</el-button>
                                    <el-button type="primary" @click="revise=false;revisepro(cid,form2.pro,form2.price)">确 定</el-button>
                                </div>
                            </el-dialog>
                            <!--修改分站价格-->
                        </div>
                    </el-collapse-transition>
                        
                    <el-collapse-transition>
                        <div v-if="show==true">
                            <el-button type="success" style="width:100%" size="mini" @click="add=!add" plain>添加用户</el-button>
                            
                            <!--密价用户列表-->
                            <table class="table table-hover" style="font-size:14px">
                                <thead>
                                    <tr>
                                        <th>uid</th>
                                        <th>昵称</th>
                                        <th>账号</th>
                                        <th>分站</th>
                                        <th>操作</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="use in rs.data">
                                        <td>{{use.uid}}</td>
                                        <td>{{use.name}}</td>
                                        <td>{{use.user}}</td>
                                        <td><span style="color:red">{{use.pro}}</span></td>
                                        <td>
                                            <el-button type="danger" size="mini" @click="del(use.uid)" plain>
                                            删除用户</el-button>
                                            <el-button type="primary" size="mini" @click="xiu=!xiu;info(use.uid)" plain>
                                            修改分站</el-button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <!--密价用户列表-->
                            
                            <!--修改分站类型-->
                            <el-dialog title="修改分站" :visible.sync="xiu">
                                <el-form :model="form1">
                                    <el-form-item label="分站">
                                        <el-select v-model="form1.pro" placeholder="请选择一个分站">
                                            <el-option label="专业版" value="1"></el-option>
                                            <el-option label="普通版" value="2"></el-option>
                                        </el-select>
                                    </el-form-item>
                                </el-form>
                                <div slot="footer" class="dialog-footer">
                                    <el-button @click="xiu=false">取 消</el-button>
                                    <el-button type="primary" @click="xiu=false;xg(uid,form1.pro)">确 定</el-button>
                                </div>
                            </el-dialog>
                            <!--修改分站类型-->
                            
                            <!--添加密价用户-->
                            <el-dialog title="添加用户" :visible.sync="add">
                                <el-form :model="form" label-position="top">
                                    <el-form-item label="输入uid">
                                        <el-input v-model="form.useruid" placeholder="请输入用户的uid"></el-input>
                                    </el-form-item>
                                    <el-form-item label="选择分站">
                                        <el-select v-model="form.pro" placeholder="请选择一个分站">
                                            <el-option label="专业版" value="1"></el-option>
                                            <el-option label="普通版" value="2"></el-option>
                                        </el-select>
                                    </el-form-item>
                                </el-form>
                                <div slot="footer" class="dialog-footer">
                                    <el-button @click="add=false">取 消</el-button>
                                    <el-button type="primary" @click="addpro(form.useruid,form.pro);add=false">确 定</el-button>
                                </div>
                            </el-dialog>
                            <!--添加密价用户-->
                            
                        </div>
                    </el-collapse-transition>
                    <!--添加等级版块-->
                    
                </div>
            </el-card>
            </div>
		</div>
</div>
<script type="text/javascript" src="assets/LightYear/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/main.min.js"></script>
<script src="assets/js/vue.min.js"></script>
<script src="assets/js/vue-resource.min.js"></script>
<script src="assets/js/element.js"></script>

<script>
var vm=new Vue({
	el:"#add",
	data:{
        show: true,
        xiu:false,
        add:false,
        row:null,
        revise:false,
        rs:null,
        prouser:null,
        uid:'',
        cid:'',
        form:{
            useruid:'',
            pro:'',
        },
        form1:{
            pro:'',
        },
        form2:{
            pro:'',
            price:'',
        },
	},
	methods:{
        get:function(){
		    var load=layer.load();
 			this.$http.post("/apisub.php?act=getclass",{emulateJSON:true}).then(function(data){	
	          	layer.close(load);
	          	if(data.data.code==1){			                     	
	          		this.row=data.body;
	          	// 	var arr=data.body.data[0].pro.split(",");
	          	}else{
	                layer.msg(data.data.msg,{icon:2});
	          	}
	        });	
	        this.$http.post("/apisub.php?act=getprice",{emulateJSON:true}).then(function(data){	
	          	if(data.data.code==1){			                     	
	          		this.rs=data.body;
	          	}else{
	                layer.msg(data.data.msg,{icon:2});
	          	}
	        });	
		},
		del: function(uid){
		    var load=layer.load();
 			this.$http.post("/apisub.php?act=delprice",{uid:uid},{emulateJSON:true}).then(function(data){	
	          	layer.close(load);
	          	vm.get();
                layer.msg(data.data.msg);
	        });
		},
		revisepro: function(cid,pro,price){
            var load=layer.load();
            $.post("/apisub.php?act=revisepro",{cid:cid,pro:pro,price:price},function (data) {
                layer.close(load);
                if (data.code==1){
                    vm.get();
                    layer.msg(data.msg,{icon:1});
                }else{
                    layer.msg(data.msg,{icon:2});
                }
            });
		},
		xg: function(uid,pro){
		    var load=layer.load();
 			this.$http.post("/apisub.php?act=xgpro",{uid:uid,pro:pro},{emulateJSON:true}).then(function(data){	
	          	layer.close(load);
	          	vm.get();
                layer.msg(data.data.msg);
	        });
		},
		info: function(a){
		    this.uid=a;
		},
		info2: function(a){
		    this.cid=a;
		},
		addpro: function(uid,pro){
            var load=layer.load();
            $.post("/apisub.php?act=addpro",{uid:uid,pro:pro},function (data) {
                layer.close(load);
                if (data.code==1){
                    vm.get();
                    layer.msg(data.msg,{icon:1});
                }else{
                    layer.msg(data.msg,{icon:2});
                }
            });
		},
	},
	mounted(){
		this.get();
	}
});
</script>