<?php
include('../confing/common.php');
$dd=$DB->count("select count(oid) from qingka_wangke_order where uid='{$userrow['uid']}' ");
$xj=$DB->count("select count(uid) from qingka_wangke_user where uuid='{$userrow['uid']}'");
$ywc=$DB->count("SELECT count(oid) FROM `qingka_wangke_order` WHERE status='已完成' AND uid='{$userrow['uid']}' ");
$jxz=$DB->count("SELECT count(oid) FROM `qingka_wangke_order` WHERE status='进行中' AND uid='{$userrow['uid']}' ");
$dcl=$DB->count("SELECT count(oid) FROM `qingka_wangke_order` WHERE status='待处理' AND uid='{$userrow['uid']}' ");
$ycdd=$DB->count("SELECT count(oid) FROM `qingka_wangke_order` WHERE status='异常' AND uid='{$userrow['uid']}' ");
$zcdd=$dd-$ycdd;
$dlzs=$DB->count("select count(uid) from qingka_wangke_user where uuid='{$userrow['uid']}' ");
$yxdl=$DB->count("select count(uid) from qingka_wangke_user where uuid='{$userrow['uid']}' AND active='1' ");
$wxdl=$dlzs-$yxdl;
$ysy=$userrow['zcz']-$userrow['money'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="lib/layui-v2.6.3/css/layui.css" media="all">
    <link rel="stylesheet" href="lib/font-awesome-4.7.0/css/font-awesome.min.css" media="all">
    <link rel="stylesheet" href="css/public.css" media="all">
    <style>
        .layui-card {border:1px solid #f2f2f2;border-radius:5px;}
        .icon {margin-right:10px;color:#1aa094;}
        .icon-cray {color:#ffb800!important;}
        .icon-blue {color:#1e9fff!important;}
        .icon-tip {color:#ff5722!important;}
        .layuimini-qiuck-module {text-align:center;margin-top: 10px}
        .layuimini-qiuck-module a i {display:inline-block;width:100%;height:60px;line-height:60px;text-align:center;border-radius:2px;font-size:30px;background-color:#F8F8F8;color:#333;transition:all .3s;-webkit-transition:all .3s;}
        .layuimini-qiuck-module a cite {position:relative;top:2px;display:block;color:#666;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;font-size:14px;}
        .welcome-module {width:100%;height:210px;}
        .panel {background-color:#fff;border:1px solid transparent;border-radius:3px;-webkit-box-shadow:0 1px 1px rgba(0,0,0,.05);box-shadow:0 1px 1px rgba(0,0,0,.05)}
        .panel-body {padding:10px}
        .panel-title {margin-top:0;margin-bottom:0;font-size:12px;color:inherit}
        .label {display:inline;padding:.2em .6em .3em;font-size:75%;font-weight:700;line-height:1;color:#fff;text-align:center;white-space:nowrap;vertical-align:baseline;border-radius:.25em;margin-top: .3em;}
        .layui-red {color:red}
        .main_btn > p {height:40px;}
        .layui-bg-number {background-color:#F8F8F8;}
        .layuimini-notice:hover {background:#f6f6f6;}
        .layuimini-notice {padding:7px 16px;clear:both;font-size:12px !important;cursor:pointer;position:relative;transition:background 0.2s ease-in-out;}
        .layuimini-notice-title,.layuimini-notice-label {
            padding-right: 70px !important;text-overflow:ellipsis!important;overflow:hidden!important;white-space:nowrap!important;}
        .layuimini-notice-title {line-height:28px;font-size:14px;}
        .layuimini-notice-extra {position:absolute;top:50%;margin-top:-8px;right:16px;display:inline-block;height:16px;color:#999;}
    </style>
    <style>
        .top-panel {
            border: 1px solid #eceff9;
            border-radius: 5px;
            text-align: center;
        }
        .top-panel > .layui-card-body{
            height: 60px;
        }
        .top-panel-number{
            line-height:60px;
            font-size: 30px;
            border-right:1px solid #eceff9;
        }
        .top-panel-tips{
            line-height:30px;
            font-size: 12px
        }
    </style>
</head>
<body>
    <div class="layuimini-main">

    <div class="layui-row layui-col-space15">
        <div class="layui-col-xs12 layui-col-md3">

            <div class="layui-card top-panel">
                <div class="layui-card-header">平台费率</div>
                <div class="layui-card-body">
                    <div class="layui-row layui-col-space5">
                        
                        <div class="layui-col-xs7 layui-col-md7 top-panel-number">
                            <?php echo $userrow['addprice'];?>
                        </div>
                        <div class="layui-col-xs5 layui-col-md5 top-panel-tips">
                            顶级 <a style="color: #1E90FF"><i class="fa fa-thumbs-up"></i>&nbsp;0.2</a><br>
                            入门 <a style="color: #bd3004"><i class="fa fa-thumbs-down"></i>&nbsp;0.4</a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="layui-col-xs12 layui-col-md3">

            <div class="layui-card top-panel">
                <div class="layui-card-header">账户余额</div>
                <div class="layui-card-body">
                    <div class="layui-row layui-col-space5">
                        <div class="layui-col-xs7 layui-col-md7 top-panel-number">
                            <?php echo $userrow['money']; ?>
                        </div>
                        <div class="layui-col-xs5 layui-col-md5 top-panel-tips">
                            已使用 <a style="color: #1E90FF"><i class="fa fa-jpy"></i>&nbsp;<?php echo $ysy; ?></a><br>
                            总充值 <a style="color: #bd3004"><i class="fa fa-jpy"></i>&nbsp;<?php echo $userrow['zcz']; ?></a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="layui-col-xs12 layui-col-md3">

            <div class="layui-card top-panel">
                <div class="layui-card-header">下单数量</div>
                <div class="layui-card-body">
                    <div class="layui-row layui-col-space5">
                        <div class="layui-col-xs7 layui-col-md7 top-panel-number">
                            <?php echo $dd; ?>
                        </div>
                        <div class="layui-col-xs5 layui-col-md5 top-panel-tips">
                            正常订单 <a style="color: #1E90FF"><i class="fa fa-bar-chart"></i>&nbsp;<?php echo $zcdd; ?></a><br>
                            异常订单 <a style="color: #bd3004"><i class="fa fa-bar-chart"></i>&nbsp;<?php echo $ycdd; ?></a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="layui-col-xs12 layui-col-md3">

            <div class="layui-card top-panel">
                <div class="layui-card-header">下级代理</div>
                <div class="layui-card-body">
                    <div class="layui-row layui-col-space5">
                        <div class="layui-col-xs7 layui-col-md7 top-panel-number">
                            <?php echo $xj; ?>
                        </div>
                        <div class="layui-col-xs5 layui-col-md5 top-panel-tips">
                            正常代理 <a style="color: #1E90FF"><i class="fa fa-group"></i>&nbsp;<?php echo $yxdl; ?></a><br>
                            封禁代理 <a style="color: #bd3004"><i class="fa fa-user-times"></i>&nbsp;<?php echo $wxdl; ?></a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<div class="layuimini-container">
    <div class="layuimini-main">
        <div class="layui-row layui-col-space15">
            <div class="layui-col-md8">
                <div class="layui-row layui-col-space15">
                    <div class="layui-col-md6">
                        <div class="layui-card">
                            <div class="layui-card-header"><i class="fa fa-bar-chart"></i>订单数据</div>
                            <div class="layui-card-body">
                                <div class="welcome-module">
                                    <div class="layui-row layui-col-space10">
                                        <div class="layui-col-xs6">
                                            <div class="panel layui-bg-number">
                                                <div class="panel-body">
                                                    <div class="panel-title">
                                                        <span class="label pull-right layui-bg-blue">实时</span>
                                                        <h5>已下单</h5>
                                                    </div>
                                                    <div class="panel-content">
                                                        <h1 class="no-margins"><?php echo $dd; ?></h1>
                                                        <small>条</small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="layui-col-xs6">
                                            <div class="panel layui-bg-number">
                                                <div class="panel-body">
                                                    <div class="panel-title">
                                                        <span class="label pull-right layui-bg-blue">实时</span>
                                                        <h5>已完成</h5>
                                                    </div>
                                                    <div class="panel-content">
                                                        <h1 class="no-margins"><?php echo $ywc; ?></h1>
                                                        <small>条</small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="layui-col-xs6">
                                            <div class="panel layui-bg-number">
                                                <div class="panel-body">
                                                    <div class="panel-title">
                                                        <span class="label pull-right layui-bg-blue">实时</span>
                                                        <h5>进行中</h5>
                                                    </div>
                                                    <div class="panel-content">
                                                        <h1 class="no-margins"><?php echo $jxz; ?></h1>
                                                        <small>条</small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="layui-col-xs6">
                                            <div class="panel layui-bg-number">
                                                <div class="panel-body">
                                                    <div class="panel-title">
                                                        <span class="label pull-right layui-bg-blue">实时</span>
                                                        <h5>待处理</h5>
                                                    </div>
                                                    <div class="panel-content">
                                                        <h1 class="no-margins"><?php echo $dcl; ?></h1>
                                                        <small>条</small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="layui-col-md6">
                        <div class="layui-card">
                            <div class="layui-card-header"><i class="fa fa-credit-card icon icon-blue"></i>快捷入口</div>
                            <div class="layui-card-body">
                                <div class="welcome-module">
                                    <div class="layui-row layui-col-space10 layuimini-qiuck">
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a href="javascript:;" layuimini-content-href="add" data-title="订单提交" data-icon="fa fa-window-maximize">
                                                <i class="fa fa-check-square-o"></i>
                                                <cite>订单提交</cite>
                                            </a>
                                        </div>
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a href="javascript:;" layuimini-content-href="list" data-title="订单列表" data-icon="fa fa-gears">
                                                <i class="fa fa-bar-chart"></i>
                                                <cite>订单列表</cite>
                                            </a>
                                        </div>
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a href="javascript:;" layuimini-content-href="userlist" data-title="下级管理" data-icon="fa fa-file-text">
                                                <i class="fa fa-group"></i>
                                                <cite>下级管理</cite>
                                            </a>
                                        </div>
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a href="javascript:;" layuimini-content-href="log" data-title="操作日志" data-icon="fa fa-dot-circle-o">
                                                <i class="fa fa-pie-chart"></i>
                                                <cite>操作日志</cite>
                                            </a>
                                        </div>
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a href="javascript:;" layuimini-content-href="charge" data-title="余额充值" data-icon="fa fa-calendar">
                                                <i class="fa fa-calendar"></i>
                                                <cite>余额充值</cite>
                                            </a>
                                        </div>
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a href="javascript:;" layuimini-content-href="docking" data-title="对接文档" data-icon="fa fa-hourglass-end">
                                                <i class="fa fa-hourglass-end"></i>
                                                <cite>对接文档</cite>
                                            </a>
                                        </div>
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a href="javascript:;" layuimini-content-href="user" data-title="个人信息" data-icon="fa fa-snowflake-o">
                                                <i class="fa fa-user"></i>
                                                <cite>个人信息</cite>
                                            </a>
                                        </div>
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a href="javascript:;" layuimini-content-href="help" data-title="学习帮助" data-icon="fa fa-search">
                                                <i class="fa fa-search"></i>
                                                <cite>学习帮助</cite>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="layui-col-md4">

                <div class="layui-card">
                    <div class="layui-card-header"><i class="fa fa-bullhorn icon icon-tip"></i>系统公告</div>
                    <div class="layui-card-body layui-text">
                        <div class="layuimini-notice">
                            <div class="layuimini-notice-title">平台公告</div>
                            <div class="layuimini-notice-extra">2022-09-01</div>
                            <div class="layuimini-notice-content layui-hide">
                                为了平台长期稳定发展，请各位代理低调行事<br>
                                商品通知Telegram频道：<a href='https://t.me/+gcJzL3aL77ViMTJl'>https://t.me/+gcJzL3aL77ViMTJl</a><br>
                            </div>
                        </div>
                        <div class="layuimini-notice">
                            <div class="layuimini-notice-title">商品说明</div>
                            <div class="layuimini-notice-extra">2022-09-01</div>
                            <div class="layuimini-notice-content layui-hide">
                                上架可查出课的商品都可以正常下单<br>
                                学习强国需要去强国专用下单页面下单<br>
                                如有需要没上架的商品，请联系上级进行反馈<br>
                            </div>
                        </div>
                        <div class="layuimini-notice">
                            <div class="layuimini-notice-title">违规警告</div>
                            <div class="layuimini-notice-extra">2022-09-01</div>
                            <div class="layuimini-notice-content layui-hide">
                                禁止低开账户<br>
                                禁止在公开场合发布本平台地址<br>
                            </div>
                        </div>
                        <div class="layuimini-notice">
                            <div class="layuimini-notice-title">安全提示</div>
                            <div class="layuimini-notice-extra">2022-09-01<</div>
                            <div class="layuimini-notice-content layui-hide">
                                请各位代理保管好自己的平台账号密码KEY等信息，如有泄露，余额被盗与本平台无关<br>
                            </div>
                        </div>
                        <div class="layuimini-notice">
                            <div class="layuimini-notice-title">api调用说明</div>
                            <div class="layuimini-notice-extra">2022-09-01</div>
                            <div class="layuimini-notice-content layui-hide">
                                余额低于20时无法调用api查课，请各位代理注意<br>
                            </div>
                        </div>
                    </div>
                </div>
                <!--<div class="layui-card">
                    <div class="layui-card-header"><i class="fa fa-fire icon"></i>个人信息</div>
                    <div class="layui-card-body layui-text">
                        <table class="layui-table">
                            <colgroup>
                                <col width="100">
                                <col>
                            </colgroup>
                            <tbody>
                            <tr>
                                <td>UID</td>
                                <td>
                                    <?php echo $userrow['uid']?>
                                </td>
                            </tr>
                            <tr>
                                <td>昵称</td>
                                <td>
                                    <?php echo $userrow['name']?>
                                </td>
                            </tr>
                            <tr>
                                <td>等级</td>
                                <td>
                                    <?php echo $userrow['addprice']; ?> 费率
                                </td>
                            </tr>
                            <tr>
                                <td>余额</td>
                                <td>
                                    <?php echo $userrow['money']; ?> 个琳琅币
                                </td>
                            </tr>
                            <tr>
                                <td>邀请码</td>
                                <td>
                                    <?php echo $userrow['yqm']==''?'无':$userrow['yqm']; ?>
                                </td>
                            </tr>
                            <tr>
                                <td>KEY</td>
                                <div class="text-muted">
                                <td style="padding-bottom: 0;">
                                    <?php echo $userrow['KEY']=='0'?'未开通，请联系上级':$userrow['key']; ?>
                                </td>
                                </div>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>-->
                
            </div>
        </div>
    </div>
    <div class="layui-card">
                    <div class="layui-card-header"><i class="fa fa-paper-plane-o icon"></i>每日一言</div>
                    <div class="layui-card-body layui-text layadmin-text"  style="width=100%">
                        <script type="text/javascript" src="https://api.vvhan.com/api/ian?type=js"></script><script>vhan()</script>
                    </div>
                </div>
</div>

<script type="text/javascript" src="assets/LightYear/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="assets/LightYear/js/main.min.js"></script>
<script src="assets/js/aes.js"></script>
<script src="https://cdn.staticfile.org/vue/2.6.11/vue.min.js"></script>
<script src="https://cdn.staticfile.org/vue-resource/1.5.1/vue-resource.min.js"></script>
<script src="https://cdn.staticfile.org/axios/0.18.0/axios.min.js"></script>
<script src="assets/js/sy.js"></script>
<script src="lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script src="js/lay-config.js?v=1.0.4" charset="utf-8"></script>

<script type="text/javascript">
		    var vm=new Vue({
		     	el: "#userindex",
		    	data: {
		      		row:null,
		      		inte:'',
		        },
		      	methods:{
		    		userinfo:function(){
		    			var load=layer.load();
		     			this.$http.post("/apisub.php?act=userinfo")
				          .then(function(data){	
				          	   	layer.close(load);
				          	if(data.data.code==1){			                     	
				          		this.row=data.data			             			                     
				          	}else{
				                layer.alert(data.data.msg,{icon:2});
				          	}
				          });	
		    		},
		    		yecz:function(){
		    			layer.alert('请联系您的上级QQ：'+this.row.sjuser+'，进行充值。（好友点充值，此处将显示您的QQ）',{icon:1,title:"温馨提示"});
		    		},
		    		ktapi:function(){
		    			layer.confirm('后台余额满300学时可免费开通，反之需花费10铜钱开通', {title:'温馨提示',icon:1,
							  btn: ['确定','取消'] //按钮
							}, function(){
							  		var load=layer.load();
					     			axios.get("/apisub.php?act=ktapi&type=1")
							          .then(function(data){	
							          	   	layer.close(load);
							          	if(data.data.code==1){			                     	
	    			                        layer.alert(data.data.msg,{icon:1,title:"温馨提示"},function(){setTimeout(function(){window.location.href=""});});							          				             			                     
							          	}else{
							                layer.msg(data.data.msg,{icon:2});
							          	}
							        });	
							
						    });
		    	    },
		    	    szyqprice:function(){		    	    	
						layer.prompt({title: '设置好友默认等级，首次自动生成邀请码', formType: 3}, function(yqprice, index){
						  layer.close(index);
						  var load=layer.load();
			              $.post("/apisub.php?act=yqprice",{yqprice},function (data) {
					 	     layer.close(load);
				             if (data.code==1){
				             	vm.userinfo();  
				                layer.alert(data.msg,{icon:1});
				             }else{
				                layer.msg(data.msg,{icon:2});
				             }
			              });		    		    
					  });
		    	    },
		    	    connect_qq:function(){
		    	    	    var ii = layer.load(0, {shade:[0.1,'#fff']});
							$.ajax({
								type : "POST",
								url : "../apisub.php?act=connect",
								data : {},
								dataType : 'json',
								success : function(data) {
									layer.close(ii);
									if(data.code == 0){
										window.location.href = data.url;
									}else{
										layer.alert(data.msg, {icon: 7});
									}
								} 
							});	
		    	  },szgg:function(){
		    	  		layer.prompt({title: '设置代理公告，您的代理可看到', formType: 2}, function(notice, index){
						  layer.close(index);
						  var load=layer.load();
			              $.post("/apisub.php?act=user_notice",{notice},function (data) {
					 	     layer.close(load);
				             if (data.code==1){
				             	vm.userinfo();  
				                layer.msg(data.msg,{icon:1});
				             }else{
				                layer.msg(data.msg,{icon:2});
				             }
			              });		    		    
					  });   	  	
		    	  }
		    	
		     	},
		     	mounted(){
		     		this.userinfo();
		     		
		     	}
		      });
		  
       </script>
       
<script>
    layui.use(['layer', 'miniTab','echarts'], function () {
        var $ = layui.jquery,
            layer = layui.layer,
            miniTab = layui.miniTab,
            echarts = layui.echarts;

        miniTab.listen();

        /**
         * 查看公告信息
         **/
        $('body').on('click', '.layuimini-notice', function () {
            var title = $(this).children('.layuimini-notice-title').text(),
                noticeTime = $(this).children('.layuimini-notice-extra').text(),
                content = $(this).children('.layuimini-notice-content').html();
            var html = '<div style="padding:15px 20px; text-align:justify; line-height: 22px;border-bottom:1px solid #e2e2e2;background-color: #2f4056;color: #ffffff">\n' +
                '<div style="text-align: center;margin-bottom: 20px;font-weight: bold;border-bottom:1px solid #718fb5;padding-bottom: 5px"><h4 class="text-danger">' + title + '</h4></div>\n' +
                '<div style="font-size: 12px">' + content + '</div>\n' +
                '</div>\n';
            parent.layer.open({
                type: 1,
                title: '系统公告'+'<span style="float: right;right: 1px;font-size: 12px;color: #b1b3b9;margin-top: 1px">'+noticeTime+'</span>',
                area: '300px;',
                shade: 0.8,
                id: 'layuimini-notice',
                btn: ['关闭'],
                btnAlign: 'c',
                moveType: 1,
                content:html,
                success: function (layero) {
                    var btn = layero.find('.layui-layer-btn');
                    btn.find('.layui-layer-btn1').attr({
                        href: '',
                        target: ''
                    });
                }
            });
        });

        /**
         * 报表功能
         */
        /*var echartsRecords = echarts.init(document.getElementById('echarts-records'), 'walden');
        var optionRecords = {
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data:['订单数']
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            toolbox: {
                feature: {
                    saveAsImage: {}
                }
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: ['周一','周二','周三','周四','周五','周六','周日']
            },
            yAxis: {
                type: 'value'
            },
            series: [
                {
                    name:'订单数',
                    type:'line',
                    data:[220, 182, 191, 234, 290, 330, 310]
                }
            ]
        };
        echartsRecords.setOption(optionRecords);*/

        // echarts 窗口缩放自适应
        window.onresize = function(){
            echartsRecords.resize();
        }

    });
</script>
</body>
</html>
