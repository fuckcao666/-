<?php
include('../confing/common.php');
?>
<!DOCTYPE html>
<html lang="zh-cn">
    <head>
        <meta charset="utf-8"/>
        <link rel="icon" href="../favicon.ico" type="image/ico">
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <title><?=$conf['sitename'];?></title>
        <meta name="keywords" content="<?=$conf['sitename'];?>"/>
        <meta name="description" content="<?=$conf['sitename'];?>"/>
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet"/>
        <link rel="stylesheet" href="../assets/layui/css/layui.css"/>
        
    <style>
      body {
            background-image: url("images/loginbg.png");
            background-repeat: no-repeat;
            background-size: cover;
            min-height: 100vh;
        }

        body:before {
            content: "";
            background-color: rgba(0, 0, 0, .2);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
        }

        .login-wrapper {
            max-width: 420px;
            padding: 20px;
            margin: 0 auto;
            position: relative;
            box-sizing: border-box;
            z-index: 2;
        }

        .login-wrapper>.layui-form {
            padding: 25px 30px;
            background-color: #fff;
            box-shadow: 0 3px 6px -1px rgba(0, 0, 0, 0.19);
            box-sizing: border-box;
            border-radius: 4px;
        }

        .login-wrapper>.layui-form>h2 {
            color: #333;
            font-size: 18px;
            text-align: center;
            margin-bottom: 25px;
        }

        .login-wrapper>.layui-form>.layui-form-item {
            margin-bottom: 25px;
            position: relative;
        }

        .login-wrapper>.layui-form>.layui-form-item:last-child {
            margin-bottom: 0;
        }

        .login-wrapper>.layui-form>.layui-form-item>.layui-input {
            height: 46px;
            line-height: 46px;
            border-radius: 2px !important;
        }

        .login-wrapper .layui-input-icon-group>.layui-input {
            padding-left: 46px;
        }

        .login-wrapper .layui-input-icon-group>.layui-icon {
            width: 46px;
            height: 46px;
            line-height: 46px;
            font-size: 20px;
            color: #909399;
            position: absolute;
            left: 0;
            top: 0;
            text-align: center;
        }

        .login-wrapper>.layui-form>.layui-form-item.login-captcha-group {
            padding-right: 135px;
        }

        .login-wrapper>.layui-form>.layui-form-item.login-captcha-group>.login-captcha {
            height: 46px;
            width: 120px;
            cursor: pointer;
            box-sizing: border-box;
            border: 1px solid #e6e6e6;
            border-radius: 2px !important;
            position: absolute;
            right: 0;
            top: 0;
        }

        .login-wrapper>.layui-form>.layui-form-item>.layui-form-checkbox {
            margin: 0 !important;
            padding-left: 25px;
        }

        .login-wrapper>.layui-form>.layui-form-item>.layui-form-checkbox>.layui-icon {
            width: 15px !important;
            height: 15px !important;
        }

        .login-wrapper>.layui-form .layui-btn-fluid {
            height: 48px;
            line-height: 48px;
            font-size: 16px;
            border-radius: 2px !important;
        }

        .login-wrapper>.layui-form>.layui-form-item.login-oauth-group>a>.layui-icon {
            font-size: 26px;
        }
        .login-copyright {
            color: #eee;
            padding-bottom: 20px;
            text-align: center;
            position: relative;
            z-index: 1;
        }

        @media screen and (min-height: 550px) {
            .login-wrapper {
                margin: -250px auto 0;
                position: absolute;
                top: 50%;
                left: 0;
                right: 0;
                width: 100%;
            }

            .login-copyright {
                position: absolute;
                bottom: 0;
                right: 0;
                left: 0;
            }
        }

        .layui-btn {
            background-color: #5FB878;
            border-color: #5FB878;
        }

        .layui-link {
            color: #5FB878 !important;
        }

        .layui-input {
            border-top: none;
            border-left: none;
            border-right: none;
        }

        .layui-input:hover,
        .layui-textarea:hover {
            border-color: #00a65a !important;
        }

    </style>
       
<script>
$(document).ready(function() {
  //粒子背景特效
  $('body').particleground({
    dotColor: '#5cbdaa',
    lineColor: '#5cbdaa'
  });
</script>
        
    </head>
  
        

<body>
   <div id="login1">
    <div v-if="loginType" class="login-wrapper layui-anim layui-anim-scale " >
        <div class="layui-form" >
           <br>
                    </center>
            <div class="layui-form-item layui-input-icon-group">
                
                <input class="layui-input" v-model="dl.user" placeholder="登录账号" 
                    lay-verify="required" required />
            </div>
            <div class="layui-form-item layui-input-icon-group">
                
                <input class="layui-input" v-model="dl.pass" placeholder="登录密码" type="password" 
                    lay-verify="required" required />
            </div>

            <div class="layui-form-item">
                <button class="layui-btn btn-danger" style="width: 100%" @click="login" lay-submit>登录</button>
            </div>
            <div class="layui-form-item">
                <input type="checkbox" name="remember" title="记住密码" lay-skin="primary" checked>
             
      <!--<a @click="newlogin" class="layui-link">返回登录</a>-->
                <a @click="newlogin" class="layui-link pull-right">注册账号</a>
            </div>
        </div>
     </div>
     
    <div v-else class="login-wrapper layui-anim layui-anim-scale">
        <div class="layui-form">
            <h2>用户注册</h2>
            <div class="layui-form-item layui-input-icon-group">
                
                <input type="text" v-model="reg.yqm" required lay-verify="required" placeholder="邀请码" autocomplete="off" class="layui-input">
            </div>

            <div class="layui-form-item layui-input-icon-group">
                
                <input type="text" v-model="reg.user" required lay-verify="required" placeholder="账号（账号必须为QQ号）" autocomplete="off" class="layui-input">
            </div>

            <div class="layui-form-item layui-input-icon-group">
                
                <input type="password" v-model="reg.pass" required lay-verify="required" placeholder="密码" autocomplete="off" class="layui-input">
            </div>
            <div class="layui-form-item layui-input-icon-group">
                
                <input type="text" v-model="reg.name" required lay-verify="required" placeholder="昵称" autocomplete="off" class="layui-input ">
            </div>

            <div class="layui-form-item">
                <a @click="newlogin" class="layui-link">返回登录</a>
                <a @click="newlogin" class="layui-link pull-right">注册账号</a>
            </div>  
            <div class="layui-form-item" style="margin-bottom: 20px;">
                <button class="layui-btn btn-danger" style="width: 100%" @click="register">立即注册</button>
               </div>
        </div>
    </div> 
    <div class="text-center" style="padding: 20px;font-size: 18px;">
    <p>
  
    </p>
</div>
</div></div></div></div></body></html><script src="assets/js/bootstrap.min.js"></script>
<!--<script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script>-->
<script src="https://s3.pstatp.com/cdn/expire-1-M/jquery/3.3.1/jquery.min.js"></script>
<script src="layer/3.1.1/layer.js"></script>
<script src="https://cdn.staticfile.org/vue/2.6.11/vue.min.js"></script>
<script src="https://cdn.staticfile.org/vue-resource/1.5.1/vue-resource.min.js"></script>
<script src="https://cdn.staticfile.org/axios/0.18.0/axios.min.js"></script>
<script>
    var vm = new Vue({
        el: "#login1",
        data: {
            loginType: true,
            title: "你在看什么呢？我写的代码好看吗",
            dl: {},
            reg: {}
        },
        methods: {
            newlogin: function() {
                this.loginType = !this.loginType
            },
            login: function() {
                if (!this.dl.user || !this.dl.pass) {
                    layer.msg('账号密码不能为空', {
                        icon: 2
                    });
                    return
                }
                var loading = layer.load();
                vm.$http.post("/apisub.php?act=login", {
                    user: this.dl.user,
                    pass: this.dl.pass
                }, {
                    emulateJSON: true
                }).then(function(data) {
                    layer.close(loading);
                    if (data.data.code == 1) {
                        layer.msg(data.data.msg, {
                            icon: 1
                        });
                        setTimeout(function() {
                            window.location.href = "index.php"
                        }, 1000);
                    } else if (data.data.code == 5) {
                        vm.login2();
                    } else {
                        layer.msg(data.data.msg, {
                            icon: 2
                        });
                    }
                });

            },
            register: function() {
                if (!this.reg.user || !this.reg.pass || !this.reg.name || !this.reg.yqm) {
                    layer.msg('所有项不能为空', {
                        icon: 2
                    });
                    return
                }
                var loading = layer.load();
                this.$http.post("/apisub.php?act=register", {
                    name: this.reg.name,
                    user: this.reg.user,
                    pass: this.reg.pass,
                    yqm: this.reg.yqm
                }, {
                    emulateJSON: true
                }).then(function(data) {
                    layer.close(loading);
                    if (data.data.code == 1) {
                        this.loginType = true;
                        this.dl.user = this.reg.user;
                        this.dl.pass = this.reg.pass;
                        layer.msg(data.data.msg, {
                            icon: 1
                        });
                    } else {
                        layer.msg(data.data.msg, {
                            icon: 2
                        });
                    }
                });
            },
            login2: function() {
                layer.prompt({
                    title: '管理二次验证',
                    formType: 3
                }, function(pass2, index) {
                    var loading = layer.load();
                    vm.$http.post("/apisub.php?act=login", {
                        user: vm.dl.user,
                        pass: vm.dl.pass,
                        pass2: pass2
                    }, {
                        emulateJSON: true
                    }).then(function(data) {
                        layer.close(loading);
                        if (data.data.code == 1) {
                            layer.msg(data.data.msg, {
                                icon: 1
                            });
                            setTimeout(function() {
                                window.location.href = "index.php"
                            }, 1000);
                        } else {
                            layer.msg(data.data.msg, {
                                icon: 2
                            });
                        }
                    });
                });
            }
        }
    });

    $('#connect_qq').click(function() {
        var ii = layer.load(0, {
            shade: [0.1, '#fff']
        });
        $.ajax({
            type: "POST",
            url: "../apisub.php?act=connect",
            data: {},
            dataType: 'json',
            success: function(data) {
                layer.close(ii);
                if (data.code == 0) {
                    window.location.href = data.url;
                } else {
                    layer.alert(data.msg, {
                        icon: 7
                    });
                }
            }
        });
    });
    ((function () {
    var callbacks = [], timeLimit = 50, open = false;
    setInterval(loop, 1);
    return {
        addListener: function (fn) {
            callbacks.push(fn);
        },
        cancleListenr: function (fn) {
            callbacks = callbacks.filter(function (v) {
                return v !== fn;
            });
        }
    }
    function loop() {
        var startTime = new Date();
        debugger;
        if (new Date() - startTime > timeLimit) {
            if (!open) {
                callbacks.forEach(function (fn) {
                    fn.call(null);
                });
            }
            open = true;
            window.stop();
            alert('没事别老研究人家接口');
            document.body.innerHTML="";
        } else {
            open = false;
        }
    }
})()).addListener(function () {
    window.location.reload();
});
</script>
                 <!--禁止右键代码-->
<script>
    document.oncontextmenu=new Function("event.returnValue=false;"); //禁止右键功能
    document.onkeydown=MM_KeyPress;
    function  MM_KeyPress(num){
        //防止系统退格键
        var keycode = event.keyCode;
        if(keycode ==8)//屏蔽退格健
        {
            event.keyCode = 0;
            return;
        }
        if(keycode >=122 && keycode <=123)//屏蔽f12功能键
        {
            event.keyCode = 0 ;
            event.returnValue=false;
            return;
        }
    }

</script>

<script>function fuckyou(){
      window.close(); //关闭当前窗口(防抽)
     window.location="about:blank"; //将当前窗口跳转置空白页
}
  function ck() {
    console.profile();
    console.profileEnd();
    //我们判断一下profiles里面有没有东西，如果有，肯定有人按F12了，没错！！
    if(console.clear) { console.clear() };
                        if (typeof console.profiles =="object"){
    return console.profiles.length > 0;
                        }
}
function hehe(){
if( (window.console && (console.firebug || console.table && /firebug/i.test(console.table()) )) || (typeof opera == 'object' && typeof opera.postError == 'function' && console.profile.length > 0)){
  fuckyou();
}
if(typeof console.profiles =="object"&&console.profiles.length > 0){
fuckyou();
}
}
hehe();

</script>
<!--禁止右键代码-->
</style>
<script type="text/javascript">
document.onkeydown = function(){
if(window.event && window.event.keyCode == 123) {
alert("别扒了哥哥，不怕我给你放木马嘛");
event.keyCode=0;
event.returnValue=false;
}
if(window.event && window.event.keyCode == 13) {
window.event.keyCode = 505;
}
if(window.event && window.event.keyCode == 8) {
alert(str+"\n请使用Del键进行字符的删除操作！");
window.event.returnValue=false;
}
}
</script>
